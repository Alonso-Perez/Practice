﻿<%@ Page Title="Menú Administrador" Language="C#" MasterPageFile="~/GoutuAdminTransporte.master" AutoEventWireup="true" CodeBehind="MenuAdminTransporte.aspx.cs" Inherits="GoutuWA.MenuAdminTransporte" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Menú Principal - Administrador de Transporte
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    <style>
        .welcome-section {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .welcome-title {
            color: #5e2a84;
            font-size: 28px;
            font-weight: 700;
            margin-bottom: 10px;
        }

        .welcome-subtitle {
            color: #666;
            font-size: 16px;
        }

        .admin-cards {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 25px;
            margin-top: 30px;
        }

        .admin-card {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            text-decoration: none;
            color: inherit;
            display: block;
            border-left: 5px solid #5e2a84;
        }

        .admin-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 25px rgba(94, 42, 132, 0.2);
        }

        .card-icon {
            font-size: 48px;
            color: #5e2a84;
            margin-bottom: 20px;
        }

        .card-title {
            font-size: 22px;
            font-weight: 700;
            color: #333;
            margin-bottom: 10px;
        }

        .card-description {
            color: #666;
            font-size: 14px;
            line-height: 1.6;
        }

        .stats-section {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            padding: 30px;
            border-radius: 15px;
            color: white;
            margin-bottom: 30px;
        }

        .stats-title {
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 20px;
        }

        .stat-item {
            text-align: center;
            background: rgba(255, 255, 255, 0.2);
            padding: 20px;
            border-radius: 10px;
        }

        .stat-number {
            font-size: 32px;
            font-weight: 700;
            display: block;
            margin-bottom: 5px;
        }

        .stat-label {
            font-size: 14px;
            opacity: 0.9;
        }
    </style>

    <div class="welcome-section">
        <div class="welcome-title">
            <i class="fa-solid fa-hand-wave"></i> Bienvenido, <asp:Label ID="lblNombreAdmin" runat="server" />
        </div>
        <p class="welcome-subtitle">Panel de administración de transporte - Gestiona rutas y tarifas del sistema</p>
    </div>

    <div class="stats-section">
        <div class="stats-title">
            <i class="fa-solid fa-chart-line"></i> Resumen del Sistema
        </div>
        <div class="stats-grid">
            <div class="stat-item">
                <span class="stat-number">
                    <asp:Label ID="lblTotalRutas" runat="server" Text="0" />
                </span>
                <span class="stat-label">Rutas Activas</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">
                    <asp:Label ID="lblTotalTarifas" runat="server" Text="0" />
                </span>
                <span class="stat-label">Tarifas Configuradas</span>
            </div>
            <div class="stat-item">
                <span class="stat-number">
                    <asp:Label ID="lblUsuariosActivos" runat="server" Text="0" />
                </span>
                <span class="stat-label">Usuarios Activos</span>
            </div>
        </div>
    </div>

    <div class="admin-cards">
        <a href="GestionRutas.aspx" class="admin-card">
            <div class="card-icon">
                <i class="fa-solid fa-route"></i>
            </div>
            <div class="card-title">Gestión de Rutas</div>
            <div class="card-description">
                Administra las rutas de transporte disponibles. Crea nuevas rutas, modifica las existentes o elimina las que ya no estén en uso.
            </div>
        </a>

        <a href="GestionTarifas.aspx" class="admin-card">
            <div class="card-icon">
                <i class="fa-solid fa-dollar-sign"></i>
            </div>
            <div class="card-title">Gestión de Tarifas</div>
            <div class="card-description">
                Configura y actualiza las tarifas del sistema de transporte. Define precios para diferentes tipos de usuarios y modalidades de viaje.
            </div>
        </a>
    </div>

</asp:Content>