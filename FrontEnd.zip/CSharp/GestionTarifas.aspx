﻿<%@ Page Title="Gestión de Tarifas" Language="C#" MasterPageFile="~/GoutuAdminTransporte.master" AutoEventWireup="true" CodeBehind="GestionTarifas.aspx.cs" Inherits="GoutuWA.GestionTarifas" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Tarifas - Administrador
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script type="text/javascript">
        function confirmarEliminacion() {
            return confirm('¿Está seguro que desea eliminar esta tarifa? Esta acción no se puede deshacer.');
        }

        function limpiarFormulario() {
            document.getElementById('<%= txtIdTarifa.ClientID %>').value = '';
            document.getElementById('<%= ddlTransporte.ClientID %>').selectedIndex = 0;
            document.getElementById('<%= txtDescripcion.ClientID %>').value = '';
            document.getElementById('<%= txtMonto.ClientID %>').value = '';
            document.getElementById('<%= btnGuardar.ClientID %>').innerText = 'Guardar Tarifa';
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    <style>
        .page-header {
            background: white;
            padding: 25px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            color: #5e2a84;
            font-size: 26px;
            font-weight: 700;
            margin: 0;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .form-title {
            color: #5e2a84;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #5e2a84;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #5e2a84;
            box-shadow: 0 0 0 3px rgba(94, 42, 132, 0.1);
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(94, 42, 132, 0.3);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .table-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            overflow-x: auto;
        }

        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .custom-table thead {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .custom-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        .custom-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
        }

        .custom-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .btn-action {
            padding: 8px 15px;
            margin: 0 3px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background-color: #ffc107;
            color: #000;
        }

        .btn-edit:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background-color: #c82333;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: #ddd;
        }

        .price-display {
            font-weight: 700;
            color: #28a745;
            font-size: 16px;
        }

        textarea.form-control {
            min-height: 80px;
            resize: vertical;
        }
    </style>

    <!-- Mensajes de alerta -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false">
        <div id="divMensaje" runat="server" class="alert">
            <asp:Label ID="lblMensaje" runat="server"></asp:Label>
        </div>
    </asp:Panel>

    <!-- Cabecera -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="fa-solid fa-dollar-sign"></i> Gestión de Tarifas
        </h1>
    </div>

    <!-- Formulario de Tarifa -->
    <div class="form-container">
        <div class="form-title">
            <i class="fa-solid fa-plus-circle"></i> <asp:Label ID="lblFormTitle" runat="server" Text="Nueva Tarifa"></asp:Label>
        </div>

        <asp:HiddenField ID="txtIdTarifa" runat="server" />

        <div class="form-row">
            <div class="form-group">
                <label for="<%= ddlTransporte.ClientID %>">
                    <i class="fa-solid fa-building"></i> Empresa de Transporte *
                </label>
                <asp:DropDownList ID="ddlTransporte" runat="server" CssClass="form-control" required="required">
                    <asp:ListItem Value="">-- Seleccione una empresa --</asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="<%= txtMonto.ClientID %>">
                    <i class="fa-solid fa-money-bill-wave"></i> Monto (S/.) *
                </label>
                <asp:TextBox ID="txtMonto" runat="server" CssClass="form-control" 
                    placeholder="Ej: 2.50" TextMode="Number" step="0.01" min="0" required="required"></asp:TextBox>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="<%= txtDescripcion.ClientID %>">
                    <i class="fa-solid fa-align-left"></i> Descripción *
                </label>
                <asp:TextBox ID="txtDescripcion" runat="server" CssClass="form-control" 
                    TextMode="MultiLine" placeholder="Ej: Tarifa para adultos en horario normal" 
                    MaxLength="500" required="required"></asp:TextBox>
            </div>
        </div>

        <div class="btn-group">
            <asp:Button ID="btnGuardar" runat="server" Text="Guardar Tarifa" 
                CssClass="btn btn-primary" OnClick="btnGuardar_Click" />
            <asp:Button ID="btnCancelar" runat="server" Text="Cancelar" 
                CssClass="btn btn-secondary" OnClick="btnCancelar_Click" 
                OnClientClick="limpiarFormulario(); return true;" />
        </div>
    </div>

    <!-- Tabla de Tarifas -->
    <div class="table-container">
        <div class="form-title" style="margin-bottom: 20px;">
            <i class="fa-solid fa-list"></i> Lista de Tarifas
        </div>

        <asp:GridView ID="gvTarifas" runat="server" CssClass="custom-table" 
            AutoGenerateColumns="False" DataKeyNames="id_tarifa"
            OnRowCommand="gvTarifas_RowCommand"
            EmptyDataText="No hay tarifas registradas">
            <Columns>
                <asp:BoundField DataField="id_tarifa" HeaderText="ID" />
                <asp:BoundField DataField="nombre_transporte" HeaderText="Empresa" />
                <asp:BoundField DataField="descripcion" HeaderText="Descripción" />
                <asp:TemplateField HeaderText="Monto">
                    <ItemTemplate>
                        <span class="price-display">S/. <%# String.Format("{0:N2}", Eval("monto")) %></span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:TemplateField HeaderText="Acciones">
                    <ItemTemplate>
                        <asp:Button ID="btnEditar" runat="server" Text="Editar" 
                            CssClass="btn-action btn-edit" 
                            CommandName="Editar" 
                            CommandArgument='<%# Eval("id_tarifa") %>' />
                        <asp:Button ID="btnEliminar" runat="server" Text="Eliminar" 
                            CssClass="btn-action btn-delete" 
                            CommandName="Eliminar" 
                            CommandArgument='<%# Eval("id_tarifa") %>'
                            OnClientClick="return confirmarEliminacion();" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <EmptyDataTemplate>
                <div class="empty-state">
                    <i class="fa-solid fa-inbox"></i>
                    <p>No hay tarifas registradas. ¡Comienza agregando una nueva tarifa!</p>
                </div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

</asp:Content>