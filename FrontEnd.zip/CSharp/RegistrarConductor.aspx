﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="RegistrarConductor.aspx.cs" Inherits="GoutuWA.RegistrarConductor" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Registrar Conductor
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .page-header {
            margin-bottom: 30px;
        }

        .page-header h2 {
            color: #4b0082;
            font-weight: 700;
            font-size: 32px;
            margin: 0;
        }

        .page-header p {
            color: #666;
            font-size: 16px;
            margin-top: 5px;
        }

        .form-card {
            background: white;
            border-radius: 15px;
            padding: 40px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            max-width: 800px;
            margin: 0 auto;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 25px;
            margin-bottom: 25px;
        }

        .form-row.full-width {
            grid-template-columns: 1fr;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-group label .required {
            color: #dc3545;
        }

        .form-control {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .form-control.error {
            border-color: #dc3545;
        }

        .error-message {
            color: #dc3545;
            font-size: 12px;
            display: none;
        }

        .error-message.show {
            display: block;
        }

        .form-select {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            background-color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .form-select:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .password-toggle {
            position: relative;
        }

        .password-toggle-btn {
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            background: none;
            border: none;
            color: #999;
            cursor: pointer;
            font-size: 16px;
        }

        .password-toggle-btn:hover {
            color: #4b0082;
        }

        .form-actions {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 40px;
        }

        .btn {
            padding: 14px 40px;
            border: none;
            border-radius: 8px;
            font-size: 16px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-primary {
            background-color: #4b0082;
            color: white;
        }

        .btn-primary:hover {
            background-color: #3a0066;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(75, 0, 130, 0.3);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(108, 117, 125, 0.3);
        }

        .info-box {
            background-color: #e7f3ff;
            border-left: 4px solid #1976d2;
            padding: 15px;
            border-radius: 8px;
            margin-bottom: 25px;
        }

        .info-box i {
            color: #1976d2;
            margin-right: 10px;
        }

        .info-box p {
            margin: 0;
            color: #333;
            font-size: 14px;
        }

        @media (max-width: 768px) {
            .form-card {
                padding: 25px;
            }

            .form-row {
                grid-template-columns: 1fr;
            }

            .form-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <!-- Header -->
    <div class="page-header">
        <h2><i class="fa-solid fa-user-plus"></i> Registrar Conductor</h2>
        <p>Complete el formulario para registrar un nuevo conductor en el sistema</p>
    </div>

    <!-- Formulario -->
    <div class="form-card">
        
        <div class="info-box">
            <i class="fa-solid fa-info-circle"></i>
            <p>Los campos marcados con <span style="color: #dc3545;">*</span> son obligatorios</p>
        </div>

        <!-- Fila 1: Nombre y Apellido -->
        <div class="form-row">
            <div class="form-group">
                <label>Nombre <span class="required">*</span></label>
                <asp:TextBox ID="txtNombre" runat="server" CssClass="form-control" placeholder="Ingrese el nombre"></asp:TextBox>
                <span class="error-message" id="errorNombre">El nombre es obligatorio</span>
            </div>

            <div class="form-group">
                <label>Apellido <span class="required">*</span></label>
                <asp:TextBox ID="txtApellido" runat="server" CssClass="form-control" placeholder="Ingrese el apellido"></asp:TextBox>
                <span class="error-message" id="errorApellido">El apellido es obligatorio</span>
            </div>
        </div>

        <!-- Fila 2: DNI y Licencia -->
        <div class="form-row">
            <div class="form-group">
                <label>DNI <span class="required">*</span></label>
                <asp:TextBox ID="txtDNI" runat="server" CssClass="form-control" placeholder="Ingrese el DNI (8 dígitos)" MaxLength="8"></asp:TextBox>
                <span class="error-message" id="errorDNI">El DNI debe tener 8 dígitos</span>
            </div>

            <div class="form-group">
                <label>N° Licencia <span class="required">*</span></label>
                <asp:TextBox ID="txtLicencia" runat="server" CssClass="form-control" placeholder="Ingrese el número de licencia"></asp:TextBox>
                <span class="error-message" id="errorLicencia">El número de licencia es obligatorio</span>
            </div>
        </div>

        <!-- Fila 3: Correo y ID Empresa -->
        <div class="form-row">
            <div class="form-group">
                <label>Correo Electrónico <span class="required">*</span></label>
                <asp:TextBox ID="txtCorreo" runat="server" CssClass="form-control" placeholder="ejemplo@correo.com"></asp:TextBox>
                <span class="error-message" id="errorCorreo">Ingrese un correo válido</span>
            </div>

            <div class="form-group">
                <label>ID Empresa <span class="required">*</span></label>
                <asp:DropDownList ID="ddlEmpresa" runat="server" CssClass="form-select">
                    <asp:ListItem Text="Seleccione una empresa" Value="" Selected="True"></asp:ListItem>
                    <asp:ListItem Text="Empresa 1" Value="1"></asp:ListItem>
                    <asp:ListItem Text="Empresa 2" Value="2"></asp:ListItem>
                </asp:DropDownList>
                <span class="error-message" id="errorEmpresa">Debe seleccionar una empresa</span>
            </div>
        </div>

        <!-- Fila 4: Contraseña -->
        <div class="form-row">
            <div class="form-group">
                <label>Contraseña <span class="required">*</span></label>
                <div class="password-toggle">
                    <asp:TextBox ID="txtContrasena" runat="server" TextMode="Password" CssClass="form-control" placeholder="Ingrese la contraseña"></asp:TextBox>
                    <button type="button" class="password-toggle-btn" onclick="togglePassword('txtContrasena', this)">
                        <i class="fa-solid fa-eye"></i>
                    </button>
                </div>
                <span class="error-message" id="errorContrasena">La contraseña debe tener al menos 8 caracteres</span>
            </div>

            <div class="form-group">
                <label>Confirmar Contraseña <span class="required">*</span></label>
                <div class="password-toggle">
                    <asp:TextBox ID="txtConfirmarContrasena" runat="server" TextMode="Password" CssClass="form-control" placeholder="Confirme la contraseña"></asp:TextBox>
                    <button type="button" class="password-toggle-btn" onclick="togglePassword('txtConfirmarContrasena', this)">
                        <i class="fa-solid fa-eye"></i>
                    </button>
                </div>
                <span class="error-message" id="errorConfirmar">Las contraseñas no coinciden</span>
            </div>
        </div>

        <!-- Botones de acción -->
        <div class="form-actions">
            <asp:LinkButton ID="btnRegistrar" runat="server" CssClass="btn btn-primary" OnClientClick="return validarFormulario();">
                <i class="fa-solid fa-save"></i> Registrar Conductor
            </asp:LinkButton>
            <a href="GestionConductores.aspx" class="btn btn-secondary">
                <i class="fa-solid fa-times"></i> Cancelar
            </a>
        </div>

    </div>

    <script>
        // Validar solo números en DNI
        document.getElementById('<%= txtDNI.ClientID %>').addEventListener('input', function (e) {
            this.value = this.value.replace(/[^0-9]/g, '');
        });

        // Validar solo letras en nombre y apellido
        document.getElementById('<%= txtNombre.ClientID %>').addEventListener('input', function (e) {
            this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
        });

        document.getElementById('<%= txtApellido.ClientID %>').addEventListener('input', function (e) {
            this.value = this.value.replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, '');
        });

        // Toggle password visibility
        function togglePassword(fieldId, btn) {
            var field = document.getElementById('<%= txtContrasena.ClientID %>');
            if (fieldId === 'txtConfirmarContrasena') {
                field = document.getElementById('<%= txtConfirmarContrasena.ClientID %>');
            }

            var icon = btn.querySelector('i');

            if (field.type === 'password') {
                field.type = 'text';
                icon.classList.remove('fa-eye');
                icon.classList.add('fa-eye-slash');
            } else {
                field.type = 'password';
                icon.classList.remove('fa-eye-slash');
                icon.classList.add('fa-eye');
            }
        }

        // Validar formulario
        function validarFormulario() {
            var isValid = true;

            // Limpiar errores previos
            document.querySelectorAll('.error-message').forEach(function (el) {
                el.classList.remove('show');
            });
            document.querySelectorAll('.form-control, .form-select').forEach(function (el) {
                el.classList.remove('error');
            });

            // Validar Nombre
            var nombre = document.getElementById('<%= txtNombre.ClientID %>');
            if (nombre.value.trim() === '') {
                nombre.classList.add('error');
                document.getElementById('errorNombre').classList.add('show');
                isValid = false;
            }

            // Validar Apellido
            var apellido = document.getElementById('<%= txtApellido.ClientID %>');
            if (apellido.value.trim() === '') {
                apellido.classList.add('error');
                document.getElementById('errorApellido').classList.add('show');
                isValid = false;
            }

            // Validar DNI
            var dni = document.getElementById('<%= txtDNI.ClientID %>');
            if (dni.value.length !== 8) {
                dni.classList.add('error');
                document.getElementById('errorDNI').classList.add('show');
                isValid = false;
            }

            // Validar Licencia
            var licencia = document.getElementById('<%= txtLicencia.ClientID %>');
            if (licencia.value.trim() === '') {
                licencia.classList.add('error');
                document.getElementById('errorLicencia').classList.add('show');
                isValid = false;
            }

            // Validar Correo
            var correo = document.getElementById('<%= txtCorreo.ClientID %>');
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            if (!emailRegex.test(correo.value)) {
                correo.classList.add('error');
                document.getElementById('errorCorreo').classList.add('show');
                isValid = false;
            }

            // Validar Empresa
            var empresa = document.getElementById('<%= ddlEmpresa.ClientID %>');
            if (empresa.value === '') {
                empresa.classList.add('error');
                document.getElementById('errorEmpresa').classList.add('show');
                isValid = false;
            }

            // Validar Contraseña
            var contrasena = document.getElementById('<%= txtContrasena.ClientID %>');
            if (contrasena.value.length < 8) {
                contrasena.classList.add('error');
                document.getElementById('errorContrasena').classList.add('show');
                isValid = false;
            }

            // Validar Confirmación
            var confirmar = document.getElementById('<%= txtConfirmarContrasena.ClientID %>');
            if (confirmar.value !== contrasena.value) {
                confirmar.classList.add('error');
                document.getElementById('errorConfirmar').classList.add('show');
                isValid = false;
            }

            if (!isValid) {
                alert('Por favor, complete correctamente todos los campos obligatorios');
            }

            return isValid;
        }
    </script>

</asp:Content>
