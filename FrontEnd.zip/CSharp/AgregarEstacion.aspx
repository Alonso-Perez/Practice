﻿<%@ Page Title="Agregar Estación" Language="C#" MasterPageFile="~/GoutuAdminTransporte.Master" AutoEventWireup="true" CodeBehind="AgregarEstacion.aspx.cs" Inherits="GoutuWA.AgregarEstacion" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Agregar Estación - Administrador
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
 
  <style>
        .fila-inputs {
            display: flex; 
            gap: 15px; 
            align-items: end; 
            flex-wrap: wrap; 
            margin-bottom: 20px;
        }
        
        .grupo-input {
            flex: 1;
        }
        
        .label-input {
            display: block; 
            color: #333; 
            font-weight: 600; 
            margin-bottom: 8px; 
            font-size: 14px;
        }
        
        .form-control-grande {
            padding: 14px 15px; 
            font-size: 12px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            background: white;
            transition: all 0.3s ease;
            width: 100%;
            box-sizing: border-box;
        }
        
        .form-control-grande:disabled {
            background-color: #f5f5f5;
            border-color: #d0d0d0;
            color: #666;
        }
        
        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 25px;
        }
        
        .checkbox-estado {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }
        
        .checkbox-label {
            font-weight: 600;
            color: #333;
            cursor: pointer;
        }
        
   .custom-table {
    width: 100%;
    border-collapse: collapse;
}

.custom-table thead {
    background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
    color: white;
}

.custom-table th {
    padding: 15px;
    text-align: left;
    font-weight: 600;
    font-size: 14px;
}

.custom-table td {
    padding: 15px;
    border-bottom: 1px solid #e0e0e0;
    font-size: 14px;
}

.custom-table tbody tr:hover {
    background-color: #f8f9fa;
}
.btn-primary {
    background-color: white;
    border: 2px solid #5e2a84;
    color: #5e2a84;
}
/* Botón base - estilo general */
.btn-custom {
    background-color: #5e2a84;      
    border: 2px solid #5e2a84;     
    color: white;                   
    padding: 12px 20px;
    border-radius: 8px;
    text-decoration: none;
    display: inline-block;
    font-weight: 600;
    transition: all 0.3s ease;
    cursor: pointer;
}

.btn-custom:hover {
    background-color: #4a1f63;        
    border-color: #4a1f63;            
    color: white;                    
}

/* Botón primario - color morado (#5e2a84) */
.btn-primary {
    background-color: #5e2a84;
    border-color: #5e2a84;
    color: white;
}

.btn-primary:hover {
    background-color: #4a1f63;
    border-color: #4a1f63;
    color: white;
}

/* Botón peligro - color rojo oscuro (#b22222) */
.btn-danger {
    background-color: #b22222;
    border-color: #b22222;
    color: white;
}

.btn-danger:hover {
    background-color: #8b1a1a;
    border-color: #8b1a1a;
    color: white;
}

/* Botón azul - color azul (#1e90ff) */
.btn-info {
    background-color: #1e90ff;
    border-color: #1e90ff;
    color: white;
}

.btn-info:hover {
    background-color: #0066cc;
    border-color: #0066cc;
    color: white;
}
.alert {
    padding: 15px 20px;
    border-radius: 10px;
    margin-bottom: 20px;
    font-weight: 500;
    border-left: 4px solid;
}

.alert-success {
    background-color: #d4edda;
    color: #155724;
    border-left-color: #28a745;
}

.alert-error {
    background-color: #f8d7da;
    color: #721c24;
    border-left-color: #dc3545;
}
.btn-warning {
    background-color: #ffc107;
    border-color: #ffc107;
    color: #212529;
}
.btn-warning:hover {
    background-color: #e0a800;
    border-color: #e0a800;
    color: #212529;
}

.btn-success {
    background-color: #28a745;
    border-color: #28a745;
    color: white;
}
.btn-success:hover {
    background-color: #218838;
    border-color: #218838;
    color: white;
}

.btn-secondary {
    background-color: #6c757d;
    border-color: #6c757d;
    color: white;
}
.btn-secondary:hover {
    background-color: #545b62;
    border-color: #545b62;
    color: white;
}

    </style>
 
<script type="text/javascript">
    function confirmarEliminacion() {
        return confirm('¿Está seguro de que desea eliminar esta estación de la ruta?');
    }
</script>

</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
 
    <!-- Mensajes -->
<asp:Panel ID="pnlMensaje" runat="server" Visible="false">
    <div id="divMensaje" runat="server" class="alert">
        <asp:Label ID="lblMensaje" runat="server"></asp:Label>
    </div>
</asp:Panel>


    <!-- card para poner una nueva estacion -->
    <div style="border: 1px solid #ccc; padding: 20px; margin: 10px; background: white; border-radius: 20px;">
        <h3>Información de la Ruta</h3>
        <p>ID Ruta: <asp:Label ID="lblIdRuta" runat="server" Text="-" /></p>
        <p>ID Servicio: <asp:Label ID="lblNombreServicio" runat="server" Text="-" /></p>
    </div>

    <div style="border: 1px solid #ccc; padding: 20px; margin: 10px; background: white; border-radius: 20px;">
        <!-- Fila con 3 elementos -->
        <div class="fila-inputs">
            <div class="grupo-input" style="min-width: 25%;">
                <label class="label-input"><i class="fa-solid fa-location-crosshairs"></i>Estacion</label>
                <asp:DropDownList ID="ddlEstaciones" runat="server" CssClass="form-control-grande">
                </asp:DropDownList>
            </div>
            <div class="grupo-input" style="min-width: 25%;">
                <label class="label-input"><i class="fa-solid fa-arrows-up-down-left-right"></i>Posicion</label>
                <asp:TextBox ID="txtPosicion" runat="server" CssClass="form-control-grande" placeholder="Ubicacion de Estacion" />
            </div>
            <div class="grupo-input" style="min-width: 20%;">
                <!-- Checkbox para estado activo (oculto inicialmente) -->
                <div id="divEstadoActivo" runat="server" class="checkbox-container" style="display: none;">
                    <asp:CheckBox ID="chkActivo" runat="server" CssClass="checkbox-estado" />
                    <label for="<%= chkActivo.ClientID %>" class="checkbox-label">Activo</label>
                </div>
            </div>
            <div class="grupo-input" style="min-width: 25%;">
                <!-- Botón Registrar (visible por defecto) -->
                <asp:LinkButton ID="btnGuardar" runat="server" CssClass="btn-custom btn-primary" OnClick="btnGuardar_Click">
                    <i class="fa-solid fa-floppy-disk"></i> Registrar
                </asp:LinkButton>
                
                <!-- Botón Confirmar Edición (oculto inicialmente) -->
                <asp:LinkButton ID="btnConfirmarEdicion" runat="server" CssClass="btn-custom btn-success" OnClick="btnConfirmarEdicion_Click" Visible="false">
                    <i class="fa-solid fa-check"></i> Confirmar Edición
                </asp:LinkButton>
                
                <!-- Botón Cancelar Edición (oculto inicialmente) -->
                <asp:LinkButton ID="btnCancelarEdicion" runat="server" CssClass="btn-custom btn-secondary" OnClick="btnCancelarEdicion_Click" Visible="false">
                    <i class="fa-solid fa-times"></i> Cancelar
                </asp:LinkButton>
            </div>
        </div>
    </div>

    <!-- card para mostrar la lista de estaciones-->
    <div style="border: 1px solid #ccc; padding: 20px; margin: 10px; background: white; border-radius: 20px;">
        <h3>LISTA DE ESTACIONES</h3>
        <!-- Tabla -->
        <div class="table-container">
            <div class="form-title"><i class="fa-solid fa-list"></i>Lista de Estaciones</div>

            <asp:GridView ID="gvEstaciones" runat="server" CssClass="custom-table"
                AutoGenerateColumns="False" DataKeyNames="lblid_Estacion"
                EmptyDataText="No hay estaciones registradas" OnRowCommand="gvEstaciones_RowCommand">

                <Columns>
                    <asp:BoundField DataField="lblid_Estacion" HeaderText="ID" />
                    <asp:BoundField DataField="lbl_NombreEstacion" HeaderText="Nombre" />
                    <asp:BoundField DataField="lblPosicion" HeaderText="Posición" />
                    <asp:BoundField DataField="lblEstadoActivo" HeaderText="Estado" />

                    <asp:TemplateField HeaderText="Acciones" ItemStyle-HorizontalAlign="Center" HeaderStyle-HorizontalAlign="Center">
                        <ItemTemplate>
                            <div style="text-align: center; white-space: nowrap;">
                                <asp:Button ID="btnEditar" runat="server"
                                    Text="Editar"
                                    CssClass="btn-custom btn-warning"
                                    CommandName="Editar"
                                    CommandArgument='<%# Eval("lblid_Estacion") + "|" + Eval("lblPosicion") + "|" + Eval("lblEstadoActivo") %>'
                                    CausesValidation="false"
                                    UseSubmitBehavior="false" />

                                <asp:Button ID="btnEliminar" runat="server"
                                    Text="Eliminar"
                                    CssClass="btn-custom btn-danger"
                                    CommandName="Eliminar"
                                    CommandArgument='<%# Eval("lblid_Estacion") %>'
                                  
                                    CausesValidation="false"
                                    UseSubmitBehavior="false" />
                            </div>
                        </ItemTemplate>
                    </asp:TemplateField>
                </Columns>
            </asp:GridView>
        </div>
    </div>
</asp:Content>