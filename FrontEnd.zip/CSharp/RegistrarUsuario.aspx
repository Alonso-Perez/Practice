﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuMaster.Master" AutoEventWireup="true" CodeBehind="RegistrarUsuario.aspx.cs"  Inherits="GoutuWA.RegistrarUsuario" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Registro - Goutu
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script src="Scripts/bootstrap.min.js"></script>
    <script src="Scripts/GoutuProg/RegistrarUsuario.js"></script>
    
    <style>
        .registro-container {
            max-width: 1200px;
            margin: 0 auto;
            padding: 40px 20px;
        }

        .registro-titulo {
            text-align: center;
            margin-bottom: 50px;
        }

        .registro-titulo h5 {
            font-size: 60px;
            display: inline;
            margin: 0;
        }

        .registro-titulo .goutu {
            color: #4b0082;
        }

        .form-row {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 30px;
            margin-bottom: 25px;
        }

        .form-row.full-width {
            grid-template-columns: 1fr;
        }

        .form-group {
            display: flex;
            flex-direction: column;
            gap: 8px;
        }

        .form-group label {
            font-weight: 500;
            color: #333;
            font-size: 14px;
        }

        .form-group .required::after {
            content: " *";
            color: #dc3545;
        }

        .form-control {
            padding: 12px 15px;
            border: 1px solid #ddd;
            border-radius: 8px;
            font-size: 15px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            border-color: #4b0082;
            box-shadow: 0 0 0 0.2rem rgba(75, 0, 130, 0.15);
            outline: none;
        }

        .documento-group {
            display: grid;
            grid-template-columns: 1fr auto;
            gap: 10px;
        }

        .tipo-documento-wrapper {
            position: relative;
            width: 140px;
        }

        .tipo-documento-wrapper select {
            appearance: none;
            -webkit-appearance: none;
            -moz-appearance: none;
            padding-right: 35px;
            cursor: pointer;
        }

        .tipo-documento-wrapper::after {
            content: "▼";
            position: absolute;
            right: 15px;
            top: 50%;
            transform: translateY(-50%);
            pointer-events: none;
            color: #666;
            font-size: 12px;
        }

        .validation-message {
            color: #dc3545;
            font-size: 13px;
            margin-top: 5px;
            display: none;
        }

        .validation-message.show {
            display: block;
        }

        .input-error {
            border-color: #dc3545 !important;
        }

        .password-strength {
            height: 4px;
            background-color: #e0e0e0;
            border-radius: 2px;
            margin-top: 5px;
            overflow: hidden;
        }

        .password-strength-bar {
            height: 100%;
            width: 0;
            transition: all 0.3s ease;
        }

        .password-strength-bar.weak {
            width: 33%;
            background-color: #dc3545;
        }

        .password-strength-bar.medium {
            width: 66%;
            background-color: #ffc107;
        }

        .password-strength-bar.strong {
            width: 100%;
            background-color: #28a745;
        }

        .password-requirements {
            font-size: 12px;
            color: #666;
            margin-top: 8px;
            line-height: 1.6;
        }

        .password-requirements .requirement {
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .password-requirements .requirement.met {
            color: #28a745;
        }

        .password-requirements .requirement::before {
            content: "○";
        }

        .password-requirements .requirement.met::before {
            content: "✓";
        }

        .terminos-box {
            background-color: #f8f9fa;
            padding: 20px;
            border-radius: 8px;
            margin: 30px 0;
        }

        .form-check {
            display: flex;
            align-items: center;
            gap: 10px;
        }

        .form-check-input {
            width: 20px;
            height: 20px;
            cursor: pointer;
            border: 2px solid #ddd;
            border-radius: 4px;
            box-shadow: none !important;
            outline: none !important;
        }

        .form-check-input:checked {
            background-color: #4b0082;
            border-color: #4b0082;
            box-shadow: none !important;
        }

        .form-check-input:focus {
            border-color: #4b0082;
            box-shadow: none !important;
            outline: none !important;
        }

        .form-check-label {
            font-size: 14px;
            color: #555;
            margin: 0;
        }

        .form-check-label a {
            color: #4b0082;
            text-decoration: none;
            font-weight: 500;
        }

        .form-check-label a:hover {
            text-decoration: underline;
        }

        .btn-registrar {
            background-color: #4b0082;
            color: white;
            padding: 15px 60px;
            font-size: 18px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-registrar:hover {
            background-color: #3a0066;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(75, 0, 130, 0.3);
            color: white;
        }

        .btn-registrar:disabled {
            background-color: #ccc;
            cursor: not-allowed;
            transform: none;
        }

        .btn-container {
            text-align: center;
            margin-top: 40px;
        }

        .modal-body {
            padding: 30px;
        }

        .terminos-content h6 {
            color: #4b0082;
            margin-top: 20px;
            margin-bottom: 10px;
            font-weight: 600;
        }

        .terminos-content p, .terminos-content ul {
            color: #555;
            text-align: justify;
        }

        .terminos-content ul {
            padding-left: 25px;
        }

        @media (max-width: 768px) {
            .form-row {
                grid-template-columns: 1fr;
                gap: 20px;
            }

            .registro-titulo h5 {
                font-size: 40px;
            }

            .documento-group {
                grid-template-columns: 1fr;
            }

            .tipo-documento-wrapper {
                width: 100%;
            }
        }
    </style>

    <script type="text/javascript">
        // Validación en tiempo real
        $(document).ready(function () {
            // Validación de nombre (solo letras y espacios)
            $('#<%= txtNombre.ClientID %>').on('input', function () {
                var regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/;
                if (!regex.test($(this).val())) {
                    $(this).val($(this).val().replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, ''));
                }
            });

            // Validación de apellido
            // Validación apellido paterno
            $('#<%= txtApellidoPaterno.ClientID %>').on('input', function () {
    var regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/;
    if (!regex.test($(this).val())) {
        $(this).val($(this).val().replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, ''));
    }
});

// Validación apellido materno
            $('#<%= txtApellidoMaterno.ClientID %>').on('input', function () {
                var regex = /^[a-zA-ZáéíóúÁÉÍÓÚñÑ\s]*$/;
                if (!regex.test($(this).val())) {
                    $(this).val($(this).val().replace(/[^a-zA-ZáéíóúÁÉÍÓÚñÑ\s]/g, ''));
                }
            });

            // Validación de DNI (solo números)
            $('#<%= txtDNI.ClientID %>').on('input', function () {
                var tipo = $('#<%= ddlTipoDocumento.ClientID %>').val();
                var maxLength = tipo === 'DNI' ? 8 : 12;

                $(this).val($(this).val().replace(/[^0-9]/g, ''));

                if ($(this).val().length > maxLength) {
                    $(this).val($(this).val().substring(0, maxLength));
                }
            });

            // Validación de teléfono (solo números y máximo 9 dígitos)
            $('#<%= txtTelefono.ClientID %>').on('input', function () {
                $(this).val($(this).val().replace(/[^0-9]/g, ''));
                if ($(this).val().length > 9) {
                    $(this).val($(this).val().substring(0, 9));
                }
            });

            // Validación de correo electrónico
            $('#<%= txtCorreo.ClientID %>').on('blur', function () {
                var email = $(this).val();
                var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (email && !regex.test(email)) {
                    $(this).addClass('input-error');
                    $(this).after('<span class="validation-message show">Ingrese un correo válido</span>');
                } else {
                    $(this).removeClass('input-error');
                    $(this).next('.validation-message').remove();
                }
            });

            // Validación de contraseña
            $('#<%= txtContrasena.ClientID %>').on('input', function () {
                var password = $(this).val();
                var strength = checkPasswordStrength(password);

                // Actualizar barra de fortaleza
                var $bar = $('.password-strength-bar');
                $bar.removeClass('weak medium strong');

                if (password.length > 0) {
                    if (strength >= 4) {
                        $bar.addClass('strong');
                    } else if (strength >= 2) {
                        $bar.addClass('medium');
                    } else {
                        $bar.addClass('weak');
                    }
                } else {
                    $bar.css('width', '0');
                }

                // Actualizar requisitos
                updatePasswordRequirements(password);
            });

            // Verificar coincidencia de contraseñas
            $('#<%= txtConfirmarContrasena.ClientID %>').on('input', function () {
                var password = $('#<%= txtContrasena.ClientID %>').val();
                var confirmPassword = $(this).val();

                if (confirmPassword.length > 0) {
                    if (password !== confirmPassword) {
                        $(this).addClass('input-error');
                        $(this).siblings('.validation-message').remove();
                        $(this).after('<span class="validation-message show">Las contraseñas no coinciden</span>');
                    } else {
                        $(this).removeClass('input-error');
                        $(this).siblings('.validation-message').remove();
                        $(this).after('<span class="validation-message show" style="color: #28a745;">Las contraseñas coinciden</span>');
                    }
                }
            });

            // Cambio de tipo de documento
            $('#<%= ddlTipoDocumento.ClientID %>').on('change', function () {
                var tipo = $(this).val();
                var $dni = $('#<%= txtDNI.ClientID %>');

                if (tipo === 'DNI') {
                    $dni.attr('placeholder', 'Ingrese 8 dígitos');
                    $dni.attr('maxlength', '8');
                } else {
                    $dni.attr('placeholder', 'Ingrese número de documento');
                    $dni.attr('maxlength', '12');
                }

                $dni.val('');
            });
        });

        function checkPasswordStrength(password) {
            var strength = 0;

            if (password.length >= 8) strength++;
            if (password.length >= 12) strength++;
            if (/[a-z]/.test(password) && /[A-Z]/.test(password)) strength++;
            if (/\d/.test(password)) strength++;
            if (/[^a-zA-Z\d]/.test(password)) strength++;

            return strength;
        }

        function updatePasswordRequirements(password) {
            $('.req-length').toggleClass('met', password.length >= 8);
            $('.req-upper').toggleClass('met', /[A-Z]/.test(password));
            $('.req-lower').toggleClass('met', /[a-z]/.test(password));
            $('.req-number').toggleClass('met', /\d/.test(password));
            $('.req-special').toggleClass('met', /[^a-zA-Z\d]/.test(password));
        }

        function validarFormulario() {
            var isValid = true;
            $('.validation-message').remove();
            $('.input-error').removeClass('input-error');

            // Validar nombre
            if ($('#<%= txtNombre.ClientID %>').val().trim() === '') {
                $('#<%= txtNombre.ClientID %>').addClass('input-error');
                $('#<%= txtNombre.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            }

            // Validar apellido paterno
            if ($('#<%= txtApellidoPaterno.ClientID %>').val().trim() === '') {
                $('#<%= txtApellidoPaterno.ClientID %>').addClass('input-error');
    $('#<%= txtApellidoPaterno.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
    isValid = false;
}

// Validar apellido materno
if ($('#<%= txtApellidoMaterno.ClientID %>').val().trim() === '') {
    $('#<%= txtApellidoMaterno.ClientID %>').addClass('input-error');
    $('#<%= txtApellidoMaterno.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
    isValid = false;
}   

            // Validar DNI
            var dni = $('#<%= txtDNI.ClientID %>').val();
            var tipoDni = $('#<%= ddlTipoDocumento.ClientID %>').val();

            if (dni.trim() === '') {
                $('#<%= txtDNI.ClientID %>').addClass('input-error');
                $('#<%= txtDNI.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            } else if (tipoDni === 'DNI' && dni.length !== 8) {
                $('#<%= txtDNI.ClientID %>').addClass('input-error');
                $('#<%= txtDNI.ClientID %>').after('<span class="validation-message show">El DNI debe tener 8 dígitos</span>');
                isValid = false;
            }

            // Validar teléfono
            var telefono = $('#<%= txtTelefono.ClientID %>').val();
            if (telefono.trim() === '') {
                $('#<%= txtTelefono.ClientID %>').addClass('input-error');
                $('#<%= txtTelefono.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            } else if (telefono.length !== 9) {
                $('#<%= txtTelefono.ClientID %>').addClass('input-error');
                $('#<%= txtTelefono.ClientID %>').after('<span class="validation-message show">El teléfono debe tener 9 dígitos</span>');
                isValid = false;
            }

            // Validar correo
            var email = $('#<%= txtCorreo.ClientID %>').val();
            var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
            
            if (email.trim() === '') {
                $('#<%= txtCorreo.ClientID %>').addClass('input-error');
                $('#<%= txtCorreo.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            } else if (!emailRegex.test(email)) {
                $('#<%= txtCorreo.ClientID %>').addClass('input-error');
                $('#<%= txtCorreo.ClientID %>').after('<span class="validation-message show">Ingrese un correo válido</span>');
                isValid = false;
            }

            // Validar dirección
            var direccion = $('#<%= txtDireccion.ClientID %>').val();
            if (direccion.trim() === '') {
                $('#<%= txtDireccion.ClientID %>').addClass('input-error');
                $('#<%= txtDireccion.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            } else if (direccion.trim().length < 10) {
                $('#<%= txtDireccion.ClientID %>').addClass('input-error');
                $('#<%= txtDireccion.ClientID %>').after('<span class="validation-message show">Ingrese una dirección más detallada</span>');
                isValid = false;
            }

            // Validar contraseña
            var password = $('#<%= txtContrasena.ClientID %>').val();
            if (password.trim() === '') {
                $('#<%= txtContrasena.ClientID %>').addClass('input-error');
                $('#<%= txtContrasena.ClientID %>').after('<span class="validation-message show">Este campo es obligatorio</span>');
                isValid = false;
            } else if (password.length < 8) {
                $('#<%= txtContrasena.ClientID %>').addClass('input-error');
                $('#<%= txtContrasena.ClientID %>').after('<span class="validation-message show">La contraseña debe tener al menos 8 caracteres</span>');
                isValid = false;
            }

            // Validar confirmación de contraseña
            var confirmPassword = $('#<%= txtConfirmarContrasena.ClientID %>').val();
            if (confirmPassword !== password) {
                $('#<%= txtConfirmarContrasena.ClientID %>').addClass('input-error');
                $('#<%= txtConfirmarContrasena.ClientID %>').after('<span class="validation-message show">Las contraseñas no coinciden</span>');
                isValid = false;
            }

            // Validar términos y condiciones
            if (!$('#<%= chkTerminos.ClientID %>').is(':checked')) {
                $('.terminos-box').css('border', '2px solid #dc3545');
                $('.terminos-box').append('<span class="validation-message show">Debe aceptar los términos y condiciones</span>');
                isValid = false;
            }

            if (!isValid) {
                $('html, body').animate({
                    scrollTop: $('.input-error:first').offset().top - 100
                }, 500);
            }

            return isValid;
        }

        function mostrarModalTerminosYcondiciones() {
            return false;
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="registro-container">
        <!-- Título -->
        <div class="registro-titulo">
            <h5>¡Regístrate a </h5>
            <h5 class="goutu">Goutu!</h5>
        </div>
    </div>

        <!-- Formulario -->
        <div class="form-row">
            
    <!-- Nombres -->
    <div class="form-group">
        <asp:Label ID="Label9" runat="server" CssClass="required">Nombres</asp:Label>
        <asp:TextBox ID="txtNombre" runat="server" CssClass="form-control" placeholder="Ingrese sus nombres"></asp:TextBox>
    </div>

    <!-- Apellido Paterno -->
    <div class="form-group">
        <asp:Label ID="Label11" runat="server" CssClass="required">Apellido Paterno</asp:Label>
        <asp:TextBox ID="txtApellidoPaterno" runat="server" CssClass="form-control" placeholder="Ingrese su apellido paterno"></asp:TextBox>
    </div>
</div>

<div class="form-row">
    <!-- Apellido Materno -->
    <div class="form-group">
        <asp:Label ID="Label12" runat="server" CssClass="required">Apellido Materno</asp:Label>
        <asp:TextBox ID="txtApellidoMaterno" runat="server" CssClass="form-control" placeholder="Ingrese su apellido materno"></asp:TextBox>
    </div>


        <div class="form-row">
            <!-- Documento -->
            <div class="form-group">
                <asp:Label ID="Label4" runat="server" CssClass="required">Documento de Identidad</asp:Label>
                <div class="documento-group">
                    <asp:TextBox ID="txtDNI" runat="server" CssClass="form-control" placeholder="Ingrese 8 dígitos" MaxLength="8"></asp:TextBox>
                    <div class="tipo-documento-wrapper">
                        <asp:DropDownList ID="ddlTipoDocumento" runat="server" CssClass="form-control">
                            <asp:ListItem Text="DNI" Value="DNI" Selected="True"></asp:ListItem>
                            <asp:ListItem Text="CE" Value="CE"></asp:ListItem>
                        </asp:DropDownList>
                    </div>
                </div>
            </div>

            <!-- Teléfono -->
            <div class="form-group">
                <asp:Label ID="Label5" runat="server" CssClass="required">Teléfono</asp:Label>
                <asp:TextBox ID="txtTelefono" runat="server" CssClass="form-control" placeholder="Ingrese su número de teléfono" MaxLength="9"></asp:TextBox>
            </div>
        </div>

        <div class="form-row">
            <!-- Correo -->
            <div class="form-group">
                <asp:Label ID="Label6" runat="server" CssClass="required">Correo Electrónico</asp:Label>
                <asp:TextBox ID="txtCorreo" runat="server" CssClass="form-control" placeholder="ejemplo@correo.com"></asp:TextBox>
            </div>

            <!-- Dirección de Domicilio -->
            <div class="form-group">
                <asp:Label ID="lblDireccion" runat="server" CssClass="required">Dirección de Domicilio</asp:Label>
                <asp:TextBox ID="txtDireccion" runat="server" CssClass="form-control" placeholder="Ingrese su dirección completa"></asp:TextBox>
            </div>
        </div>

        <div class="form-row">
            <!-- Contraseña -->
            <div class="form-group">
                <asp:Label ID="Label7" runat="server" CssClass="required">Contraseña</asp:Label>
                <asp:TextBox ID="txtContrasena" runat="server" CssClass="form-control" TextMode="Password" placeholder="Ingrese su contraseña"></asp:TextBox>
                <div class="password-strength">
                    <div class="password-strength-bar"></div>
                </div>
                <div class="password-requirements">
                    <div class="requirement req-length">Mínimo 8 caracteres</div>
                    <div class="requirement req-upper">Una letra mayúscula</div>
                    <div class="requirement req-lower">Una letra minúscula</div>
                    <div class="requirement req-number">Un número</div>
                    <div class="requirement req-special">Un carácter especial (!@#$%^&*)</div>
                </div>
            </div>

            <!-- Verificar Contraseña -->
            <div class="form-group">
                <asp:Label ID="Label8" runat="server" CssClass="required">Verificar Contraseña</asp:Label>
                <asp:TextBox ID="txtConfirmarContrasena" runat="server" CssClass="form-control" TextMode="Password" placeholder="Vuelva a ingresar su contraseña"></asp:TextBox>
            </div>
        </div>

        <!-- Términos y Condiciones -->
        <div class="terminos-box">
            <div class="form-check">
                <asp:CheckBox ID="chkTerminos" runat="server" CssClass="form-check-input" />
                <label class="form-check-label">
                    Acepto los 
                    <a href="#" data-bs-toggle="modal" data-bs-target="#modalTerminos" onclick="return mostrarModalTerminosYcondiciones();">
                        Términos y Condiciones
                    </a>
                </label>
            </div>
        </div>

        <!-- Botón de Registro -->
        <div class="btn-container">
            <asp:LinkButton ID="btnRegistrar" runat="server" CssClass="btn-registrar" OnClick="btnRegistrar_Click" OnClientClick="return validarFormulario();">
                Registrarse
            </asp:LinkButton>
        </div>
    </div>

    <!-- Modal de Términos y Condiciones -->
    <div class="modal fade" id="modalTerminos" tabindex="-1" aria-labelledby="modalTerminosLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg modal-dialog-scrollable">
            <div class="modal-content">
                <div class="modal-body">
                    <div style="text-align: center; margin-bottom: 20px;">
                        <img src="images/Logo.png" alt="Goutu Logo" style="width: 200px;" />
                    </div>

                    <h5 class="text-center mb-4" style="color: #4b0082; font-weight: 600;">TÉRMINOS Y CONDICIONES</h5>
                    
                    <div class="terminos-content">
                        <h6>1. Introducción</h6>
                        <p>Estos términos y condiciones regulan el uso de datos e información por parte de GouTu. Al acceder y utilizar nuestros servicios, usted acepta cumplir con estos términos y condiciones en su totalidad. Si no está de acuerdo con alguna parte de estos términos, por favor no utilice nuestros servicios.</p>

                        <h6>2. Recopilación de Datos</h6>
                        <p>Recopilamos ciertos datos personales y no personales de nuestros usuarios con el objetivo de mejorar nuestros servicios y proporcionar una experiencia personalizada. Estos datos pueden incluir, entre otros, información de contacto, información demográfica y datos de uso del servicio.</p>

                        <h6>3. Uso de la Información</h6>
                        <p>Utilizamos la información recopilada para:</p>
                        <ul>
                            <li>Personalizar y mejorar nuestros servicios.</li>
                            <li>Enviar comunicaciones relacionadas con el servicio.</li>
                            <li>Analizar tendencias y comportamientos de los usuarios.</li>
                            <li>Cumplir con obligaciones legales y regulatorias.</li>
                        </ul>

                        <h6>4. Seguridad de los Datos</h6>
                        <p>Nos comprometemos a proteger la seguridad de los datos de nuestros usuarios y empleamos medidas adecuadas para salvaguardar la información recopilada. Sin embargo, no podemos garantizar la seguridad absoluta de los datos transmitidos a través de internet.</p>

                        <h6>5. Compartición de Información</h6>
                        <p>Podemos compartir información con terceros proveedores de servicios que nos asisten en la operación de nuestro negocio y la prestación de servicios a nuestros usuarios. Nos aseguramos de que estos terceros cumplan con estándares adecuados de protección de datos.</p>

                        <h6>6. Cookies y Tecnologías Similares</h6>
                        <p>Utilizamos cookies y otras tecnologías similares para mejorar la funcionalidad del sitio web y proporcionar una experiencia más personalizada. Los usuarios pueden controlar el uso de cookies a través de la configuración de su navegador.</p>

                        <h6>7. Cambios en los Términos y Condiciones</h6>
                        <p>Nos reservamos el derecho de modificar estos términos y condiciones en cualquier momento. Los cambios entrarán en vigor al ser publicados en nuestro sitio web. Es responsabilidad del usuario revisar periódicamente estos términos para estar al tanto de cualquier modificación.</p>

                        <h6>8. Consentimiento</h6>
                        <p>Al utilizar nuestros servicios, usted consiente el procesamiento de sus datos personales de acuerdo con estos términos y condiciones.</p>

                        <h6>9. Contacto</h6>
                        <p>Si tiene alguna pregunta sobre estos términos y condiciones, por favor contáctenos a través de GouTu@gmail.com.</p>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <asp:LinkButton ID="cerrarModalTerminos" runat="server" CssClass="btn btn-success" OnClick="cerrarModalTerminos_click">
                        Aceptar
                    </asp:LinkButton>
                </div>
            </div>
        </div>
    </div>
</asp:Content>