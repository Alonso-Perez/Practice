﻿<%@ Page Title="Gestión de Tarjetas" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="GestionTarjetasAdmin.aspx.cs" Inherits="GoutuWA.GestionTarjetasAdmin" %>

<asp:Content ID="cTitle" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Tarjetas - Admin Sistema
</asp:Content>

<asp:Content ID="cScripts" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .admin-header {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .admin-header h2 {
            margin: 0;
            font-weight: 700;
        }

        .card-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .card-section h3 {
            color: #5e2a84;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }

        .form-section {
            margin-bottom: 20px;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(94, 42, 132, 0.3);
        }

        /* Botón para ver todas las tarjetas */
        .btn-view-all {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            padding: 12px 30px;
            font-weight: 600;
            transition: all 0.3s ease;
            color: white;
            text-decoration: none;
            display: inline-block;
            border-radius: 8px;
        }

        .btn-view-all:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(40, 167, 69, 0.3);
            color: white;
        }

        .upload-zone {
            border: 2px dashed #5e2a84;
            border-radius: 10px;
            padding: 40px;
            text-align: center;
            background-color: #f8f9fa;
            transition: all 0.3s ease;
            cursor: pointer;
        }

        .upload-zone:hover {
            background-color: #e9ecef;
            border-color: #4a1f63;
        }

        .upload-zone i {
            font-size: 48px;
            color: #5e2a84;
            margin-bottom: 15px;
        }

        .stats-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.12);
        }

        .stat-card i {
            font-size: 36px;
            margin-bottom: 10px;
        }

        .stat-card.lima-pass i {
            color: #28a745;
        }

        .stat-card.tren i {
            color: #007bff;
        }

        .stat-value {
            font-size: 32px;
            font-weight: 700;
            color: #333;
        }

        .stat-label {
            font-size: 14px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .stat-sub {
            margin-top: 6px;
            font-size: 13px;
            color: #555;
        }

        .stat-sub span.value {
            font-weight: 700;
            margin-left: 3px;
        }

        .alert-custom {
            border-left: 4px solid;
            border-radius: 8px;
        }

        .alert-custom.success {
            border-left-color: #28a745;
            background-color: #d4edda;
        }

        .alert-custom.error {
            border-left-color: #dc3545;
            background-color: #f8d7da;
        }

        .alert-custom.info {
            border-left-color: #17a2b8;
            background-color: #d1ecf1;
        }
    </style>

    <script type="text/javascript">
        function mostrarToast(mensaje, tipo) {
            var toastEl = document.getElementById('toastNotificacion');
            var toastBody = document.getElementById('toastMensaje');

            toastBody.innerText = mensaje;

            toastEl.classList.remove('bg-success', 'bg-danger', 'bg-info');
            if (tipo === 'error') {
                toastEl.classList.add('bg-danger');
            } else if (tipo === 'info') {
                toastEl.classList.add('bg-info');
            } else {
                toastEl.classList.add('bg-success');
            }

            var toast = new bootstrap.Toast(toastEl);
            toast.show();
        }

        function validarFormulario() {
            var tipo = document.getElementById('<%= ddlTipoTarjeta.ClientID %>').value;
            var codigo = document.getElementById('<%= txtCodigo.ClientID %>').value.trim();
            var saldo = document.getElementById('<%= txtSaldo.ClientID %>').value.trim();
            var tarifario = document.getElementById('<%= ddlTarifario.ClientID %>').value;

            if (!tipo || !codigo || !saldo || !tarifario) {
                alert('Por favor complete todos los campos');
                return false;
            }

            if (tipo === 'Lima Pass' && codigo.length !== 10) {
                alert('El código de Lima Pass debe tener exactamente 10 dígitos');
                return false;
            }

            if (tipo === 'Linea 1' && codigo.length !== 8) {
                alert('El código de Linea 1 debe tener exactamente 8 dígitos');
                return false;
            }

            if (!/^\d+$/.test(codigo)) {
                alert('El código debe contener solo números');
                return false;
            }

            return true;
        }

        function validarCSV() {
            var fileInput = document.getElementById('<%= fileCSV.ClientID %>');

            if (!fileInput.files || fileInput.files.length === 0) {
                alert('Por favor seleccione un archivo CSV');
                return false;
            }

            var fileName = fileInput.files[0].name;
            if (!fileName.endsWith('.csv')) {
                alert('El archivo debe ser de tipo CSV');
                return false;
            }

            return true;
        }
    </script>
</asp:Content>

<asp:Content ID="cContenido" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <div class="admin-header">
        <h2><i class="fas fa-credit-card me-3"></i>Gestión de Tarjetas del Sistema</h2>
        <p class="mb-0">Administra las tarjetas disponibles en la plataforma</p>
    </div>

    <!-- Botón para ver todas las tarjetas -->
    <div class="mb-4 text-end">
        <a href="ModificarTarjetasAdmin.aspx" class="btn-view-all">
            <i class="fas fa-list me-2"></i>Ver y Modificar Todas las Tarjetas
        </a>
    </div>

    <!-- Estadísticas -->
    <div class="stats-grid">
        <div class="stat-card lima-pass">
            <i class="fas fa-credit-card"></i>
            <div class="stat-value">
                <asp:Label ID="lblTotalLimaPass" runat="server" Text="0"></asp:Label>
            </div>
            <div class="stat-label">Lima Pass Libres</div>
            <div class="stat-sub">
                Bloqueadas:
                <span class="value">
                    <asp:Label ID="lblLimaPassBloqueadas" runat="server" Text="0"></asp:Label>
                </span>
            </div>
        </div>

        <div class="stat-card tren">
            <i class="fas fa-subway"></i>
            <div class="stat-value">
                <asp:Label ID="lblTotalTren" runat="server" Text="0"></asp:Label>
            </div>
            <div class="stat-label">Linea 1 Libres</div>
            <div class="stat-sub">
                Bloqueadas:
                <span class="value">
                    <asp:Label ID="lblTrenBloqueadas" runat="server" Text="0"></asp:Label>
                </span>
            </div>
        </div>
    </div>

    <!-- Mensajes -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false" CssClass="alert-custom mb-4">
        <asp:Label ID="lblMensaje" runat="server"></asp:Label>
    </asp:Panel>

    <!-- Sección: Agregar Tarjeta Individual -->
    <div class="card-section">
        <h3><i class="fas fa-plus-circle me-2"></i>Agregar Tarjeta Individual</h3>
        
        <div class="row">
            <div class="col-md-6 form-section">
                <label class="form-label">Tipo de Tarjeta <span class="text-danger">*</span></label>
                <asp:DropDownList ID="ddlTipoTarjeta" runat="server" CssClass="form-select">
                    <asp:ListItem Text="-- Seleccione --" Value=""></asp:ListItem>
                    <asp:ListItem Text="Lima Pass (10 dígitos)" Value="Lima Pass"></asp:ListItem>
                    <asp:ListItem Text="Linea 1 (8 dígitos)" Value="Linea 1"></asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="col-md-6 form-section">
                <label class="form-label">Código de Tarjeta <span class="text-danger">*</span></label>
                <asp:TextBox ID="txtCodigo" runat="server" CssClass="form-control" 
                    placeholder="Solo números" MaxLength="10"></asp:TextBox>
            </div>
        </div>

        <div class="row">
            <div class="col-md-6 form-section">
                <label class="form-label">Saldo Inicial <span class="text-danger">*</span></label>
                <asp:TextBox ID="txtSaldo" runat="server" CssClass="form-control" 
                    placeholder="0.00" TextMode="Number" step="0.01"></asp:TextBox>
            </div>

            <div class="col-md-6 form-section">
                <label class="form-label">Tarifario <span class="text-danger">*</span></label>
                <asp:DropDownList ID="ddlTarifario" runat="server" CssClass="form-select">
                    <asp:ListItem Text="-- Seleccione --" Value=""></asp:ListItem>
                    <asp:ListItem Text="Regular" Value="Regular"></asp:ListItem>
                    <asp:ListItem Text="Universitario" Value="Universitario"></asp:ListItem>
                    <asp:ListItem Text="Conadis" Value="Conadis"></asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>

        <div class="mt-4">
            <asp:Button ID="btnAgregarTarjeta" runat="server" Text="Agregar Tarjeta" 
                CssClass="btn btn-primary-custom" OnClientClick="return validarFormulario();"
                OnClick="btnAgregarTarjeta_Click" />
        </div>
    </div>

    <!-- Sección: Carga Masiva desde CSV -->
    <div class="card-section">
        <h3><i class="fas fa-file-upload me-2"></i>Carga Masiva desde CSV</h3>
        
        <div class="alert alert-custom info mb-4">
            <strong><i class="fas fa-info-circle me-2"></i>Formato del archivo CSV:</strong>
            <ul class="mb-0 mt-2">
                <li>Columnas: <code>tipo,codigo,saldo,tarifario</code></li>
                <li>Tipo: "Lima Pass" o "Linea 1"</li>
                <li>Código: 10 dígitos para Lima Pass, 8 dígitos para Linea 1</li>
                <li>Saldo: Número decimal (ej: 50.00)</li>
                <li>Tarifario: "Regular", "Universitario" o "Conadis"</li>
            </ul>
        </div>

        <div class="form-section">
            <label class="form-label">Seleccionar archivo CSV</label>
            <asp:FileUpload ID="fileCSV" runat="server" CssClass="form-control" accept=".csv" />
        </div>

        <div class="mt-4">
            <asp:Button ID="btnCargarCSV" runat="server" Text="Cargar Archivo CSV" 
                CssClass="btn btn-primary-custom" OnClientClick="return validarCSV();"
                OnClick="btnCargarCSV_Click" />
        </div>
    </div>

    <!-- Toast para notificaciones -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="toastNotificacion" class="toast align-items-center text-white border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body" id="toastMensaje"></div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

</asp:Content>