﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="MenuAdminSistemas.aspx.cs" Inherits="GoutuWA.MenuAdminSistemas" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Dashboard - Admin Sistema
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <style>
        .dashboard-header {
            margin-bottom: 30px;
        }

        .dashboard-header h2 {
            color: #4b0082;
            font-weight: 700;
            font-size: 32px;
            margin-bottom: 10px;
        }

        .dashboard-header p {
            color: #666;
            font-size: 16px;
        }

        /* Tarjetas KPI */
        .kpi-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .kpi-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            transition: all 0.3s ease;
            border-left: 4px solid;
        }

        .kpi-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 5px 20px rgba(0, 0, 0, 0.12);
        }

        .kpi-card.clientes {
            border-left-color: #4b0082;
        }

        .kpi-card.conductores {
            border-left-color: #28a745;
        }

        .kpi-card.admins {
            border-left-color: #ff6b6b;
        }

        .kpi-card.tarjetas {
            border-left-color: #ffc107;
        }

        .kpi-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .kpi-icon {
            width: 50px;
            height: 50px;
            border-radius: 12px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .kpi-card.clientes .kpi-icon {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
        }

        .kpi-card.conductores .kpi-icon {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .kpi-card.admins .kpi-icon {
            background: linear-gradient(135deg, #ff6b6b, #ee5a6f);
        }

        .kpi-card.tarjetas .kpi-icon {
            background: linear-gradient(135deg, #ffc107, #ffb300);
        }

        .kpi-title {
            font-size: 14px;
            color: #666;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        .kpi-value {
            font-size: 36px;
            font-weight: 700;
            color: #333;
            margin-bottom: 5px;
        }

        .kpi-trend {
            font-size: 13px;
            color: #28a745;
            display: flex;
            align-items: center;
            gap: 5px;
        }

        .kpi-trend.negative {
            color: #dc3545;
        }

        /* Sección de gráficos */
        .charts-section {
            display: grid;
            grid-template-columns: 2fr 1fr;
            gap: 20px;
            margin-bottom: 30px;
        }

        .chart-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .chart-card h3 {
            color: #333;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        /* Accesos rápidos */
        .quick-actions {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 15px;
            margin-bottom: 30px;
        }

        .quick-action-btn {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #333;
            transition: all 0.3s ease;
            display: flex;
            flex-direction: column;
            align-items: center;
            gap: 10px;
        }

        .quick-action-btn:hover {
            border-color: #4b0082;
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(75, 0, 130, 0.3);
        }

        .quick-action-btn i {
            font-size: 32px;
        }

        .quick-action-btn span {
            font-weight: 600;
            font-size: 14px;
        }

        /* Actividad reciente */
        .activity-section {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 20px;
        }

        .activity-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .activity-card h3 {
            color: #333;
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #f0f0f0;
        }

        .activity-item {
            padding: 12px;
            border-left: 3px solid #4b0082;
            background-color: #f8f9fa;
            border-radius: 8px;
            margin-bottom: 10px;
            transition: all 0.3s ease;
        }

        .activity-item:hover {
            background-color: #e9ecef;
            transform: translateX(5px);
        }

        .activity-item-title {
            font-weight: 600;
            color: #333;
            font-size: 14px;
            margin-bottom: 5px;
        }

        .activity-item-desc {
            font-size: 13px;
            color: #666;
            margin-bottom: 5px;
        }

        .activity-item-time {
            font-size: 12px;
            color: #999;
        }

        /* Sistema Info */
        .system-info {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
            border-radius: 15px;
            padding: 25px;
            margin-top: 30px;
        }

        .system-info h3 {
            font-size: 18px;
            margin-bottom: 15px;
            font-weight: 600;
        }

        .system-info-grid {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
        }

        .system-info-item {
            background: rgba(255, 255, 255, 0.1);
            padding: 15px;
            border-radius: 10px;
            backdrop-filter: blur(10px);
        }

        .system-info-label {
            font-size: 12px;
            opacity: 0.9;
            margin-bottom: 5px;
        }

        .system-info-value {
            font-size: 16px;
            font-weight: 600;
        }

        @media (max-width: 992px) {
            .charts-section {
                grid-template-columns: 1fr;
            }

            .activity-section {
                grid-template-columns: 1fr;
            }
        }

        @media (max-width: 576px) {
            .kpi-container {
                grid-template-columns: 1fr;
            }

            .quick-actions {
                grid-template-columns: 1fr;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <!-- Header del Dashboard -->
    <div class="dashboard-header">
        <h2><i class="fa-solid fa-chart-line"></i> Dashboard Principal</h2>
        <p>Bienvenido al panel de administración del sistema Goutu</p>
    </div>

    <!-- Tarjetas KPI -->
    <div class="kpi-container">
        <div class="kpi-card clientes">
            <div class="kpi-header">
                <div class="kpi-icon">
                    <i class="fa-solid fa-users"></i>
                </div>
            </div>
            <div class="kpi-title">Total Clientes</div>
            <div class="kpi-value">1,248</div>
            <div class="kpi-trend">
                <i class="fa-solid fa-arrow-up"></i>
                <span>+12% este mes</span>
            </div>
        </div>

        <div class="kpi-card conductores">
            <div class="kpi-header">
                <div class="kpi-icon">
                    <i class="fa-solid fa-id-card"></i>
                </div>
            </div>
            <div class="kpi-title">Conductores Activos</div>
            <div class="kpi-value">187</div>
            <div class="kpi-trend">
                <i class="fa-solid fa-arrow-up"></i>
                <span>+8% este mes</span>
            </div>
        </div>

        <div class="kpi-card admins">
            <div class="kpi-header">
                <div class="kpi-icon">
                    <i class="fa-solid fa-user-tie"></i>
                </div>
            </div>
            <div class="kpi-title">Admin Transporte</div>
            <div class="kpi-value">24</div>
            <div class="kpi-trend">
                <i class="fa-solid fa-minus"></i>
                <span>Sin cambios</span>
            </div>
        </div>

        <div class="kpi-card tarjetas">
            <div class="kpi-header">
                <div class="kpi-icon">
                    <i class="fa-solid fa-credit-card"></i>
                </div>
            </div>
            <div class="kpi-title">Tarjetas Vendidas</div>
            <div class="kpi-value">3,542</div>
            <div class="kpi-trend">
                <i class="fa-solid fa-arrow-up"></i>
                <span>+25% este mes</span>
            </div>
        </div>
    </div>

    <!-- Accesos Rápidos -->
    <div class="quick-actions">
        <a href="RegistrarConductor.aspx" class="quick-action-btn">
            <i class="fa-solid fa-user-plus"></i>
            <span>Registrar Conductor</span>
        </a>
        <a href="RegistrarAdminTransporte.aspx" class="quick-action-btn">
            <i class="fa-solid fa-user-tie"></i>
            <span>Registrar Admin</span>
        </a>
        <a href="GestionClientes.aspx" class="quick-action-btn">
            <i class="fa-solid fa-users-cog"></i>
            <span>Gestionar Usuarios</span>
        </a>
        <a href="ReportesAdmin.aspx" class="quick-action-btn">
            <i class="fa-solid fa-file-download"></i>
            <span>Generar Reportes</span>
        </a>
    </div>

    <!-- Sección de Gráficos -->
    <div class="charts-section">
        <div class="chart-card">
            <h3><i class="fa-solid fa-chart-bar"></i> Registros por Mes</h3>
            <canvas id="registrosChart"></canvas>
        </div>

        <div class="chart-card">
            <h3><i class="fa-solid fa-chart-pie"></i> Usuarios por Tipo</h3>
            <canvas id="usuariosChart"></canvas>
        </div>
    </div>

    <!-- Actividad Reciente -->
    <div class="activity-section">
        <div class="activity-card">
            <h3><i class="fa-solid fa-clock"></i> Actividad Reciente</h3>
            
            <div class="activity-item">
                <div class="activity-item-title">Nuevo Cliente Registrado</div>
                <div class="activity-item-desc">Juan Pérez se registró en el sistema</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 5 minutos</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Recarga Realizada</div>
                <div class="activity-item-desc">María García recargó S/ 50.00</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 15 minutos</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Conductor Aprobado</div>
                <div class="activity-item-desc">Carlos Rodríguez - Licencia verificada</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 1 hora</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Nueva Ruta Creada</div>
                <div class="activity-item-desc">Ruta 405: Lima Centro - Callao</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 2 horas</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Tarjeta Bloqueada</div>
                <div class="activity-item-desc">Tarjeta #78542 bloqueada por seguridad</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 3 horas</div>
            </div>
        </div>

        <div class="activity-card">
            <h3><i class="fa-solid fa-bell"></i> Notificaciones del Sistema</h3>
            
            <div class="activity-item">
                <div class="activity-item-title">Mantenimiento Programado</div>
                <div class="activity-item-desc">Sistema estará en mantenimiento el domingo</div>
                <div class="activity-item-time"><i class="fa-regular fa-calendar"></i> 31/10/2025</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Actualización Disponible</div>
                <div class="activity-item-desc">Nueva versión 2.5.0 lista para instalar</div>
                <div class="activity-item-time"><i class="fa-regular fa-calendar"></i> Hoy</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Respaldo Completado</div>
                <div class="activity-item-desc">Base de datos respaldada exitosamente</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 6 horas</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Reportes Mensuales</div>
                <div class="activity-item-desc">Informes de octubre generados</div>
                <div class="activity-item-time"><i class="fa-regular fa-calendar"></i> 30/10/2025</div>
            </div>

            <div class="activity-item">
                <div class="activity-item-title">Nuevo Feedback</div>
                <div class="activity-item-desc">15 nuevas reseñas de usuarios</div>
                <div class="activity-item-time"><i class="fa-regular fa-clock"></i> Hace 8 horas</div>
            </div>
        </div>
    </div>

    <!-- Información del Sistema -->
    <div class="system-info">
        <h3><i class="fa-solid fa-server"></i> Estado del Sistema</h3>
        <div class="system-info-grid">
            <div class="system-info-item">
                <div class="system-info-label">Estado Servidor</div>
                <div class="system-info-value"><i class="fa-solid fa-circle-check"></i> Operativo</div>
            </div>
            <div class="system-info-item">
                <div class="system-info-label">Versión</div>
                <div class="system-info-value">v2.4.1</div>
            </div>
            <div class="system-info-item">
                <div class="system-info-label">Última Actualización</div>
                <div class="system-info-value">15/10/2025</div>
            </div>
            <div class="system-info-item">
                <div class="system-info-label">Uptime</div>
                <div class="system-info-value">99.8%</div>
            </div>
        </div>
    </div>

    <script>
        // Gráfico de Registros por Mes
        const ctxRegistros = document.getElementById('registrosChart').getContext('2d');
        new Chart(ctxRegistros, {
            type: 'line',
            data: {
                labels: ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct'],
                datasets: [{
                    label: 'Clientes',
                    data: [65, 78, 90, 105, 125, 142, 168, 195, 220, 248],
                    borderColor: '#4b0082',
                    backgroundColor: 'rgba(75, 0, 130, 0.1)',
                    tension: 0.4,
                    fill: true
                }, {
                    label: 'Conductores',
                    data: [12, 15, 18, 22, 28, 35, 42, 48, 55, 62],
                    borderColor: '#28a745',
                    backgroundColor: 'rgba(40, 167, 69, 0.1)',
                    tension: 0.4,
                    fill: true
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });

        // Gráfico de Usuarios por Tipo
        const ctxUsuarios = document.getElementById('usuariosChart').getContext('2d');
        new Chart(ctxUsuarios, {
            type: 'doughnut',
            data: {
                labels: ['Clientes', 'Conductores', 'Admin Transporte'],
                datasets: [{
                    data: [1248, 187, 24],
                    backgroundColor: [
                        '#4b0082',
                        '#28a745',
                        '#ff6b6b'
                    ],
                    borderWidth: 0
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: true,
                plugins: {
                    legend: {
                        position: 'bottom'
                    }
                }
            }
        });
    </script>

</asp:Content>

