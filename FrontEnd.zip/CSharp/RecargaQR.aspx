﻿<%@ Page Title="Pagar con Billetera" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="RecargaQR.aspx.cs" Inherits="GoutuWA.RecargaQR" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Pagar con Billetera
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .btn-goutu-primary {
            background-color: #5e2a84;
            border-color: #5e2a84;
            color: white;
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
        }

        .btn-goutu-primary:hover {
            background-color: #4a1f63;
            border-color: #4a1f63;
            color: white;
        }

        .btn-goutu-outline {
            background-color: transparent;
            border: 2px solid #5e2a84;
            color: #5e2a84;
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
            text-align: center;
            text-decoration: none;
            display: block;
        }

        .btn-goutu-outline:hover {
            background-color: #f8f5fb;
            color: #5e2a84;
            text-decoration: none;
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-6">
                <div class="card shadow-sm border-0 text-center" style="border-radius: 15px;">
                    <div class="card-body p-4 p-md-5">
                        <asp:Image ID="imgLogoBilletera" runat="server" style="height: 50px; margin-bottom: 15px;" />
                        <h2 ID="lblTituloQR" runat="server" style="color: #5e2a84; font-weight: 600;"></h2>

                        <p class="lead mt-3">
                            Monto a pagar:
                            <asp:Label ID="lblMontoPagar" runat="server" Text="S/ 0.00" CssClass="h4"
                                style="font-weight: 700; color: #333;"></asp:Label>
                        </p>
                        <p class="text-muted">Escanea el código QR desde tu app.</p>

                        <asp:Image ID="imgQR" runat="server" CssClass="img-fluid my-3"
                            style="max-width: 280px; border-radius: 10px;" />

                        <div class="d-grid gap-3 mt-4">
                            <asp:Button ID="btnConfirmar" runat="server" Text="Confirmar Pago" CssClass="btn-goutu-primary" OnClick="btnConfirmar_Click" />
                            <asp:HyperLink ID="btnVolver" runat="server" Text="Volver" CssClass="btn-goutu-outline" NavigateUrl="~/RecargaMetodo.aspx" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>