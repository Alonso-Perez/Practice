﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="MenuPrincipal.aspx.cs" Inherits="GoutuWA.MenuPrincipal" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Menú Principal - Goutu
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .background-image-section {
            background-image: url('images/tu-imagen-fondo.jpg');
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
            min-height: 400px;
            border-radius: 10px;
        }

        .user-section {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: space-between;
            height: 100%;
            min-height: 600px;
        }

        .user-info-card {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 20px;
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="container mt-4">
        <div class="row">
            <!-- Columna izquierda para información de usuario -->
            <div class="col-md-6">
                <div class="user-section">
                    <div class="text-center w-100">
                        <h3 class="mb-4">Información de Usuario</h3>
                        <div class="mb-3">
                            <img src="images/users.png" width="200" alt="Usuario" class="mb-3" />
                        </div>
                        <div class="user-info-card">
                            <h4 class="mb-2">
                                <asp:Label ID="lblNombreCompleto" runat="server" Text="Cargando..."></asp:Label>
                            </h4>
                            <p class="text-muted mb-0">
                                <asp:Label ID="lblCorreo" runat="server" Text=""></asp:Label>
                            </p>
                        </div>
                    </div>

                    <!-- Botón -->
                    <div class="d-grid gap-3 w-100" style="max-width: 300px;">
                        <asp:Button ID="btnMisTarjetas" runat="server" Text="Mis Tarjetas"
                            CssClass="btn bd-color-morado-goutu btn-lg" style="color: white;"
                            OnClick="btnMisTarjetas_Click" />
                    </div>
                </div>
            </div>

            <!-- Columna derecha para tarifas y viajes -->
            <div class="col-md-5">
                <h3>Tarifas del Día</h3>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-striped">
                            <thead>
                                <tr>
                                    <th>Linea</th>
                                    <th>Tarifa General</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>Metropolitano</td>
                                    <td>S/. 3.50</td>
                                </tr>
                                <tr>
                                    <td>Corredores</td>
                                    <td>S/. 2.20</td>
                                </tr>
                                <tr>
                                    <td>Tren Eléctrico (Línea 1)</td>
                                    <td>S/. 1.50</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>

                <h3 class="mt-4">Últimos Viajes</h3>
                <div class="card">
                    <div class="card-body">
                        <table class="table table-hover">
                            <thead>
                                <tr>
                                    <th>Fecha</th>
                                    <th>Ruta</th>
                                    <th>Monto</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td>28/10/2025</td>
                                    <td>Centro - Norte</td>
                                    <td>S/. 2.50</td>
                                </tr>
                                <tr>
                                    <td>27/10/2025</td>
                                    <td>Sur - Este</td>
                                    <td>S/. 2.80</td>
                                </tr>
                                <tr>
                                    <td>26/10/2025</td>
                                    <td>Este - Centro</td>
                                    <td>S/. 3.00</td>
                                </tr>
                                <tr>
                                    <td>25/10/2025</td>
                                    <td>Norte - Sur</td>
                                    <td>S/. 2.50</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>