﻿<%@ Page Language="C#" 
    AutoEventWireup="true" 
    CodeBehind="ReporteTarjetas.aspx.cs"
    Inherits="GoutuWA.ReporteTarjetas" 
    MasterPageFile="~/GoutuAdminSistemas.master" %>

<asp:Content ID="Content1" 
             ContentPlaceHolderID="cph_ContenidoAdmin" 
             runat="server">
    <p style="font-size:16px; font-weight:bold; color:#444;">
        Cargando reporte...
    </p>
</asp:Content>