﻿<%@ Page Title="Método de Pago" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="RecargaMetodo.aspx.cs" Inherits="GoutuWA.RecargaMetodo" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Método de Pago
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        :root {
            --goutu-primary: #5e2a84;
            --goutu-light-bg: #f8f5fb;
            --goutu-border: #e0e0e0;
            --goutu-text-muted: #6c757d;
        }

        .main-payment-option {
            border: 2px solid var(--goutu-border);
            border-radius: 15px;
            padding: 15px;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 15px;
            background-color: #fff;
            display: block;
        }

        .main-payment-option:hover {
            border-color: #c0c0c0;
            background-color: #fcfaff;
        }

        .main-payment-option.selected {
            border-color: var(--goutu-primary);
            box-shadow: 0 4px 12px rgba(94, 42, 132, 0.2);
            background-color: var(--goutu-light-bg);
        }

        .main-payment-option input[type="radio"] {
            display: none;
        }

        .main-payment-option label {
            display: block;
            width: 100%;
            cursor: pointer;
            margin-bottom: 0;
        }

        .inner-select-option {
            border: 2px solid var(--goutu-border);
            border-radius: 10px;
            padding: 12px 15px;
            display: block;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 10px;
            background-color: #fff;
        }

        .inner-select-option:hover {
            border-color: #c0c0c0;
        }

        .inner-select-option.selected {
            border-color: var(--goutu-primary);
            background-color: var(--goutu-light-bg);
        }

        .inner-select-option img {
            height: 35px;
            width: 60px;
            object-fit: contain;
            margin-right: 15px;
            border-radius: 6px;
        }

        .inner-select-option .card-number-text {
            font-weight: 500;
            font-size: 1rem;
            color: #333;
            margin-left: 5px;
        }

        .inner-select-option input[type="radio"] {
            display: none;
        }

        .btn-goutu-primary {
            background-color: var(--goutu-primary);
            border-color: var(--goutu-primary);
            color: white;
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
        }

        .btn-goutu-primary:hover {
            background-color: #4a1f63;
            border-color: #4a1f63;
            color: white;
        }

        .btn-goutu-outline {
            background-color: transparent;
            border: 2px solid var(--goutu-primary);
            color: var(--goutu-primary);
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
            text-align: center;
            text-decoration: none;
            display: block;
        }

        .btn-goutu-outline:hover {
            background-color: var(--goutu-light-bg);
            color: var(--goutu-primary);
            text-decoration: none;
        }

        .error-message-global {
            color: #dc3545;
            background-color: #f8d7da;
            border-color: #f5c6cb;
            padding: 15px;
            margin-top: 20px;
            border-radius: 10px;
            font-weight: 500;
            text-align: center;
            display: block;
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <h2 class="text-center" style="color: #5e2a84; font-weight: 600;">
                    <asp:Label ID="lblTituloPagina" runat="server" Text="Elige una forma de pago"></asp:Label>
                </h2>
                <hr />

                <div class="card shadow-sm border-0" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <h5 class="card-title" style="font-weight: 600;">
                            <asp:Label ID="lblTituloResumen" runat="server" Text="Resumen de recarga"></asp:Label>
                        </h5>

                        <div class="d-flex justify-content-between align-items-center mt-3">
                            <span class="text-muted">
                                <asp:Label ID="lblTextoMonto" runat="server" Text="Monto a recargar:"></asp:Label>
                            </span>
                            <asp:Label ID="lblMontoResumen" runat="server" Text="S/ 0.00" CssClass="h5"
                                style="font-weight: 600; color: var(--goutu-primary);"></asp:Label>
                        </div>
                        <div class="d-flex justify-content-between align-items-center mt-2">
                            <span class="text-muted">
                                <asp:Label ID="lblTextoTarjeta" runat="server" Text="Para la tarjeta:"></asp:Label>
                            </span>
                            <asp:Label ID="lblTarjetaResumen" runat="server" Text="[Tipo Tarjeta]" CssClass="h6"
                                style="font-weight: 600;"></asp:Label>
                        </div>
                    </div>
                </div>

                <div class="card shadow-sm border-0 mt-4" style="border-radius: 15px;">
                    <div class="card-body p-4">
                        <h5 class="card-title" style="font-weight: 600;">Métodos de pago</h5>

                        <asp:RadioButtonList ID="rblMetodosPrincipales" runat="server"
                            RepeatLayout="Flow"
                            CssClass="payment-selector mt-3"
                            AutoPostBack="true"
                            OnSelectedIndexChanged="rblMetodosPrincipales_SelectedIndexChanged">
                            <asp:ListItem Value="Guardadas" Text=" "></asp:ListItem>
                            <asp:ListItem Value="NuevaTarjeta" Text=" "></asp:ListItem>
                            <asp:ListItem Value="Billeteras" Text=" "></asp:ListItem>
                        </asp:RadioButtonList>

                        <hr />

                        <asp:Panel ID="pnlTarjetasGuardadas" runat="server" Visible="false">
                            <asp:DropDownList ID="ddlTarjetasGuardadas" runat="server" CssClass="form-select">
                            </asp:DropDownList>
                        </asp:Panel>

                        <asp:Panel ID="pnlNuevaTarjeta" runat="server" Visible="false">
                            <asp:Panel ID="pnlError" runat="server" Visible="false" CssClass="alert alert-danger" role="alert">
                                <asp:Label ID="lblError" runat="server" Text=""></asp:Label>
                            </asp:Panel>

                            <div class="mb-3">
                                <label class="form-label" style="font-weight: 500;">Número de Tarjeta</label>
                                <asp:TextBox ID="txtNumTarjetaCredito" runat="server"
                                    CssClass="form-control"
                                    style="padding: 10px;"
                                    MaxLength="19"
                                    placeholder="0000 0000 0000 0000"></asp:TextBox>
                            </div>

                            <div class="row mb-3">
                                <div class="col-md-6">
                                    <label class="form-label" style="font-weight: 500;">Fecha Venc. (MM/AA)</label>
                                    <asp:TextBox ID="txtVencimiento" runat="server"
                                        CssClass="form-control"
                                        placeholder="MM/AA"
                                        style="padding: 10px;"
                                        MaxLength="5"></asp:TextBox>
                                </div>
                                <div class="col-md-6">
                                    <label class="form-label" style="font-weight: 500;">CVV</label>
                                    <asp:TextBox ID="txtCVV" runat="server"
                                        CssClass="form-control"
                                        placeholder="123"
                                        style="padding: 10px;"
                                        TextMode="Password"
                                        MaxLength="4"></asp:TextBox>
                                </div>
                            </div>

                            <div class="mb-3">
                                <label class="form-label" style="font-weight: 500;">Nombre del Titular</label>
                                <asp:TextBox ID="txtNombreTitular" runat="server"
                                    CssClass="form-control"
                                    style="padding: 10px;"></asp:TextBox>
                            </div>
                        </asp:Panel>

                        <asp:Panel ID="pnlBilleteras" runat="server" Visible="false">
                            <asp:RadioButtonList ID="rblBilleteras" runat="server"
                                RepeatLayout="Flow"
                                AutoPostBack="true"
                                OnSelectedIndexChanged="rblInterno_SelectedIndexChanged">
                            </asp:RadioButtonList>
                        </asp:Panel>
                    </div>
                </div>

                <asp:Label ID="lblErrorGlobal" runat="server" Visible="false" CssClass="error-message-global"></asp:Label>

                <div class="d-grid gap-3 mt-4">
                    <asp:Button ID="btnPagar" runat="server" Text="Pagar" CssClass="btn-goutu-primary" OnClick="btnPagar_Click" />
                    <asp:HyperLink ID="btnVolver" runat="server"
                        Text="Volver"
                        CssClass="btn-goutu-outline"
                        NavigateUrl="javascript:history.back();" />
                </div>
            </div>
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function () {
            const inputTarjeta = document.getElementById('<%= txtNumTarjetaCredito.ClientID %>');
            if (inputTarjeta) {
                inputTarjeta.addEventListener('input', function (e) {
                    let value = e.target.value.replace(/\D/g, '');
                    let formattedValue = '';
                    for (let i = 0; i < value.length; i++) {
                        if (i > 0 && i % 4 === 0) {
                            formattedValue += ' ';
                        }
                        formattedValue += value[i];
                    }
                    e.target.value = formattedValue;
                });
            }

            const inputVencimiento = document.getElementById('<%= txtVencimiento.ClientID %>');
            if (inputVencimiento) {
                inputVencimiento.addEventListener('input', function (e) {
                    let value = e.target.value.replace(/\D/g, '');
                    if (value.length > 2) {
                        value = value.substring(0, 2) + '/' + value.substring(2, 4);
                    }
                    e.target.value = value;
                });
            }
        });
    </script>
</asp:Content>