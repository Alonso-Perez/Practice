﻿

let modalInicioSesion;

function mostrarModalIniciarSesion() {
  
    modalInicioSesion = new bootstrap.Modal(document.getElementById('modalIniciarSesion'));
    modalInicioSesion.show();
       
}