﻿let modalRegistro;

function mostrarModalTerminosYcondiciones() {
    console.log(' EJECUTANDO: mostrarModalTerminosYcondiciones');

    // Verificar si el elemento existe
    var modalElement = document.getElementById('modalTerminos');
    console.log(' Elemento modal:', modalElement);

    if (modalElement) {
        modalRegistro = new bootstrap.Modal(modalElement);
        console.log(' Modal creado:', modalRegistro);
        modalRegistro.show();
        console.log(' Modal mostrado');
    } else {
        console.error(' ERROR: No se encontró el elemento modalTerminos');
    }

    return false;
}
function cerrarModalTerminos() {
    console.log(' EJECUTANDO: cerrarModalTerminos');
    console.log(' Valor de modalRegistro:', modalRegistro);
    console.log(' Tipo de modalRegistro:', typeof modalRegistro);

    if (modalRegistro) {
        console.log(' Cerrando modal...');
        modalRegistro.hide();
        console.log(' Modal cerrado');
    } else {
        console.error(' ERROR: modalRegistro es undefined o null');
        console.log(' Intentando cerrar con método alternativo...');

        // Método alternativo
        var modalElement = document.getElementById('modalTerminos');
        if (modalElement) {
            var modal = bootstrap.Modal.getInstance(modalElement);
            if (modal) {
                modal.hide();
                console.log(' Modal cerrado con método alternativo');
            } else {
                console.error(' No se pudo obtener instancia del modal');
            }
        }
    }

}
