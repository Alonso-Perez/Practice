﻿<%@ Page Title="Recargas" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="Recargas.aspx.cs" Inherits="GoutuWA.Recargas" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Recargas
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        :root {
            --goutu-primary: #5e2a84;
        }

        /* --- Estilos para SELECCIÓN DE TARJETA --- */
        .card-select-option {
            border: 2px solid #e0e0e0;
            border-radius: 15px;
            padding: 15px;
            display: flex;
            align-items: center;
            cursor: pointer;
            transition: all 0.2s ease;
            margin-bottom: 10px;
            background-color: #fff;
        }

        .card-select-option:hover {
            border-color: #c0c0c0;
            background-color: #fcfaff;
        }

        .card-select-option.selected {
            border-color: var(--goutu-primary);
            box-shadow: 0 4px 12px rgba(94, 42, 132, 0.2);
            background-color: #f8f5fb; /* Morado pálido */
        }

        .card-select-option img {
            height: 50px;
            width: 50px;
            object-fit: contain;
            margin-right: 15px;
        }

        /* --- Estilos para SELECCIÓN DE MONTO --- */
        .amount-select-option {
            border: 2px solid var(--goutu-primary);
            border-radius: 10px;
            padding: 18px 10px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
            color: var(--goutu-primary);
            background-color: #ffffff;
            font-weight: 600;
            font-size: 1.1rem;
            user-select: none; /* Evita que el texto se seleccione al hacer clic */
        }

        .amount-select-option:hover {
            background-color: #f8f5fb;
        }

        .amount-select-option.selected {
            background-color: var(--goutu-primary);
            color: #ffffff;
            border-color: var(--goutu-primary);
        }

        /* Estilo para el botón Continuar */
        .btn-goutu-primary {
            background-color: var(--goutu-primary);
            border-color: var(--goutu-primary);
            color: white;
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
        }

        .btn-goutu-primary:hover {
            background-color: #4a1f63; /* Morado más oscuro */
            border-color: #4a1f63;
            color: white;
        }

        .error-message {
            color: #dc3545;
            font-weight: 500;
            margin-bottom: 15px;
            display: block;
            text-align: center;
            padding: 10px;
            background-color: #f8d7da;
            border: 1px solid #f5c6cb;
            border-radius: 5px;
        }
    </style>

    <script type="text/javascript">
        // Función para manejar la selección de TARJETA
        // Recibe el valor compuesto ('tipo|numero') y actualiza el HiddenField.
        function selectCard(divElement, cardValue) {
            // 1. Actualizar el HiddenField correspondiente (hdnSelectedCardInfo)
            var hdnField = document.getElementById('<%= hdnSelectedCardInfo.ClientID %>');
            if (hdnField) hdnField.value = cardValue;

            // 2. Quitar 'selected' de todas las opciones de tarjeta
            var allCards = document.querySelectorAll('.card-select-option');
            allCards.forEach(function (card) {
                card.classList.remove('selected');
            });

            // 3. Agregar 'selected' al div que clickeamos
            divElement.classList.add('selected');
        }

        // Función para manejar la selección de MONTO
        function selectAmount(divElement, amountValue) {
            // 1. Actualizar el HiddenField correspondiente
            var hdnField = document.getElementById('<%= hdnSelectedMonto.ClientID %>');
            if (hdnField) hdnField.value = amountValue;

            // 2. Quitar 'selected' de todos los botones de monto
            var allAmounts = document.querySelectorAll('.amount-select-option');
            allAmounts.forEach(function (btn) {
                btn.classList.remove('selected');
            });

            // 3. Agregar 'selected' al div que clickeamos
            divElement.classList.add('selected');

            // 4. Limpiar "Otro Monto"
            var txtOtroMonto = document.getElementById('<%= txtOtroMonto.ClientID %>');
            if (txtOtroMonto) txtOtroMonto.value = '';
        }

        // Función para manejar "Otro Monto"
        function handleOtroMonto(textBox) {
            if (textBox.value.length > 0) {
                // 1. Limpiar el HiddenField de monto (para indicar al servidor que debe usar el TextBox)
                var hdnField = document.getElementById('<%= hdnSelectedMonto.ClientID %>');
                if (hdnField) hdnField.value = '';

                // 2. Quitar 'selected' de todos los botones de monto
                var allAmounts = document.querySelectorAll('.amount-select-option');
                allAmounts.forEach(function (btn) {
                    btn.classList.remove('selected');
                });
            }
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <%-- CAMPOS OCULTOS para almacenar las selecciones --%>
    <%-- hdnSelectedCardInfo guarda "tipo|numero" (ej. "lima|55821902") --%>
    <asp:HiddenField ID="hdnSelectedCardInfo" runat="server" />
    <asp:HiddenField ID="hdnSelectedMonto" runat="server" />

    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-7">
                <div class="row">
                    <div class="col-12">
                        <h2 style="color: #5e2a84; font-weight: 600;">
                            <asp:Label ID="lblTituloPrincipal" runat="server" Text="Recargas"></asp:Label>
                        </h2>
                        <hr />
                    </div>
                </div>

                <%-- Mensaje de error global (para sesión, conexión, validación o sin tarjetas) --%>
                <asp:Label ID="lblMensajeError" runat="server" CssClass="error-message" Visible="false"></asp:Label>

                <%-- Panel principal que se oculta si hay errores o no hay tarjetas --%>
                <asp:Panel ID="pnlContenidoRecarga" runat="server">
                    <div class="card shadow-sm border-0" style="border-radius: 15px;">
                        <div class="card-body p-4">
                            <h5 class="card-title" style="font-weight: 600;">
                                <asp:Label ID="lblSubtituloTarjeta" runat="server" Text="Selecciona la tarjeta que deseas recargar"></asp:Label>
                            </h5>

                            <%-- Tarjetas desde el Repeater --%>
                            <asp:Repeater ID="rptTarjetas" runat="server">
                                <ItemTemplate>
                                    <div class='card-select-option <%# Eval("EsSeleccionada") != null && (bool)Eval("EsSeleccionada") ? "selected" : "" %>'
                                         onclick='selectCard(this, "<%# Eval("Value") %>")'>
                                        <img src='<%# Eval("ImagenUrl") %>' alt='<%# Eval("Nombre") %>' />
                                        <div>
                                            <strong class="d-block"><%# Eval("Nombre") %></strong>
                                            <span class="text-muted" style="font-weight: 500; font-size: 0.9rem;">#<%# Eval("Numero") %></span>
                                        </div>
                                    </div>
                                </ItemTemplate>
                            </asp:Repeater>
                        </div>
                    </div>

                    <div class="card shadow-sm border-0 mt-4" style="border-radius: 15px;">
                        <div class="card-body p-4">
                            <h5 class="card-title" style="font-weight: 600;">
                                <asp:Label ID="lblSubtituloMonto" runat="server" Text="Selecciona el monto a recargar (S/)"></asp:Label>
                            </h5>

                            <div class="row g-3 mt-2">
                                <div class="col-6">
                                    <div ID="divMonto5" runat="server" class="amount-select-option" onclick="selectAmount(this, '5')">
                                        S/ 5
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div ID="divMonto10" runat="server" class="amount-select-option" onclick="selectAmount(this, '10')">
                                        S/ 10
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div ID="divMonto20" runat="server" class="amount-select-option" onclick="selectAmount(this, '20')">
                                        S/ 20
                                    </div>
                                </div>
                                <div class="col-6">
                                    <div ID="divMonto50" runat="server" class="amount-select-option" onclick="selectAmount(this, '50')">
                                        S/ 50
                                    </div>
                                </div>
                            </div>

                            <div class="mt-4">
                                <label for="<%= txtOtroMonto.ClientID %>" class="form-label" style="font-weight: 600;">Otro monto (S/)</label>
                                <div class="input-group">
                                    <span class="input-group-text bg-light border-0">S/</span>
                                    <asp:TextBox ID="txtOtroMonto" runat="server" CssClass="form-control"
                                        placeholder="Monto personalizado" style="padding: 10px;" onkeyup="handleOtroMonto(this)"></asp:TextBox>
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="d-grid mt-4">
                        <asp:Button ID="btnContinuar" runat="server" Text="Continuar" OnClick="btnContinuar_Click" CssClass="btn btn-goutu-primary" />
                    </div>
                </asp:Panel>
                <%-- Fin pnlContenidoRecarga --%>
            </div>
        </div>
    </div>
</asp:Content>