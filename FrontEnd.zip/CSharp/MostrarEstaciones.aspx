﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="MostrarEstaciones.aspx.cs" Inherits="GoutuWA.MostrarEstaciones" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Mostrar Estaciones
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        body {
            background: #5e2a84;
            min-height: 100vh;
            margin: 0;
            padding: 0;
        }
        
        .contenedor { 
            max-width: 1200px; 
            margin: 0 auto; 
            padding: 30px 20px; 
        }
        
        .header-section {
            text-align: center;
            margin-bottom: 30px;
        }
        
        .titulo { 
            font-size: 2.2rem; 
            font-weight: 700; 
            margin-bottom: 10px;
            color: #fff;
        }
        
        .sub { 
            color: rgba(255,255,255,.8); 
            font-size: 1.1rem;
        }

        .panel {
            background: #fff; 
            border-radius: 10px; 
            padding: 25px;
            margin-bottom: 20px;
            border: 1px solid #e0e0e0;
        }
        
        .panel h3 { 
            margin: 0 0 20px 0; 
            font-size: 1.3rem;
            font-weight: 600;
            color: #5e2a84;
            border-bottom: 2px solid #5e2a84;
            padding-bottom: 10px;
        }

        .grid { 
            display: flex; 
            flex-wrap: wrap; 
            gap: 12px; 
            align-items: center;
        }

        .btn-ruta {
            background: #5e2a84;
            color: #fff; 
            border: 2px solid #5e2a84; 
            border-radius: 8px; 
            padding: 12px 20px;
            font-weight: 600; 
            font-size: 14px;
            cursor: pointer; 
            transition: all 0.3s ease;
        }
        
        .btn-ruta:hover { 
            background: #4a1f63;
            border-color: #4a1f63;
        }

        /* Mapa de estaciones */
        .ruta-mapa { 
            display: flex; 
            flex-wrap: wrap; 
            align-items: center; 
            gap: 15px;
            padding: 15px 0;
        }
        
        .estacion-item { 
            display: inline-flex; 
            flex-direction: column;
            align-items: center; 
            gap: 8px;
        }
        
        .estacion-circulo {
            width: 50px; 
            height: 50px; 
            border-radius: 50%;
            background: #fff; 
            color: #5e2a84; 
            border: 3px solid #5e2a84;
            display: flex; 
            align-items: center; 
            justify-content: center;
            font-weight: 700; 
            font-size: 1.1rem;
            transition: all 0.3s ease;
        }
        
        .estacion-nombre { 
            font-weight: 600; 
            text-align: center;
            color: #333;
            font-size: 0.9rem;
            max-width: 100px;
        }
        
        .flecha { 
            font-size: 20px; 
            color: #666;
        }

        /* Seleccionada - AMARILLO OSCURO */
        .estacion-circulo.sel {
            background: #b45309;
            border-color: #b45309;
            color: #fff;
        }
        
        .estacion-nombre.sel { 
            color: #b45309;
            font-weight: 700;
        }

        /* Botones de estaciones */
        .btn-estacion {
            background: #f8f9fa;
            color: #333; 
            border: 2px solid #ddd; 
            border-radius: 8px;
            padding: 10px 16px; 
            font-weight: 600; 
            font-size: 0.9rem;
            cursor: pointer; 
            transition: all 0.3s ease;
        }
        
        .btn-estacion:hover { 
            background: #5e2a84;
            border-color: #5e2a84;
            color: #fff;
        }

        /* GridView de Transportes */
        .grid-transportes {
            width: 100%;
            border-collapse: collapse;
            margin-top: 15px;
        }
        
        .grid-transportes th {
            background: #5e2a84;
            color: white;
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }
        
        .grid-transportes td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
        }
        
        .grid-transportes tr:nth-child(even) {
            background: #f8f9fa;
        }
        
        .grid-transportes tr:hover {
            background-color: #f0f0f0;
        }

        .empty-state {
            text-align: center;
            padding: 40px 20px;
            color: #666;
        }
        
        .empty-state h4 {
            color: #333;
            margin-bottom: 8px;
            font-weight: 600;
        }

        .volver { 
            display: inline-block;
            margin-top: 20px; 
            padding: 10px 20px;
            background: #fff;
            color: #5e2a84; 
            font-weight: 600;
            font-size: 14px;
            text-decoration: none;
            border-radius: 8px;
            border: 2px solid #fff;
            transition: all 0.3s ease;
        }
        
        .volver:hover {
            background: #5e2a84;
            color: #fff;
            text-decoration: none;
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="contenedor">

        <!-- Rutas del servicio -->
        <div class="panel">
            <h3>Elige una Ruta</h3>
            <div class="grid">
                <asp:PlaceHolder ID="phRutas" runat="server"></asp:PlaceHolder>
            </div>
        </div>

        <!-- Mapa de estaciones -->
        <asp:Panel ID="pnlMapa" runat="server" class="panel" Visible="false">
            <h3><asp:Literal ID="ltRutaSel" runat="server" /></h3>
            <div class="ruta-mapa">
                <asp:PlaceHolder ID="phMapa" runat="server"></asp:PlaceHolder>
            </div>
        </asp:Panel>

        <!-- Botones de estaciones seleccionables -->
        <asp:Panel ID="pnlEstaciones" runat="server" class="panel" Visible="false">
            <h3>Selecciona una Estación</h3>
            <div class="grid">
                <asp:PlaceHolder ID="phEstacionesBtns" runat="server"></asp:PlaceHolder>
            </div>
        </asp:Panel>

        <!-- Panel Transportes en Estación -->
        <asp:Panel ID="pnlTransportes" runat="server" class="panel" Visible="false">
            <h3>Transportes en Estación</h3>
            <asp:GridView ID="gvTransportes" runat="server" CssClass="grid-transportes" AutoGenerateColumns="false">
                <Columns>
                    <asp:BoundField DataField="estacion" HeaderText="Estación Actual" />
                    <asp:BoundField DataField="fechaHora" HeaderText="Fecha y Hora" />
                    <asp:BoundField DataField="nombreTransporte" HeaderText="Nombre del Transporte" />
                    <asp:BoundField DataField="estacionNombreLlegada" HeaderText="Destino" />
                </Columns>
                <EmptyDataTemplate>
                    <div class="empty-state">
                        <h4>No hay transportes disponibles</h4>
                        <p>Actualmente no hay transportes en esta estación</p>
                    </div>
                </EmptyDataTemplate>
            </asp:GridView>
            <asp:Label ID="lblTransportesVacio" runat="server" Visible="false" />
        </asp:Panel>

        <a href="Rutas.aspx" class="volver">← Volver a Servicios</a>
    </div>
</asp:Content>