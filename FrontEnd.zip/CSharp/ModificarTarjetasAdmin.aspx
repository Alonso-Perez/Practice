﻿<%@ Page Title="Modificar Tarjetas" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="ModificarTarjetasAdmin.aspx.cs" Inherits="GoutuWA.ModificarTarjetasAdmin" %>

<asp:Content ID="cTitle" ContentPlaceHolderID="cph_Title" runat="server">
    Modificar Tarjetas - Admin Sistema
</asp:Content>

<asp:Content ID="cScripts" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .admin-header {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
            padding: 30px;
            border-radius: 15px;
            margin-bottom: 30px;
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
        }

        .admin-header h2 {
            margin: 0;
            font-weight: 700;
        }

        .card-section {
            background: white;
            border-radius: 15px;
            padding: 30px;
            margin-bottom: 30px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .card-section h3 {
            color: #5e2a84;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 15px;
            border-bottom: 2px solid #e0e0e0;
        }

        .tarjeta-item {
            border: 1px solid #e0e0e0;
            border-radius: 10px;
            padding: 20px;
            margin-bottom: 15px;
            transition: all 0.3s ease;
        }

        .tarjeta-item:hover {
            box-shadow: 0 5px 15px rgba(0, 0, 0, 0.1);
            transform: translateY(-2px);
        }

        .tarjeta-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 15px;
        }

        .tarjeta-codigo {
            font-size: 24px;
            font-weight: 700;
            color: #5e2a84;
        }

        .tarjeta-tipo {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
            padding: 5px 15px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
        }

        .tarjeta-details {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(150px, 1fr));
            gap: 15px;
            margin-bottom: 15px;
        }

        .detail-item {
            padding: 10px;
            background-color: #f8f9fa;
            border-radius: 8px;
        }

        .detail-label {
            font-size: 12px;
            color: #666;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 5px;
        }

        .detail-value {
            font-size: 16px;
            font-weight: 600;
            color: #333;
        }

        .btn-primary-custom {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            border: none;
            padding: 8px 20px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-primary-custom:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(94, 42, 132, 0.3);
        }

        .alert-custom {
            border-left: 4px solid;
            border-radius: 8px;
        }

        .alert-custom.success {
            border-left-color: #28a745;
            background-color: #d4edda;
        }

        .alert-custom.error {
            border-left-color: #dc3545;
            background-color: #f8d7da;
        }

        /* Botón flotante Volver */
        .btn-back-floating {
            position: fixed;
            bottom: 25px;
            right: 25px;
            z-index: 1050;
            background: #6c757d;
            border: none;
            color: #fff !important;
            padding: 10px 20px;
            border-radius: 999px;
            font-weight: 600;
            box-shadow: 0 4px 12px rgba(0,0,0,0.25);
        }

        .btn-back-floating i {
            margin-right: 6px;
        }

        .btn-back-floating:hover {
            text-decoration: none;
            background: #5a6268;
            color: #fff;
        }
    </style>

    <script type="text/javascript">
        function mostrarToast(mensaje, tipo) {
            var toastEl = document.getElementById('toastNotificacion');
            var toastBody = document.getElementById('toastMensaje');

            toastBody.innerText = mensaje;

            toastEl.classList.remove('bg-success', 'bg-danger', 'bg-info');
            if (tipo === 'error') {
                toastEl.classList.add('bg-danger');
            } else if (tipo === 'info') {
                toastEl.classList.add('bg-info');
            } else {
                toastEl.classList.add('bg-success');
            }

            var toast = new bootstrap.Toast(toastEl);
            toast.show();
        }

        // Sólo números (para el filtro de DNI)
        function soloNumeros(e) {
            var key = e.keyCode || e.which;

            // teclas especiales: backspace, tab, flechas, delete
            if (key === 8 || key === 9 || key === 37 || key === 39 || key === 46) {
                return true;
            }

            var ch = String.fromCharCode(key);
            if (!/[0-9]/.test(ch)) {
                e.preventDefault();
                return false;
            }
            return true;
        }
    </script>
</asp:Content>

<asp:Content ID="cContenido" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <div class="admin-header">
        <h2><i class="fas fa-edit me-3"></i>Modificar Tarjetas Existentes</h2>
        <p class="mb-0">Edita los datos de las tarjetas en el sistema</p>
    </div>

    <!-- Mensajes -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false" CssClass="alert-custom mb-4">
        <asp:Label ID="lblMensaje" runat="server"></asp:Label>
    </asp:Panel>

    <!-- Filtros -->
    <div class="card-section">
        <h3><i class="fas fa-filter me-2"></i>Filtros</h3>

        <div class="row align-items-end">
            <div class="col-md-3">
                <label class="form-label">Tipo de Tarjeta</label>
                <asp:DropDownList ID="ddlFiltroTipo" runat="server" CssClass="form-select" AutoPostBack="true" OnSelectedIndexChanged="ddlFiltroTipo_SelectedIndexChanged">
                    <asp:ListItem Text="Todas" Value=""></asp:ListItem>
                    <asp:ListItem Text="Lima Pass" Value="Lima Pass"></asp:ListItem>
                    <asp:ListItem Text="Linea 1" Value="Linea 1"></asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="col-md-3">
                <label class="form-label">Estado</label>
                <asp:DropDownList ID="ddlFiltroEstado" runat="server" CssClass="form-select" AutoPostBack="true" OnSelectedIndexChanged="ddlFiltroEstado_SelectedIndexChanged">
                    <asp:ListItem Text="Todos" Value=""></asp:ListItem>
                    <asp:ListItem Text="Activo" Value="Activo"></asp:ListItem>
                    <asp:ListItem Text="Bloqueado" Value="Bloqueado"></asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="col-md-3">
                <label class="form-label">Buscar por Código</label>
                <asp:TextBox ID="txtBuscarCodigo" runat="server" CssClass="form-control" placeholder="Código..."></asp:TextBox>
            </div>

            <div class="col-md-3">
                <label class="form-label">Buscar por DNI</label>
                <asp:TextBox ID="txtBuscarDni" runat="server" CssClass="form-control" placeholder="DNI..."
                    MaxLength="8" onkeypress="return soloNumeros(event);"></asp:TextBox>
            </div>
        </div>

        <div class="row align-items-end mt-3">
            <div class="col-md-9">
                <label class="form-label">Buscar por Nombre</label>
                <asp:TextBox ID="txtBuscarNombre" runat="server" CssClass="form-control" placeholder="Nombre..."></asp:TextBox>
            </div>
            <div class="col-md-3 text-end">
                <asp:Button ID="btnBuscar" runat="server" Text="Aplicar filtros" CssClass="btn btn-primary-custom mt-3 mt-md-0"
                    OnClick="btnBuscar_Click" />
            </div>
        </div>
    </div>

    <!-- Listado de Tarjetas -->
    <div class="card-section">
        <h3><i class="fas fa-list me-2"></i>Tarjetas en el Sistema</h3>
        
        <asp:Panel ID="pnlSinResultados" runat="server" Visible="false" CssClass="text-center py-5">
            <i class="fas fa-search fa-3x text-muted mb-3"></i>
            <p class="text-muted">No se encontraron tarjetas con los filtros seleccionados</p>
        </asp:Panel>

        <asp:Repeater ID="RepeaterTarjetas" runat="server" OnItemCommand="RepeaterTarjetas_ItemCommand">
            <ItemTemplate>
                <div class="tarjeta-item">
                    <div class="tarjeta-header">
                        <div class="tarjeta-codigo">
                            <i class="fas fa-credit-card me-2"></i><%# Eval("Codigo") %>
                        </div>
                        <span class="tarjeta-tipo"><%# Eval("Tipo") %></span>
                    </div>

                    <div class="tarjeta-details">
                        <div class="detail-item">
                            <div class="detail-label">Saldo</div>
                            <div class="detail-value text-success">S/ <%# Eval("Saldo", "{0:N2}") %></div>
                        </div>

                        <div class="detail-item">
                            <div class="detail-label">Tarifario</div>
                            <div class="detail-value"><%# Eval("Tarifario") %></div>
                        </div>

                        <div class="detail-item">
                            <div class="detail-label">Estado</div>
                            <div class="detail-value"><%# Eval("Estado") %></div>
                        </div>

                        <div class="detail-item">
                            <div class="detail-label">DNI Usuario</div>
                            <div class="detail-value"><%# Eval("UsuarioDni") %></div>
                        </div>

                        <div class="detail-item">
                            <div class="detail-label">Nombre Usuario</div>
                            <div class="detail-value"><%# Eval("UsuarioNombreCompleto") %></div>
                        </div>
                    </div>

                    <div class="text-end">
                        <asp:Button ID="btnModificar" runat="server" Text="Modificar" 
                            CssClass="btn btn-primary-custom btn-sm" 
                            CommandName="Modificar"
                            CommandArgument='<%# Eval("IdTarjeta") + "," + Eval("Tipo") %>' />
                    </div>
                </div>
            </ItemTemplate>
        </asp:Repeater>
    </div>

    <!-- Modal Modificar -->
    <div class="modal fade" id="modalModificar" tabindex="-1" aria-labelledby="modalModificarLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header" style="background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%); color: white;">
                    <h5 class="modal-title" id="modalModificarLabel">
                        <i class="fas fa-edit me-2"></i>Modificar Tarjeta
                    </h5>
                    <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <asp:HiddenField ID="hfIdTarjetaModificar" runat="server" />
                    <asp:HiddenField ID="hfTipoTarjetaModificar" runat="server" />

                    <div class="mb-3">
                        <label class="form-label">Código (solo lectura)</label>
                        <asp:TextBox ID="txtCodigoModificar" runat="server" CssClass="form-control" ReadOnly="true"></asp:TextBox>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Saldo <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtSaldoModificar" runat="server" CssClass="form-control" TextMode="Number" step="0.01"></asp:TextBox>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Tarifario <span class="text-danger">*</span></label>
                        <asp:DropDownList ID="ddlTarifarioModificar" runat="server" CssClass="form-select">
                            <asp:ListItem Text="Regular" Value="Regular"></asp:ListItem>
                            <asp:ListItem Text="Universitario" Value="Universitario"></asp:ListItem>
                            <asp:ListItem Text="Conadis" Value="Conadis"></asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Estado <span class="text-danger">*</span></label>
                        <asp:DropDownList ID="ddlEstadoModificar" runat="server" CssClass="form-select">
                            <asp:ListItem Text="Activo" Value="Activo"></asp:ListItem>
                            <asp:ListItem Text="Bloqueado" Value="Bloqueado"></asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <div class="mb-3">
                        <label class="form-label">Usuario (DNI) <span class="text-danger">*</span></label>
                        <asp:DropDownList ID="ddlUsuarioModificar" runat="server" CssClass="form-select">
                        </asp:DropDownList>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
                    <asp:Button ID="btnGuardarCambios" runat="server" Text="Guardar Cambios" 
                        CssClass="btn btn-primary-custom" OnClick="btnGuardarCambios_Click" />
                </div>
            </div>
        </div>
    </div>

    <!-- Toast para notificaciones -->
    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="toastNotificacion" class="toast align-items-center text-white border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body" id="toastMensaje"></div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

    <!-- Botón flotante Volver -->
    <a href="GestionTarjetasAdmin.aspx" class="btn-back-floating">
        <i class="fas fa-arrow-left"></i> Volver
    </a>

</asp:Content>