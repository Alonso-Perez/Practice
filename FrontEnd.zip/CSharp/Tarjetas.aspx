﻿<%@ Page Title="Mis Tarjetas" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="Tarjetas.aspx.cs" Inherits="GoutuWA.Tarjetas" %>

<asp:Content ID="cTitle" ContentPlaceHolderID="cph_Title" runat="server">
    Mis Tarjetas
</asp:Content>

<asp:Content ID="cScripts" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .card-tarjeta {
            transition: transform 0.2s ease-in-out, box-shadow 0.2s ease-in-out;
        }

        .card-tarjeta:hover {
            transform: translateY(-5px);
            box-shadow: 0 8px 16px rgba(0,0,0,0.15) !important;
        }

        .card-img-tarjeta {
            height: 200px;
            object-fit: contain;
            padding: 20px;
            background-color: #f8f9fa;
        }

        .error-message {
            font-size: 0.875rem;
            margin-top: 0.25rem;
        }

        .toast-custom {
            position: fixed;
            top: 20px;
            right: 20px;
            z-index: 9999;
            min-width: 300px;
        }
    </style>

    <script type="text/javascript">
        function validarCodigoTiempoReal() {
            var ddlTipo = document.getElementById('<%= ddlTipo.ClientID %>');
            var txtCodigo = document.getElementById('<%= txtCodigo.ClientID %>');
            var btnGuardar = document.getElementById('<%= btnGuardarTarjeta.ClientID %>');
            var lblError = document.getElementById('<%= lblAddError.ClientID %>');

            var tipo = ddlTipo.value;
            var codigo = txtCodigo.value.trim();
            var error = '';

            if (codigo && !/^\d+$/.test(codigo)) {
                error = 'Solo se permiten números.';
            }
            else if (tipo === 'Línea 1' && codigo && codigo.length !== 8) {
                error = 'Para Línea 1 son exactamente 8 dígitos.';
            }
            else if (tipo === 'Lima Pass' && codigo && codigo.length !== 10) {
                error = 'Para Lima Pass son exactamente 10 dígitos.';
            }
            else if (!tipo) {
                error = 'Selecciona el tipo de tarjeta.';
            }
            else if (!codigo) {
                error = 'Ingresa el código de la tarjeta.';
            }

            if (error) {
                lblError.innerText = error;
                lblError.classList.remove('d-none');
                btnGuardar.disabled = true;
            } else {
                lblError.innerText = '';
                lblError.classList.add('d-none');
                btnGuardar.disabled = false;
            }
        }

        function actualizarMaxLength() {
            var ddlTipo = document.getElementById('<%= ddlTipo.ClientID %>');
            var txtCodigo = document.getElementById('<%= txtCodigo.ClientID %>');

            if (ddlTipo.value === 'Línea 1') {
                txtCodigo.maxLength = 8;
            } else if (ddlTipo.value === 'Lima Pass') {
                txtCodigo.maxLength = 10;
            } else {
                txtCodigo.maxLength = 10;
            }

            if (txtCodigo.value.length > txtCodigo.maxLength) {
                txtCodigo.value = txtCodigo.value.substring(0, txtCodigo.maxLength);
            }

            validarCodigoTiempoReal();
        }

        function soloNumeros(e) {
            var key = e.key;
            if (!/^\d$/.test(key) && key !== 'Backspace' && key !== 'Delete' && key !== 'Tab' && key !== 'ArrowLeft' && key !== 'ArrowRight') {
                e.preventDefault();
            }
        }

        function mostrarToast(mensaje) {
            var toastEl = document.getElementById('toastNotificacion');
            document.getElementById('toastMensaje').innerText = mensaje;
            var toast = new bootstrap.Toast(toastEl);
            toast.show();
        }

        function mostrarToastError(mensaje) {
            var toastEl = document.getElementById('toastError');
            document.getElementById('toastMensajeError').innerText = mensaje;
            var toast = new bootstrap.Toast(toastEl);
            toast.show();
        }

        window.onload = function () {
            var ddlTipo = document.getElementById('<%= ddlTipo.ClientID %>');
            var txtCodigo = document.getElementById('<%= txtCodigo.ClientID %>');

            if (ddlTipo) {
                ddlTipo.addEventListener('change', function () {
                    actualizarMaxLength();
                    validarCodigoTiempoReal();
                });
            }
            if (txtCodigo) {
                txtCodigo.addEventListener('input', validarCodigoTiempoReal);
                txtCodigo.addEventListener('keydown', soloNumeros);
            }

            validarCodigoTiempoReal();
        }

        function abrirModalAgregar() {
            var hf = document.getElementById('<%= hfTotalTarjetas.ClientID %>');
            var total = parseInt(hf ? hf.value : '0', 10) || 0;

            if (total >= 4) {
                if (typeof mostrarToastError === 'function') {
                    mostrarToastError('Has alcanzado el máximo de 4 tarjetas asociadas.');
                } else {
                    alert('Has alcanzado el máximo de 4 tarjetas asociadas.');
                }
                return;
            }

            var ddlTipo = document.getElementById('<%= ddlTipo.ClientID %>');
            var txtCodigo = document.getElementById('<%= txtCodigo.ClientID %>');
            var lblError = document.getElementById('<%= lblAddError.ClientID %>');
            var btnGuardar = document.getElementById('<%= btnGuardarTarjeta.ClientID %>');

            if (ddlTipo) ddlTipo.value = '';
            if (txtCodigo) txtCodigo.value = '';
            if (lblError) { lblError.innerText = ''; lblError.classList.add('d-none'); }
            if (btnGuardar) btnGuardar.disabled = true;

            if (typeof actualizarMaxLength === 'function') actualizarMaxLength();
            if (typeof validarCodigoTiempoReal === 'function') validarCodigoTiempoReal();

            var modalEl = document.getElementById('addCardModal');
            if (!modalEl) return;
            var modal = bootstrap.Modal.getOrCreateInstance(modalEl);
            modal.show();

            setTimeout(function () { if (ddlTipo) ddlTipo.focus(); }, 150);
        }

        function reabrirModalSinLimpiar(tipo, codigo, mensaje) {
            var ddlTipo = document.getElementById('<%= ddlTipo.ClientID %>');
            var txtCodigo = document.getElementById('<%= txtCodigo.ClientID %>');
            var lblError = document.getElementById('<%= lblAddError.ClientID %>');
            var btnGuardar = document.getElementById('<%= btnGuardarTarjeta.ClientID %>');

            if (ddlTipo && tipo) ddlTipo.value = tipo;
            if (typeof actualizarMaxLength === 'function') actualizarMaxLength();
            if (txtCodigo && codigo) txtCodigo.value = codigo;

            if (lblError) {
                lblError.innerText = mensaje || '';
                if (mensaje) lblError.classList.remove('d-none');
                else lblError.classList.add('d-none');
            }
            if (btnGuardar) btnGuardar.disabled = false;

            var modal = bootstrap.Modal.getOrCreateInstance(document.getElementById('addCardModal'));
            modal.show();
        }
    </script>
</asp:Content>

<asp:Content ID="cContenido" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="container-fluid py-4">
        <asp:HiddenField ID="hfTotalTarjetas" runat="server" />

        <asp:Panel ID="pnlEstadoVacio" runat="server" Visible="false" CssClass="text-center py-5">
            <div class="mb-4">
                <i class="fas fa-credit-card fa-5x text-muted"></i>
            </div>
            <h2 class="mb-3">¡Agrega tus tarjetas preferidas!</h2>
            <p class="text-muted mb-4">Agrega como máximo 4 tarjetas prepago del SIT</p>
            <button type="button" class="btn btn-primary btn-lg" onclick="abrirModalAgregar()">
                <i class="fas fa-plus me-2"></i>Añadir Tarjeta
            </button>
        </asp:Panel>

        <asp:Panel ID="pnlListado" runat="server" Visible="false">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h2>Mis Tarjetas</h2>
                <button type="button" class="btn btn-primary" onclick="abrirModalAgregar()">
                    <i class="fas fa-plus me-2"></i>Añadir Tarjeta
                </button>
            </div>

            <div class="row row-cols-1 row-cols-md-2 g-4">
                <asp:Repeater ID="RepeaterTarjetas" runat="server">
                    <ItemTemplate>
                        <div class="col">
                            <div class="card card-tarjeta shadow-sm h-100">
                                <img src='<%# Eval("ImagePath") %>' alt="<%# Eval("CardType") %>" class="card-img-tarjeta" />
                                <div class="card-body">
                                    <h5 class="card-title text-primary">Tarjeta #: <%# Eval("CardNumber") %></h5>
                                    <p class="card-text mb-1">
                                        <strong>Tipo:</strong> <%# Eval("CardType") %>
                                    </p>
                                    <asp:LinkButton ID="btnVerDetalles" runat="server"
                                        CssClass="btn btn-primary mt-3"
                                        CommandArgument='<%# Eval("CardNumber") %>'
                                        OnClick="VerDetalles_Click">
                                        <i class="fas fa-eye me-2"></i>Ver Detalles
                                    </asp:LinkButton>
                                </div>
                            </div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
            </div>
        </asp:Panel>
    </div>

    <div class="modal fade" id="addCardModal" tabindex="-1" aria-labelledby="addCardModalLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="addCardModalLabel">Ingresar nueva tarjeta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="<%= ddlTipo.ClientID %>" class="form-label">Tipo de tarjeta <span class="text-danger">*</span></label>
                        <asp:DropDownList ID="ddlTipo" runat="server" CssClass="form-select">
                            <asp:ListItem Text="-- Seleccione --" Value=""></asp:ListItem>
                            <asp:ListItem Text="Línea 1" Value="Línea 1"></asp:ListItem>
                            <asp:ListItem Text="Lima Pass" Value="Lima Pass"></asp:ListItem>
                        </asp:DropDownList>
                    </div>

                    <div class="mb-3">
                        <label for="<%= txtCodigo.ClientID %>" class="form-label">Código de tarjeta <span class="text-danger">*</span></label>
                        <asp:TextBox ID="txtCodigo" runat="server" CssClass="form-control"
                            MaxLength="10" placeholder="Solo números"></asp:TextBox>
                        <small class="form-text text-muted">Línea 1: 8 dígitos · Lima Pass: 10 dígitos</small>
                    </div>

                    <asp:Label ID="lblAddError" runat="server" CssClass="text-danger fw-semibold d-none error-message"
                        role="alert" aria-live="polite"></asp:Label>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cerrar</button>
                    <asp:Button ID="btnGuardarTarjeta" runat="server" CssClass="btn btn-primary"
                        Text="Ingresar" OnClick="btnGuardarTarjeta_Click" />
                </div>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="toastNotificacion" class="toast align-items-center text-white bg-success border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body" id="toastMensaje">Tarjeta agregada correctamente</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>

    <div class="toast-container position-fixed top-0 end-0 p-3">
        <div id="toastError" class="toast align-items-center text-white bg-danger border-0" role="alert">
            <div class="d-flex">
                <div class="toast-body" id="toastMensajeError">Ocurrió un error</div>
                <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast"></button>
            </div>
        </div>
    </div>
</asp:Content>