﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="GestionClientes.aspx.cs" Inherits="GoutuWA.GestionClientes" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Clientes
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h2 {
            color: #4b0082;
            font-weight: 700;
            font-size: 32px;
            margin: 0;
        }

        .header-actions {
            display: flex;
            gap: 10px;
        }

        .btn-export {
            background-color: #28a745;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-export:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
            color: white;
        }

        /* Tarjetas de estadísticas */
        .stats-container {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }

        .stat-card {
            background: white;
            border-radius: 12px;
            padding: 20px;
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.08);
            display: flex;
            align-items: center;
            gap: 15px;
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-3px);
            box-shadow: 0 4px 15px rgba(0, 0, 0, 0.12);
        }

        .stat-icon {
            width: 50px;
            height: 50px;
            border-radius: 10px;
            display: flex;
            align-items: center;
            justify-content: center;
            font-size: 24px;
            color: white;
        }

        .stat-icon.total {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
        }

        .stat-icon.active {
            background: linear-gradient(135deg, #28a745, #20c997);
        }

        .stat-icon.inactive {
            background: linear-gradient(135deg, #dc3545, #c82333);
        }

        .stat-icon.new {
            background: linear-gradient(135deg, #ffc107, #ffb300);
        }

        .stat-info h3 {
            font-size: 28px;
            font-weight: 700;
            color: #333;
            margin: 0;
        }

        .stat-info p {
            font-size: 13px;
            color: #666;
            margin: 0;
        }

        /* Card de contenido */
        .content-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        /* Barra de búsqueda y filtros */
        .search-filter-bar {
            display: flex;
            gap: 15px;
            margin-bottom: 20px;
            flex-wrap: wrap;
        }

        .search-box {
            flex: 1;
            min-width: 250px;
            position: relative;
        }

        .search-box input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .search-box input:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .search-box i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
        }

        .filter-group {
            display: flex;
            gap: 10px;
            align-items: center;
        }

        .filter-select {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            background-color: white;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .filter-select:focus {
            border-color: #4b0082;
            outline: none;
        }

        /* Tabla */
        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table thead {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
        }

        .data-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            white-space: nowrap;
        }

        .data-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s ease;
        }

        .data-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .data-table td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .user-info {
            display: flex;
            align-items: center;
            gap: 12px;
        }

        .user-avatar {
            width: 40px;
            height: 40px;
            border-radius: 50%;
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            display: flex;
            align-items: center;
            justify-content: center;
            color: white;
            font-weight: 600;
            font-size: 16px;
        }

        .user-details h4 {
            margin: 0;
            font-size: 14px;
            font-weight: 600;
            color: #333;
        }

        .user-details p {
            margin: 0;
            font-size: 12px;
            color: #666;
        }

        .badge {
            padding: 5px 12px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .badge.active {
            background-color: #d4edda;
            color: #155724;
        }

        .badge.inactive {
            background-color: #f8d7da;
            color: #721c24;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-action {
            width: 35px;
            height: 35px;
            border: none;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-view {
            background-color: #e3f2fd;
            color: #1976d2;
        }

        .btn-view:hover {
            background-color: #1976d2;
            color: white;
            transform: scale(1.1);
        }

        .btn-edit {
            background-color: #fff3cd;
            color: #856404;
        }

        .btn-edit:hover {
            background-color: #ffc107;
            color: white;
            transform: scale(1.1);
        }

        .btn-delete {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-delete:hover {
            background-color: #dc3545;
            color: white;
            transform: scale(1.1);
        }

        /* Paginación */
        .pagination-container {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-top: 20px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .pagination-info {
            font-size: 14px;
            color: #666;
        }

        .pagination {
            display: flex;
            gap: 5px;
        }

        .pagination button {
            padding: 8px 12px;
            border: 2px solid #e0e0e0;
            background-color: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .pagination button:hover {
            border-color: #4b0082;
            color: #4b0082;
        }

        .pagination button.active {
            background-color: #4b0082;
            color: white;
            border-color: #4b0082;
        }

        .pagination button:disabled {
            opacity: 0.5;
            cursor: not-allowed;
        }

        /* Modal */
        .modal-backdrop {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 1000;
            align-items: center;
            justify-content: center;
        }

        .modal-backdrop.show {
            display: flex;
        }

        .modal-content-custom {
            background: white;
            border-radius: 15px;
            padding: 30px;
            max-width: 500px;
            width: 90%;
            max-height: 90vh;
            overflow-y: auto;
        }

        .modal-header-custom {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .modal-header-custom h3 {
            color: #4b0082;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }

        .btn-close-modal {
            background: none;
            border: none;
            font-size: 24px;
            cursor: pointer;
            color: #999;
            transition: color 0.3s ease;
        }

        .btn-close-modal:hover {
            color: #333;
        }

        .detail-row {
            display: flex;
            padding: 12px 0;
            border-bottom: 1px solid #f0f0f0;
        }

        .detail-label {
            font-weight: 600;
            color: #666;
            width: 150px;
        }

        .detail-value {
            color: #333;
            flex: 1;
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .stats-container {
                grid-template-columns: 1fr;
            }

            .search-filter-bar {
                flex-direction: column;
            }

            .search-box {
                width: 100%;
            }

            .table-container {
                overflow-x: scroll;
            }

            .data-table {
                min-width: 800px;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <!-- Header -->
    <div class="page-header">
        <h2><i class="fa-solid fa-users"></i> Gestión de Clientes</h2>
        <div class="header-actions">
            <a href="#" class="btn-export">
                <i class="fa-solid fa-download"></i>
                Exportar Excel
            </a>
        </div>
    </div>

    <!-- Estadísticas -->
    <div class="stats-container">
        <div class="stat-card">
            <div class="stat-icon total">
                <i class="fa-solid fa-users"></i>
            </div>
            <div class="stat-info">
                <h3>1,248</h3>
                <p>Total Clientes</p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon active">
                <i class="fa-solid fa-user-check"></i>
            </div>
            <div class="stat-info">
                <h3>1,185</h3>
                <p>Activos</p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon inactive">
                <i class="fa-solid fa-user-slash"></i>
            </div>
            <div class="stat-info">
                <h3>63</h3>
                <p>Inactivos</p>
            </div>
        </div>

        <div class="stat-card">
            <div class="stat-icon new">
                <i class="fa-solid fa-user-plus"></i>
            </div>
            <div class="stat-info">
                <h3>45</h3>
                <p>Nuevos (Este mes)</p>
            </div>
        </div>
    </div>

    <!-- Contenido Principal -->
    <div class="content-card">
        
        <!-- Barra de búsqueda y filtros -->
        <div class="search-filter-bar">
            <div class="search-box">
                <i class="fa-solid fa-search"></i>
                <input type="text" id="txtBuscar" placeholder="Buscar por nombre, correo o DNI..." onkeyup="filtrarTabla()" />
            </div>
            
            <div class="filter-group">
                <select id="ddlEstado" class="filter-select" onchange="filtrarTabla()">
                    <option value="">Todos los estados</option>
                    <option value="Activo">Activos</option>
                    <option value="Inactivo">Inactivos</option>
                </select>

                <select id="ddlOrden" class="filter-select" onchange="ordenarTabla()">
                    <option value="nombre">Ordenar por Nombre</option>
                    <option value="fecha">Ordenar por Fecha</option>
                    <option value="tarjetas">Ordenar por Tarjetas</option>
                </select>
            </div>
        </div>

        <!-- Tabla de clientes -->
        <div class="table-container">
            <table class="data-table" id="tablaClientes">
                <thead>
                    <tr>
                        <th>Cliente</th>
                        <th>DNI</th>
                        <th>Teléfono</th>
                        <th>Tarjetas</th>
                        <th>Fecha Registro</th>
                        <th>Estado</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">JP</div>
                                <div class="user-details">
                                    <h4>Juan Pérez García</h4>
                                    <p>juan.perez@gmail.com</p>
                                </div>
                            </div>
                        </td>
                        <td>72845693</td>
                        <td>987654321</td>
                        <td>2</td>
                        <td>15/10/2025</td>
                        <td><span class="badge active">Activo</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-view" onclick="verDetalle('Juan Pérez García')" title="Ver detalles">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarDesactivar('Juan Pérez García')" title="Desactivar">
                                    <i class="fa-solid fa-ban"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">MG</div>
                                <div class="user-details">
                                    <h4>María García López</h4>
                                    <p>maria.garcia@outlook.com</p>
                                </div>
                            </div>
                        </td>
                        <td>71234567</td>
                        <td>965432187</td>
                        <td>1</td>
                        <td>12/10/2025</td>
                        <td><span class="badge active">Activo</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-view" onclick="verDetalle('María García López')" title="Ver detalles">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarDesactivar('María García López')" title="Desactivar">
                                    <i class="fa-solid fa-ban"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">CR</div>
                                <div class="user-details">
                                    <h4>Carlos Rodríguez Soto</h4>
                                    <p>carlos.rodriguez@gmail.com</p>
                                </div>
                            </div>
                        </td>
                        <td>70987654</td>
                        <td>912345678</td>
                        <td>3</td>
                        <td>08/10/2025</td>
                        <td><span class="badge active">Activo</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-view" onclick="verDetalle('Carlos Rodríguez Soto')" title="Ver detalles">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarDesactivar('Carlos Rodríguez Soto')" title="Desactivar">
                                    <i class="fa-solid fa-ban"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">AL</div>
                                <div class="user-details">
                                    <h4>Ana López Martínez</h4>
                                    <p>ana.lopez@yahoo.com</p>
                                </div>
                            </div>
                        </td>
                        <td>73456789</td>
                        <td>998877665</td>
                        <td>1</td>
                        <td>05/10/2025</td>
                        <td><span class="badge inactive">Inactivo</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-view" onclick="verDetalle('Ana López Martínez')" title="Ver detalles">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarDesactivar('Ana López Martínez')" title="Activar">
                                    <i class="fa-solid fa-check"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>
                            <div class="user-info">
                                <div class="user-avatar">LT</div>
                                <div class="user-details">
                                    <h4>Luis Torres Vega</h4>
                                    <p>luis.torres@hotmail.com</p>
                                </div>
                            </div>
                        </td>
                        <td>74567890</td>
                        <td>923456789</td>
                        <td>2</td>
                        <td>01/10/2025</td>
                        <td><span class="badge active">Activo</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-view" onclick="verDetalle('Luis Torres Vega')" title="Ver detalles">
                                    <i class="fa-solid fa-eye"></i>
                                </button>
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarDesactivar('Luis Torres Vega')" title="Desactivar">
                                    <i class="fa-solid fa-ban"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Paginación -->
        <div class="pagination-container">
            <div class="pagination-info">
                Mostrando 1-5 de 1,248 clientes
            </div>
            <div class="pagination">
                <button disabled><i class="fa-solid fa-chevron-left"></i></button>
                <button class="active">1</button>
                <button>2</button>
                <button>3</button>
                <button>4</button>
                <button>5</button>
                <button>...</button>
                <button>250</button>
                <button><i class="fa-solid fa-chevron-right"></i></button>
            </div>
        </div>

    </div>

    <!-- Modal de Detalles -->
    <div class="modal-backdrop" id="modalDetalle">
        <div class="modal-content-custom">
            <div class="modal-header-custom">
                <h3><i class="fa-solid fa-user"></i> Detalles del Cliente</h3>
                <button class="btn-close-modal" onclick="cerrarModal()">&times;</button>
            </div>
            <div class="modal-body-custom">
                <div class="detail-row">
                    <span class="detail-label">Nombre Completo:</span>
                    <span class="detail-value" id="detNombre">Juan Pérez García</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">DNI:</span>
                    <span class="detail-value">72845693</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Correo:</span>
                    <span class="detail-value">juan.perez@gmail.com</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Teléfono:</span>
                    <span class="detail-value">987654321</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Dirección:</span>
                    <span class="detail-value">Av. Los Olivos 123, Lima</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Tarjetas:</span>
                    <span class="detail-value">2 tarjetas activas</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Última Recarga:</span>
                    <span class="detail-value">28/10/2025 - S/ 20.00</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Fecha Registro:</span>
                    <span class="detail-value">15/10/2025</span>
                </div>
                <div class="detail-row">
                    <span class="detail-label">Estado:</span>
                    <span class="detail-value"><span class="badge active">Activo</span></span>
                </div>
            </div>
        </div>
    </div>

    <script>
        // Filtrar tabla
        function filtrarTabla() {
            var input = document.getElementById("txtBuscar").value.toUpperCase();
            var estadoFiltro = document.getElementById("ddlEstado").value.toUpperCase();
            var tabla = document.getElementById("tablaClientes");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) {
                var fila = filas[i];
                var textoFila = fila.textContent || fila.innerText;
                
                var cumpleBusqueda = textoFila.toUpperCase().indexOf(input) > -1;
                var cumpleEstado = estadoFiltro === "" || textoFila.toUpperCase().indexOf(estadoFiltro) > -1;

                if (cumpleBusqueda && cumpleEstado) {
                    fila.style.display = "";
                } else {
                    fila.style.display = "none";
                }
            }
        }

        // Ordenar tabla (básico)
        function ordenarTabla() {
            alert("Función de ordenamiento - se implementará con datos del backend");
        }

        // Ver detalle
        function verDetalle(nombre) {
            document.getElementById("detNombre").textContent = nombre;
            document.getElementById("modalDetalle").classList.add("show");
        }

        // Cerrar modal
        function cerrarModal() {
            document.getElementById("modalDetalle").classList.remove("show");
        }

        // Cerrar modal al hacer clic fuera
        window.onclick = function(event) {
            var modal = document.getElementById("modalDetalle");
            if (event.target == modal) {
                cerrarModal();
            }
        }

        // Confirmar desactivar
        function confirmarDesactivar(nombre) {
            if (confirm("¿Está seguro de desactivar al cliente " + nombre + "?")) {
                alert("Cliente desactivado - se implementará con backend");
            }
        }
    </script>

</asp:Content>
