﻿<%@ Page Title="Pago Exitoso" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="RecargaExito.aspx.cs" Inherits="GoutuWA.RecargaExito" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Pago Exitoso
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        :root {
            --goutu-primary: #5e2a84;
        }

        .btn-goutu-primary {
            background-color: var(--goutu-primary);
            border-color: var(--goutu-primary);
            color: white;
            border-radius: 20px;
            padding: 12px;
            font-weight: 600;
            font-size: 1.1rem;
            transition: all 0.2s ease;
            text-decoration: none;
        }

        .btn-goutu-primary:hover {
            background-color: #4a1f63;
            border-color: #4a1f63;
            color: white;
            text-decoration: none;
        }

        /* Estilo para el Saldo Actual */
        .saldo-actual-container {
            margin-top: 3rem !important;
            margin-bottom: 3rem !important;
            text-align: center;
        }

        .saldo-actual-text {
            font-weight: 700; /* Negrita */
            font-size: 1.5rem;
            color: #333;
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
    <div class="container-fluid">
        <div class="row justify-content-center">
            <div class="col-md-10 col-lg-8 col-xl-6">
                <div class="card shadow-sm border-0 text-center" style="border-radius: 15px;">
                    <div class="card-body p-4 p-md-5">
                        <i class="fa-solid fa-check-circle fa-5x" style="color: #28a745; margin-bottom: 20px;"></i>

                        <h2 class="card-title" style="color: #5e2a84; font-weight: 600;">
                            <asp:Label ID="lblTituloExito" runat="server" Text="¡Pago Exitoso!"></asp:Label>
                        </h2>

                        <p class="lead">
                            <asp:Label ID="lblMensajeExito" runat="server" Text="Tu recarga se ha completado correctamente."></asp:Label>
                        </p>

                        <hr class="my-4" />

                        <div style="text-align: left; max-width: 400px; margin: auto;">
                            <div class="d-flex justify-content-between mb-2">
                                <asp:Label ID="lblTituloMontoFinal" runat="server" CssClass="text-muted" Text="Monto Recargado:"></asp:Label>
                                <asp:Label ID="lblMontoFinal" runat="server" style="font-weight: 600;"></asp:Label>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Tarjeta Transporte:</span>
                                <asp:Label ID="lblTarjetaFinal" runat="server" style="font-weight: 600;"></asp:Label>
                            </div>
                            <div class="d-flex justify-content-between mb-2">
                                <span class="text-muted">Medio de Pago:</span>
                                <asp:Label ID="lblMetodoPagoFinal" runat="server" style="font-weight: 600;"></asp:Label>
                            </div>
                        </div>

                        <%-- Nuevo campo: Saldo Actual --%>
                        <div class="saldo-actual-container">
                            <span class="saldo-actual-text">
                                Saldo Actual:
                                <asp:Label ID="lblSaldoActual" runat="server" Text="S/ 0.00"></asp:Label>
                            </span>
                        </div>

                        <div class="d-grid">
                            <asp:HyperLink NavigateUrl="~/MenuPrincipal.aspx" runat="server" CssClass="btn-goutu-primary">
                                Volver al Inicio
                            </asp:HyperLink>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</asp:Content>