﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="GestionConductores.aspx.cs" Inherits="GoutuWA.GestionConductores" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Conductores
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h2 {
            color: #4b0082;
            font-weight: 700;
            font-size: 32px;
            margin: 0;
        }

        .btn-add {
            background-color: #28a745;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-add:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
            color: white;
        }

        .content-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .search-bar {
            margin-bottom: 20px;
            position: relative;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .search-bar input:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
        }

        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table thead {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
        }

        .data-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            white-space: nowrap;
        }

        .data-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s ease;
        }

        .data-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .data-table td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .badge-empresa {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .badge-empresa.empresa-1 {
            background-color: #e3f2fd;
            color: #1976d2;
        }

        .badge-empresa.empresa-2 {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-action {
            padding: 8px 15px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-asignar {
            background-color: #fff3cd;
            color: #856404;
        }

        .btn-asignar:hover {
            background-color: #ffc107;
            color: white;
            transform: scale(1.05);
        }

        .btn-quitar {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-quitar:hover {
            background-color: #dc3545;
            color: white;
            transform: scale(1.05);
        }

        /* Modal Styles */
        .modal-overlay {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.5);
            z-index: 9999;
            align-items: center;
            justify-content: center;
        }

        .modal-content {
            background: white;
            border-radius: 15px;
            padding: 30px;
            width: 90%;
            max-width: 500px;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            position: relative;
            margin: 20px;
        }

        .modal-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 25px;
            padding-bottom: 15px;
            border-bottom: 2px solid #4b0082;
        }

        .modal-title {
            color: #4b0082;
            font-size: 24px;
            font-weight: 700;
            margin: 0;
        }

        .close-modal {
            background: none;
            border: none;
            font-size: 24px;
            color: #999;
            cursor: pointer;
            transition: color 0.3s ease;
        }

        .close-modal:hover {
            color: #4b0082;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            font-weight: 600;
            color: #333;
            font-size: 14px;
        }

        .form-control {
            width: 100%;
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
            background-color: white;
        }

        .form-control:focus {
            outline: none;
            border-color: #4b0082;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .form-control:disabled {
            background-color: #f8f9fa;
            color: #666;
            cursor: not-allowed;
        }

        .transporte-list {
            max-height: 200px;
            overflow-y: auto;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            background: white;
        }

        .transporte-item {
            padding: 12px 15px;
            border-bottom: 1px solid #f0f0f0;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .transporte-item:hover {
            background-color: #f8f9fa;
        }

        .transporte-item.selected {
            background-color: #4b0082;
            color: white;
        }

        .transporte-placa {
            font-weight: 600;
            font-size: 14px;
        }

        .modal-actions {
            display: flex;
            gap: 15px;
            justify-content: flex-end;
            margin-top: 25px;
            padding-top: 20px;
            border-top: 1px solid #e0e0e0;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(75, 0, 130, 0.3);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .table-container {
                overflow-x: scroll;
            }

            .data-table {
                min-width: 600px;
            }

            .modal-content {
                width: 95%;
                margin: 20px;
                padding: 20px;
            }

            .modal-actions {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <!-- Header -->
    <div class="page-header">
        <h2><i class="fa-solid fa-id-card"></i> Gestión de Conductores</h2>
        <a href="RegistrarConductor.aspx" class="btn-add">
            <i class="fa-solid fa-plus"></i>
            Registrar Conductor
        </a>
    </div>

    <!-- Contenido Principal -->
    <div class="content-card">
        
        <!-- Barra de búsqueda -->
        <div class="search-bar">
            <i class="fa-solid fa-search"></i>
            <input type="text" id="txtBuscar" placeholder="Buscar por nombre, DNI o licencia..." onkeyup="filtrarTabla()" />
        </div>

        <!-- Tabla de conductores -->
        <div class="table-container">
           <asp:GridView ID="gvConductores" runat="server" CssClass="data-table" 
    AutoGenerateColumns="False" OnRowCommand="gvConductores_RowCommand"
    EmptyDataText="No hay conductores registrados"
    DataKeyNames="IdConductor,IdTransporte">
    <Columns>
        <asp:BoundField DataField="NombreCompleto" HeaderText="Nombre Completo" />
        <asp:BoundField DataField="DNI" HeaderText="DNI" />
        <asp:BoundField DataField="NumeroLicencia" HeaderText="N° Licencia" />
        <asp:BoundField DataField="PlacaTransporte" HeaderText="Transporte Asignado" />
        <asp:BoundField DataField="NombreRuta" HeaderText="Ruta" />
        <asp:BoundField DataField="NombreServicio" HeaderText="Servicio" />
        <asp:TemplateField HeaderText="Acciones">
            <ItemTemplate>
                <div class="action-buttons">
                    <asp:Button ID="btnAsignar" runat="server" Text="Asignar Transporte" 
                        CssClass="btn-action btn-asignar" 
                        CommandName="Editar" 
                        CommandArgument='<%# Container.DataItemIndex %>' />
                    <asp:Button ID="btnQuitar" runat="server" Text="Quitar Transporte" 
                        CssClass="btn-action btn-quitar" 
                        CommandName="Eliminar" 
                        CommandArgument='<%# Container.DataItemIndex %>'
                        OnClientClick='<%# "return confirmarEliminar(\"" + Eval("NombreCompleto") + "\");" %>' 
                        Visible='<%# Eval("IdTransporte").ToString() != "0" %>' />
                </div>
            </ItemTemplate>
        </asp:TemplateField>
    </Columns>
</asp:GridView>
        </div>

    </div>
<!-- Modal de Edición -->
<div class="modal-overlay" id="modalEditar">
    <div class="modal-content">
        <div class="modal-header">
            <h3 class="modal-title"><i class="fa-solid fa-bus"></i> Asignar Transporte</h3>
            <button class="close-modal" onclick="cerrarModal()">&times;</button>
        </div>

        <asp:HiddenField ID="hfIdConductor" runat="server" />
        <asp:HiddenField ID="hfIdTransporte" runat="server" />

        <div class="form-group">
            <label for="txtNombreConductor"><i class="fa-solid fa-user"></i> Conductor</label>
            <asp:TextBox ID="txtNombreConductor" runat="server" CssClass="form-control" Enabled="false"></asp:TextBox>
        </div>

        <div class="form-group">
            <label><i class="fa-solid fa-car"></i> Seleccionar Transporte Disponible</label>
            <div class="transporte-list" id="listaTransportes">
                <asp:Repeater ID="rptTransportes" runat="server">
                    <ItemTemplate>
                        <div class="transporte-item" onclick="seleccionarTransporte(<%# Eval("IdTransporte") %>, '<%# Eval("Placa") %>')">
                            <div class="transporte-placa"><%# Eval("Placa") %></div>
                        </div>
                    </ItemTemplate>
                </asp:Repeater>
                <asp:Label ID="lblNoTransportes" runat="server" CssClass="no-transportes" 
                    Text="No hay transportes disponibles sin conductor" Visible="false"></asp:Label>
            </div>
        </div>

        <div class="modal-actions">
            <button type="button" class="btn btn-secondary" onclick="cerrarModal()">Cancelar</button>
            <asp:Button ID="btnGuardar" runat="server" Text="Asignar Transporte" 
                CssClass="btn btn-primary" OnClick="btnGuardar_Click" OnClientClick="return validarSeleccion();" />
        </div>
    </div>
</div>

    <script>
        let transporteSeleccionado = null;

        // Filtrar tabla principal
        function filtrarTabla() {
            var input = document.getElementById("txtBuscar").value.toUpperCase();
            var tabla = document.getElementById("<%= gvConductores.ClientID %>");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) {
                var fila = filas[i];
                var textoFila = fila.textContent || fila.innerText;
                
                if (textoFila.toUpperCase().indexOf(input) > -1) {
                    fila.style.display = "";
                } else {
                    fila.style.display = "none";
                }
            }
        }

        // Abrir modal de edición
        function abrirModalEditar(nombreConductor, transporteActual) {
            document.getElementById('<%= txtNombreConductor.ClientID %>').value = nombreConductor;
            document.getElementById('modalEditar').style.display = 'flex';
        }

        // Cerrar modal
        function cerrarModal() {
            document.getElementById('modalEditar').style.display = 'none';
            transporteSeleccionado = null;
            
            // Limpiar selección
            document.querySelectorAll('.transporte-item').forEach(item => {
                item.classList.remove('selected');
            });
            document.getElementById('<%= hfIdTransporte.ClientID %>').value = '';
        }

        // Seleccionar transporte
        function seleccionarTransporte(idTransporte, placa) {
            // Remover selección anterior
            document.querySelectorAll('.transporte-item').forEach(item => {
                item.classList.remove('selected');
            });
            
            // Agregar selección actual
            event.target.closest('.transporte-item').classList.add('selected');
            
            // Guardar el ID del transporte
            document.getElementById('<%= hfIdTransporte.ClientID %>').value = idTransporte;

            console.log("Transporte seleccionado - ID:", idTransporte, "Placa:", placa);
        }

        // Confirmar quitar transporte
        function confirmarEliminar(nombre) {
            return confirm("¿Está seguro de quitar el transporte al conductor " + nombre + "?");
        }

        // Cerrar modal al hacer clic fuera
        document.getElementById('modalEditar').addEventListener('click', function (e) {
            if (e.target === this) {
                cerrarModal();
            }
        });

        // Prevenir que los clics dentro del modal cierren el modal
        document.querySelector('.modal-content').addEventListener('click', function (e) {
            e.stopPropagation();
        });
    </script>

</asp:Content>