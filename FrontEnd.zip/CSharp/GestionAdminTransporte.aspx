﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuAdminSistemas.Master" AutoEventWireup="true" CodeBehind="GestionAdminTransporte.aspx.cs" Inherits="GoutuWA.GestionAdminTransporte" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Admin Transporte
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .page-header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 30px;
            flex-wrap: wrap;
            gap: 15px;
        }

        .page-header h2 {
            color: #4b0082;
            font-weight: 700;
            font-size: 32px;
            margin: 0;
        }

        .btn-add {
            background-color: #28a745;
            color: white;
            padding: 12px 24px;
            border: none;
            border-radius: 8px;
            font-weight: 600;
            text-decoration: none;
            display: flex;
            align-items: center;
            gap: 8px;
            transition: all 0.3s ease;
        }

        .btn-add:hover {
            background-color: #218838;
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(40, 167, 69, 0.3);
            color: white;
        }

        .content-card {
            background: white;
            border-radius: 15px;
            padding: 25px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
        }

        .search-bar {
            margin-bottom: 20px;
            position: relative;
        }

        .search-bar input {
            width: 100%;
            padding: 12px 15px 12px 45px;
            border: 2px solid #e0e0e0;
            border-radius: 10px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .search-bar input:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .search-bar i {
            position: absolute;
            left: 15px;
            top: 50%;
            transform: translateY(-50%);
            color: #999;
            font-size: 16px;
        }

        .table-container {
            overflow-x: auto;
        }

        .data-table {
            width: 100%;
            border-collapse: collapse;
        }

        .data-table thead {
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
        }

        .data-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
            white-space: nowrap;
        }

        .data-table tbody tr {
            border-bottom: 1px solid #f0f0f0;
            transition: all 0.3s ease;
        }

        .data-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .data-table td {
            padding: 15px;
            font-size: 14px;
            color: #333;
        }

        .badge-empresa {
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 12px;
            font-weight: 600;
            display: inline-block;
        }

        .badge-empresa.empresa-1 {
            background-color: #e3f2fd;
            color: #1976d2;
        }

        .badge-empresa.empresa-2 {
            background-color: #f3e5f5;
            color: #7b1fa2;
        }

        .action-buttons {
            display: flex;
            gap: 8px;
        }

        .btn-action {
            width: 35px;
            height: 35px;
            border: none;
            border-radius: 8px;
            display: flex;
            align-items: center;
            justify-content: center;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-edit {
            background-color: #fff3cd;
            color: #856404;
        }

        .btn-edit:hover {
            background-color: #ffc107;
            color: white;
            transform: scale(1.1);
        }

        .btn-delete {
            background-color: #f8d7da;
            color: #721c24;
        }

        .btn-delete:hover {
            background-color: #dc3545;
            color: white;
            transform: scale(1.1);
        }

        .pagination-container {
            display: flex;
            justify-content: center;
            margin-top: 20px;
            gap: 5px;
        }

        .pagination-container button {
            padding: 8px 12px;
            border: 2px solid #e0e0e0;
            background-color: white;
            border-radius: 8px;
            cursor: pointer;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .pagination-container button:hover {
            border-color: #4b0082;
            color: #4b0082;
        }

        .pagination-container button.active {
            background-color: #4b0082;
            color: white;
            border-color: #4b0082;
        }

        @media (max-width: 768px) {
            .page-header {
                flex-direction: column;
                align-items: flex-start;
            }

            .table-container {
                overflow-x: scroll;
            }

            .data-table {
                min-width: 500px;
            }
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    
    <!-- Header -->
    <div class="page-header">
        <h2><i class="fa-solid fa-user-tie"></i> Gestión de Administradores de Transporte</h2>
        <a href="RegistrarAdminTransporte.aspx" class="btn-add">
            <i class="fa-solid fa-plus"></i>
            Registrar Admin Transporte
        </a>
    </div>

    <!-- Contenido Principal -->
    <div class="content-card">
        
        <!-- Barra de búsqueda -->
        <div class="search-bar">
            <i class="fa-solid fa-search"></i>
            <input type="text" id="txtBuscar" placeholder="Buscar por nombre o DNI..." onkeyup="filtrarTabla()" />
        </div>

        <!-- Tabla de administradores -->
        <div class="table-container">
            <table class="data-table" id="tablaAdminTransporte">
                <thead>
                    <tr>
                        <th>Nombre Completo</th>
                        <th>DNI</th>
                        <th>ID Empresa</th>
                        <th>Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>Pedro Antonio García Mendoza</td>
                        <td>42156789</td>
                        <td><span class="badge-empresa empresa-1">Empresa 1</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Pedro Antonio García Mendoza')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Ana María Rodríguez López</td>
                        <td>43267891</td>
                        <td><span class="badge-empresa empresa-2">Empresa 2</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Ana María Rodríguez López')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Jorge Luis Martínez Silva</td>
                        <td>41987654</td>
                        <td><span class="badge-empresa empresa-1">Empresa 1</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Jorge Luis Martínez Silva')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Carmen Rosa Fernández Torres</td>
                        <td>44567823</td>
                        <td><span class="badge-empresa empresa-2">Empresa 2</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Carmen Rosa Fernández Torres')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Roberto Carlos Díaz Salazar</td>
                        <td>42789456</td>
                        <td><span class="badge-empresa empresa-1">Empresa 1</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Roberto Carlos Díaz Salazar')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>María Elena Vásquez Ruiz</td>
                        <td>43891234</td>
                        <td><span class="badge-empresa empresa-2">Empresa 2</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('María Elena Vásquez Ruiz')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Francisco Javier Sánchez Pérez</td>
                        <td>41456789</td>
                        <td><span class="badge-empresa empresa-1">Empresa 1</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Francisco Javier Sánchez Pérez')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Laura Patricia Herrera Castro</td>
                        <td>44234567</td>
                        <td><span class="badge-empresa empresa-2">Empresa 2</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Laura Patricia Herrera Castro')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Diego Alejandro Morales Gutiérrez</td>
                        <td>42345678</td>
                        <td><span class="badge-empresa empresa-1">Empresa 1</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Diego Alejandro Morales Gutiérrez')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>

                    <tr>
                        <td>Claudia Isabel Ramírez Flores</td>
                        <td>43678912</td>
                        <td><span class="badge-empresa empresa-2">Empresa 2</span></td>
                        <td>
                            <div class="action-buttons">
                                <button class="btn-action btn-edit" title="Editar">
                                    <i class="fa-solid fa-edit"></i>
                                </button>
                                <button class="btn-action btn-delete" onclick="confirmarEliminar('Claudia Isabel Ramírez Flores')" title="Eliminar">
                                    <i class="fa-solid fa-trash"></i>
                                </button>
                            </div>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>

        <!-- Paginación -->
        <div class="pagination-container">
            <button disabled><i class="fa-solid fa-chevron-left"></i></button>
            <button class="active">1</button>
            <button>2</button>
            <button>3</button>
            <button><i class="fa-solid fa-chevron-right"></i></button>
        </div>

    </div>

    <script>
        // Filtrar tabla
        function filtrarTabla() {
            var input = document.getElementById("txtBuscar").value.toUpperCase();
            var tabla = document.getElementById("tablaAdminTransporte");
            var filas = tabla.getElementsByTagName("tr");

            for (var i = 1; i < filas.length; i++) {
                var fila = filas[i];
                var textoFila = fila.textContent || fila.innerText;
                
                if (textoFila.toUpperCase().indexOf(input) > -1) {
                    fila.style.display = "";
                } else {
                    fila.style.display = "none";
                }
            }
        }

        // Confirmar eliminar
        function confirmarEliminar(nombre) {
            if (confirm("¿Está seguro de eliminar al administrador " + nombre + "?")) {
                alert("Administrador eliminado - se implementará con backend");
            }
        }
    </script>

</asp:Content>
