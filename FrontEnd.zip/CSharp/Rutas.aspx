﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuCuenta.Master"
    AutoEventWireup="true" CodeBehind="Rutas.aspx.cs" Inherits="GoutuWA.Rutas" %>

<asp:Content ID="c1" ContentPlaceHolderID="cph_Title" runat="server">Rutas</asp:Content>

<asp:Content ID="c2" ContentPlaceHolderID="cph_Scripts" runat="server">
  <style>
    .page-container { display:flex; flex-direction:column; align-items:center; min-height:70vh; }
    .titulo-seccion { text-align:center; font-size:2rem; margin:32px 0 12px; font-weight:700; color:#333; }
    .sub { color:#6b7280; margin-bottom:24px; }

    .grid {
      display:flex; flex-wrap:wrap; gap:20px; justify-content:center; padding: 0 24px 32px;
    }
    .tile-btn {
      background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
      color:#fff; border:none; border-radius:18px; padding:26px 20px;
      min-width:240px; height:110px; display:flex; align-items:center; justify-content:center;
      font-size:1.1rem; font-weight:700; cursor:pointer; transition:.25s ease all;
      box-shadow:0 6px 20px rgba(0,0,0,.15);
    }
    .tile-btn:hover { transform:translateY(-6px); filter:brightness(1.06); }

    .panel {
      width:100%; max-width:1080px; background:#fff; border-radius:16px; padding:20px;
      box-shadow: 0 6px 26px rgba(0,0,0,.06);
      margin-bottom:24px;
    }
    .panel h2 { margin:0 0 10px 0; font-size:1.25rem; }
    .rutas-grid .tile-btn {
      background: linear-gradient(135deg, #10b981 0%, #059669 100%);
    }
    .rutas-grid .tile-btn:hover { filter:brightness(1.06); }
  </style>
</asp:Content>

<asp:Content ID="c3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
  <div class="page-container">
    <h1 class="titulo-seccion">Selecciona un Servicio</h1>
    <div class="grid">
      <asp:PlaceHolder ID="phServicios" runat="server"></asp:PlaceHolder>
    </div>

    <asp:Panel ID="pnlRutas" runat="server" CssClass="panel" Visible="false">
      <h2>Rutas de <asp:Literal ID="ltServicioSel" runat="server" /></h2>
      <div class="grid rutas-grid">
        <asp:PlaceHolder ID="phRutas" runat="server"></asp:PlaceHolder>
      </div>
    </asp:Panel>
  </div>
</asp:Content>
