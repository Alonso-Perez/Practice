﻿<%@ Page Title="Validar Codigo" Language="C#" MasterPageFile="~/GouTuValidacion.Master"
    AutoEventWireup="true" CodeBehind="CodigoEmail.aspx.cs" Inherits="GoutuWA.CodigoEmail" %>

<asp:Content ID="Content1" ContentPlaceHolderID="AuthContent" runat="server">

    <div class="auth-card">

        <div class="text-center mb-3">
            <h3 class="fw-bold">Verificación</h3>
            <p class="text-muted" style="font-size: 15px;">Ingresa el código enviado a tu correo</p>
        </div>

        <!-- CÓDIGO DIFUMINADO -->
        <div class="mb-3">
            <asp:Label ID="lblCodigo" runat="server" Text="Código de verificación"></asp:Label>
            <asp:TextBox ID="txtCodigo"
                runat="server"
                CssClass="form-control text-center"
                MaxLength="6"
                placeholder="• • • • • •"
                Style="letter-spacing: 8px; font-size: 24px; padding: 12px; opacity:0.85;">
            </asp:TextBox>
        </div>

        <asp:Label ID="lblMensaje" runat="server" CssClass="text-danger"></asp:Label>

        <div class="d-grid my-3">
            <asp:Button ID="btnValidar"
                runat="server"
                Text="Validar Código"
                CssClass="btn btn-primary"
                Style="padding: 10px; font-size: 16px; border-radius: 10px;"
                OnClick="btnValidar_Click" />
        </div>

        <!-- BOTÓN REENVIAR + TIEMPO -->
        <div class="text-center mt-3">
            <asp:Button ID="btnReenviar"
                runat="server"
                Text="Reenviar código"
                CssClass="btn btn-link"
                Style="text-decoration:none; font-weight:bold; opacity:0.6;"
                OnClick="btnReenviar_Click" />
            <br />

            <span id="timerText" style="font-size:14px; color:#6c757d;"></span>
        </div>

    </div>

    <script>
        let button = document.getElementById("<%= btnReenviar.ClientID %>");
        let timerText = document.getElementById("timerText");

        function iniciarTimer() {
            button.disabled = true;
            let tiempo = 30;

            timerText.innerText = "Puedes reenviar el código en " + tiempo + "s";

            let intervalo = setInterval(() => {
                tiempo--;
                timerText.innerText = "Puedes reenviar el código en " + tiempo + "s";

                if (tiempo <= 0) {
                    clearInterval(intervalo);
                    timerText.innerText = "";
                    button.disabled = false;
                }
            }, 1000);
        }

        // Inicia automáticamente al cargar
        window.onload = function () {
            iniciarTimer();
        };
    </script>

</asp:Content>
