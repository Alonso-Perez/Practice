﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuMaster.Master" AutoEventWireup="true"  CodeBehind="Inicio.aspx.cs" Inherits="GoutuWA.Inicio" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Inicio - Goutu
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        .inicio-container {
            min-height: calc(100vh - 150px);
            display: flex;
            align-items: center;
            padding: 20px;
        }

        .imagen-container {
            display: flex;
            align-items: center;
            justify-content: center;
            padding-right: 30px;
        }

        .imagen-container img {
            max-width: 100%;
            height: auto;
            max-height: 80vh;
            object-fit: contain;
        }

        .contenido-container {
            display: flex;
            flex-direction: column;
            justify-content: center;
            padding-left: 30px;
        }

        .titulo-bienvenida {
            margin-bottom: 30px;
        }

        .titulo-bienvenida h5 {
            font-size: 50px;
            line-height: 1.2;
            margin: 0;
            display: inline;
        }

        .titulo-bienvenida .goutu-color {
            color: #4b0082;
        }

        .descripcion-texto {
            font-size: 20px;
            line-height: 1.6;
            color: #555;
            text-align: justify;
            margin-bottom: 0;
        }

        /* Estilos del modal */
        .modal-content {
            border-radius: 15px;
            border: none;
            box-shadow: 0 5px 20px rgba(0,0,0,0.1);
        }

        .modal-header {
            background-color: #4b0082;
            color: white;
            border-radius: 15px 15px 0 0;
            padding: 20px 25px;
        }

        .modal-header .btn-close {
            filter: brightness(0) invert(1);
        }

        .modal-body {
            padding: 30px;
        }

        .credentials-form .form-label {
            font-weight: 500;
            color: #333;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .credentials-form .form-control {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .credentials-form .form-control:focus {
            border-color: #4b0082;
            outline: none;
            box-shadow: 0 0 0 3px rgba(75, 0, 130, 0.1);
        }

        .login-options {
            display: flex;
            flex-direction: column;
            gap: 15px;
            margin-bottom: 20px;
        }

        .login-option-btn {
            background: white;
            border: 2px solid #e0e0e0;
            border-radius: 12px;
            padding: 20px;
            text-align: center;
            text-decoration: none;
            color: #333;
            cursor: pointer;
            transition: all 0.3s ease;
            display: flex;
            align-items: center;
            justify-content: center;
            gap: 15px;
        }

        .login-option-btn:hover {
            border-color: #4b0082;
            background: linear-gradient(135deg, #4b0082, #6a0dad);
            color: white;
            transform: translateY(-3px);
            box-shadow: 0 5px 15px rgba(75, 0, 130, 0.3);
        }

        .login-option-btn i {
            font-size: 28px;
        }

        .login-option-btn span {
            font-weight: 600;
            font-size: 16px;
        }

        .btn-outline-primary {
            padding: 10px 20px;
            border-radius: 8px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-outline-primary:hover {
            background-color: #4b0082;
            border-color: #4b0082;
            color: white !important;
            transform: translateY(-2px);
        }

        .validation-message {
            color: #dc3545;
            font-size: 13px;
            margin-top: 5px;
            display: none;
        }

        .validation-message.show {
            display: block;
        }

        .input-error {
            border-color: #dc3545 !important;
        }

        .alert {
            border-radius: 8px;
            padding: 12px 15px;
            margin-bottom: 15px;
        }

        @media (max-width: 992px) {
            .inicio-container {
                flex-direction: column;
                min-height: auto;
            }

            .imagen-container {
                padding-right: 0;
                margin-bottom: 30px;
            }

            .contenido-container {
                padding-left: 0;
            }

            .titulo-bienvenida h5 {
                font-size: 35px;
            }

            .descripcion-texto {
                font-size: 18px;
            }
        }

        @media (max-width: 576px) {
            .titulo-bienvenida h5 {
                font-size: 28px;
            }

            .descripcion-texto {
                font-size: 16px;
            }
        }
    </style>

    <script type="text/javascript">
        $(document).ready(function () {
            // Limpiar mensajes al abrir el modal
            $('#modalIniciarSesion').on('show.bs.modal', function () {
                $('#<%= txtCorreo.ClientID %>').val('').removeClass('input-error');
        $('#<%= txtContrasena.ClientID %>').val('').removeClass('input-error');
        $('.validation-message').removeClass('show');
        $('#loginAlert').remove();
    });

            // Validación en tiempo real del correo
            $('#<%= txtCorreo.ClientID %>').on('blur', function () {
                var email = $(this).val();
                var regex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

                if (email && !regex.test(email)) {
                    $(this).addClass('input-error');
                } else {
                    $(this).removeClass('input-error');
                }
            });

            // Manejar clic en botones de login
            $('.login-option-btn').on('click', function (e) {
                e.preventDefault();
                var role = $(this).attr('data-role');

                // CAMBIO CRÍTICO: Validar credenciales para TODOS los roles
                if (!validarCredenciales()) {
                    return; // Detener si la validación falla
                }

                // Ejecutar el postback correspondiente según el rol
                if (role === 'cliente') {
            <%= Page.ClientScript.GetPostBackEventReference(btnIniciarSesion, "") %>;
        } else if (role === 'admin-sistema') {
            window.location.href = 'MenuAdminSistemas.aspx';
        } else if (role === 'admin-transporte') {
            __doPostBack('<%= btnIniciarSesionAdminTransporte.UniqueID %>', '');
        } else if (role === 'conductor') {
            __doPostBack('<%= btnIniciarSesionConductor.UniqueID %>', '');
        }
    });

    // Permitir login con Enter
    $('#<%= txtContrasena.ClientID %>').on('keypress', function (e) {
        if (e.which === 13) { // Enter key
            e.preventDefault();
            // Intentar con el primer botón visible o cliente por defecto
            $('.login-option-btn[data-role="cliente"]').trigger('click');
        }
    });
});

// FUNCIÓN SEPARADA: Solo valida campos, NO ejecuta postback
function validarCredenciales() {
    var email = $('#<%= txtCorreo.ClientID %>').val().trim();
    var password = $('#<%= txtContrasena.ClientID %>').val();

    // Limpiar mensajes previos
    $('.validation-message').removeClass('show');
    $('.input-error').removeClass('input-error');
    $('#loginAlert').remove();

    // Validaciones básicas
    if (email === '') {
        $('#<%= txtCorreo.ClientID %>').addClass('input-error');
        mostrarAlerta('Por favor ingrese su correo electrónico', 'warning');
        return false;
    }

    if (password === '') {
        $('#<%= txtContrasena.ClientID %>').addClass('input-error');
        mostrarAlerta('Por favor ingrese su contraseña', 'warning');
        return false;
    }

    var emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
                $('#<%= txtCorreo.ClientID %>').addClass('input-error');
                mostrarAlerta('Ingrese un correo válido', 'warning');
                return false;
            }

            return true; // Validación exitosa
        }

        function mostrarAlerta(mensaje, tipo) {
            var alertHtml = '<div id="loginAlert" class="alert alert-' + tipo + ' alert-dismissible fade show" role="alert">' +
                mensaje +
                '<button type="button" class="btn-close" data-bs-dismiss="alert"></button>' +
                '</div>';

            $('#loginAlert').remove();
            $('.modal-body').prepend(alertHtml);

            setTimeout(function () {
                $('#loginAlert').fadeOut('slow', function () {
                    $(this).remove();
                });
            }, 5000);
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_Contenido" runat="server">
    <div class="container-fluid inicio-container">
        <div class="row w-100 align-items-center">
            <!-- Columna de la imagen -->
            <div class="col-lg-6 imagen-container">
                <img src="images/FondoInicio.jpg" alt="Goutu - Plataforma de transporte" />
            </div>
            
            <!-- Columna del contenido -->
            <div class="col-lg-6 contenido-container">
                <div class="titulo-bienvenida">
                    <h5>¡Bienvenidos a </h5>
                    <h5 class="goutu-color">GOUTU!</h5>
                </div>
                
                <p class="descripcion-texto">
                    Tu plataforma confiable para la recarga de tus tarjetas
                    de transporte, realización de trámites rápidos y accesibles
                    y que puedas ubicar tu transporte en tiempo real.
                </p>
            </div>
        </div>
    </div>

    <!-- Modal de Iniciar Sesión -->
    <div class="modal fade" id="modalIniciarSesion" tabindex="-1" aria-labelledby="modalIniciarSesionLabel" aria-hidden="true">
        <div class="modal-dialog modal-dialog-centered">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalIniciarSesionLabel">Iniciar Sesión</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <h6 class="text-center mb-4" style="color: #4b0082; font-weight: 600;">Iniciar Sesión en Goutu</h6>
                    
                    <!-- Formulario de credenciales -->
                    <div class="credentials-form mb-4">
                        <div class="mb-3">
                            <label for="<%= txtCorreo.ClientID %>" class="form-label">Correo Electrónico</label>
                            <asp:TextBox ID="txtCorreo" runat="server" CssClass="form-control" 
                                placeholder="ejemplo@correo.com" TextMode="Email"></asp:TextBox>
                        </div>
                        <div class="mb-3">
                            <label for="<%= txtContrasena.ClientID %>" class="form-label">Contraseña</label>
                            <asp:TextBox ID="txtContrasena" runat="server" CssClass="form-control" 
                                placeholder="Ingrese su contraseña" TextMode="Password"></asp:TextBox>
                        </div>

                        <div class="text-end mt-1">
                            <asp:HyperLink ID="lnkOlvido" runat="server" 
                                NavigateUrl="RecuperarContraseña.aspx" 
                                Text="¿Olvidaste la contraseña?" 
                                Style="font-size:13px; color:#4b0082; text-decoration:none;">
                            </asp:HyperLink>
                        </div>
                    </div>

                    <h6 class="text-center mb-3" style="color: #666; font-size: 14px; font-weight: 500;">Seleccione cómo desea ingresar</h6>
                    
                    <div class="login-options">
                        <a href="#" data-role="cliente" class="login-option-btn">
                            <i class="fa-solid fa-user"></i>
                            <span>Iniciar como Cliente</span>
                        </a>
                        
                        <a href="#" data-role="admin-sistema" class="login-option-btn">
                            <i class="fa-solid fa-user-shield"></i>
                            <span>Iniciar como Admin Sistema</span>
                        </a>

                        <a href="#" data-role="admin-transporte" class="login-option-btn">
                            <i class="fa-solid fa-building"></i>
                            <span>Iniciar como Admin Transporte</span>
                        </a>

                        <a href="#" data-role="conductor" class="login-option-btn">
                            <i class="fa-solid fa-bus"></i>
                            <span>Iniciar como Conductor</span>
                        </a>
                    </div>

                    <div class="text-center mt-4">
                        <p class="mb-2" style="color: #666; font-size: 14px;">¿No tienes cuenta?</p>
                        <a href="RegistrarUsuario.aspx" class="btn btn-outline-primary" style="border: 2px solid #4b0082; color: #4b0082;">
                            <i class="fa-solid fa-user-plus"></i> Registrarse
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Botón oculto para postback -->
    <asp:Button ID="btnIniciarSesion" runat="server" Style="display:none;" OnClick="btnIniciarSesion_Click" />
    <!-- Botón oculto para postback Conductor -->
<asp:Button ID="btnIniciarSesionConductor" runat="server" Style="display:none;" OnClick="btnIniciarSesionConductor_Click" />
<!-- Botón oculto para postback Admin Transporte - AGREGAR ESTO -->
<asp:Button ID="btnIniciarSesionAdminTransporte" runat="server" Style="display:none;" OnClick="btnIniciarSesionAdminTransporte_Click" />
</asp:Content>