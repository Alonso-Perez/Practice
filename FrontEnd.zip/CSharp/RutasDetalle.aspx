﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuCuenta.Master"
    AutoEventWireup="true" CodeBehind="RutasDetalle.aspx.cs" Inherits="GoutuWA.RutasDetalle" %>

<asp:Content ID="c1" ContentPlaceHolderID="cph_Title" runat="server">Detalle de Ruta</asp:Content>

<asp:Content ID="c2" ContentPlaceHolderID="cph_Scripts" runat="server">
  <script src="Scripts/bootstrap.min.js"></script>
</asp:Content>

<asp:Content ID="c3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
  <!-- Encabezado -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div>
      <a href="Rutas.aspx" class="text-decoration-none">&laquo; Volver a Rutas</a>
      <h3 class="m-0">Detalle de Ruta</h3>
      <div class="text-muted">
        ID: <asp:Label ID="lblIdRuta" runat="server" /> ·
        Nombre: <asp:Label ID="lblNombreRuta" runat="server" />
      </div>
    </div>
    <asp:LinkButton ID="btnNuevoParadero" runat="server" CssClass="btn text-white"
      Style="background-color:#4b0082"
      OnClientClick="$('#modalParadero').modal('show'); return false;">
      + Agregar Paradero
    </asp:LinkButton>
  </div>

  <!-- Grid de Paraderos -->
  <asp:GridView ID="gvParaderos" runat="server" CssClass="table table-striped"
      AutoGenerateColumns="False" GridLines="None">
    <Columns>
      <asp:BoundField DataField="id_paradero" HeaderText="ID" />
      <asp:BoundField DataField="orden" HeaderText="Orden" />
      <asp:BoundField DataField="nombre" HeaderText="Nombre del Paradero" />
      <asp:BoundField DataField="latitud" HeaderText="Latitud" />
      <asp:BoundField DataField="longitud" HeaderText="Longitud" />
      <asp:BoundField DataField="tiempo_estimado" HeaderText="T. Estimado (min)" />
      <asp:CheckBoxField DataField="activo" HeaderText="Activo" />
      <asp:ButtonField Text="Editar" CommandName="Editar" />
      <asp:ButtonField Text="Eliminar" CommandName="Eliminar" />
    </Columns>
  </asp:GridView>

  <!-- (Opcional) Previsualización de mapa -->
  <div class="card mt-3">
    <div class="card-body">
      <h5 class="card-title mb-2">Mapa de referencia</h5>
      <div class="bg-light border rounded d-flex align-items-center justify-content-center"
           style="height:300px;">
        <span class="text-muted">Aquí podría ir un mapa (placeholder)</span>
      </div>
    </div>
  </div>

  <!-- Modal Crear/Editar Paradero -->
  <div class="modal fade" id="modalParadero" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content p-3">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="m-0" style="color:#4b0082;">Paradero</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-4">
            <label class="form-label">Orden</label>
            <asp:TextBox ID="txtOrden" runat="server" CssClass="form-control" TextMode="Number" />
          </div>
          <div class="col-8">
            <label class="form-label">Nombre</label>
            <asp:TextBox ID="txtNombreParadero" runat="server" CssClass="form-control" />
          </div>
          <div class="col-6">
            <label class="form-label">Latitud</label>
            <asp:TextBox ID="txtLatitud" runat="server" CssClass="form-control" />
          </div>
          <div class="col-6">
            <label class="form-label">Longitud</label>
            <asp:TextBox ID="txtLongitud" runat="server" CssClass="form-control" />
          </div>
          <div class="col-6">
            <label class="form-label">T. estimado (min)</label>
            <asp:TextBox ID="txtTiempoEstimado" runat="server" CssClass="form-control" TextMode="Number" />
          </div>
          <div class="col-6 d-flex align-items-center">
            <asp:CheckBox ID="chkActivoParadero" runat="server" CssClass="form-check-input me-2" />
            <label class="form-check-label">Activo</label>
          </div>
        </div>

        <div class="mt-3 d-flex justify-content-end gap-2">
          <asp:LinkButton ID="btnGuardarParadero" runat="server" CssClass="btn text-white"
            Style="background-color:#4b0082">Guardar</asp:LinkButton>
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </div>
  </div>
</asp:Content>
