﻿<%@ Page Title="Gestión de Rutas" Language="C#" MasterPageFile="~/GoutuAdminTransporte.master" AutoEventWireup="true" CodeBehind="GestionRutas.aspx.cs" Inherits="GoutuWA.GestionRutas" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Rutas - Administrador
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script type="text/javascript">
        function confirmarEliminacion() {
            return confirm('¿Está seguro que desea eliminar esta ruta? Esta acción no se puede deshacer.');
        }

        function limpiarFormulario() {
            document.getElementById('<%= txtIdRuta.ClientID %>').value = '';
            document.getElementById('<%= txtNombreRuta.ClientID %>').value = '';
            document.getElementById('<%= ddlServicio.ClientID %>').selectedIndex = 0;
            document.getElementById('<%= txtHoraInicio.ClientID %>').value = '';
            document.getElementById('<%= txtHoraFin.ClientID %>').value = '';
            document.getElementById('<%= txtTiempoIdeal.ClientID %>').value = '';
            document.getElementById('<%= txtTiempoRuta.ClientID %>').value = '';
            document.getElementById('<%= ddlActivo.ClientID %>').selectedIndex = 0;

            document.getElementById('<%= btnGuardar.ClientID %>').innerText = 'Guardar Ruta';
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
 <style>
     .page-header {
         background: white;
         padding: 25px 30px;
         border-radius: 15px;
         box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
         margin-bottom: 30px;
         display: flex;
         justify-content: space-between;
         align-items: center;
     }

     .page-title {
         color: #5e2a84;
         font-size: 26px;
         font-weight: 700;
         margin: 0;
     }

     .btn-nuevo {
         background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
         color: white;
         padding: 12px 25px;
         border: none;
         border-radius: 25px;
         font-weight: 600;
         cursor: pointer;
         transition: all 0.3s ease;
         text-decoration: none;
         display: inline-flex;
         align-items: center;
         gap: 8px;
     }

     .btn-nuevo:hover {
         transform: translateY(-2px);
         box-shadow: 0 4px 12px rgba(94, 42, 132, 0.3);
     }

     .form-container {
         background: white;
         padding: 30px;
         border-radius: 15px;
         box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
         margin-bottom: 30px;
     }

     .form-title {
         color: #5e2a84;
         font-size: 20px;
         font-weight: 600;
         margin-bottom: 20px;
         padding-bottom: 10px;
         border-bottom: 2px solid #5e2a84;
     }

     .form-row {
         display: grid;
         grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
         gap: 20px;
         margin-bottom: 20px;
     }

     .form-group {
         display: flex;
         flex-direction: column;
     }

     .form-group label {
         color: #333;
         font-weight: 600;
         margin-bottom: 8px;
         font-size: 14px;
     }

     .form-control {
         padding: 12px 15px;
         border: 2px solid #e0e0e0;
         border-radius: 8px;
         font-size: 14px;
         transition: all 0.3s ease;
     }

     .form-control:focus {
         outline: none;
         border-color: #5e2a84;
         box-shadow: 0 0 0 3px rgba(94, 42, 132, 0.1);
     }

     .btn-group {
         display: flex;
         gap: 15px;
         margin-top: 25px;
     }

     .btn {
         padding: 12px 30px;
         border: none;
         border-radius: 25px;
         font-weight: 600;
         cursor: pointer;
         transition: all 0.3s ease;
         font-size: 14px;
     }

     .btn-primary {
         background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
         color: white;
     }

     .btn-primary:hover {
         transform: translateY(-2px);
         box-shadow: 0 4px 12px rgba(94, 42, 132, 0.3);
     }

     .btn-secondary {
         background-color: #6c757d;
         color: white;
     }

     .btn-secondary:hover {
         background-color: #5a6268;
         transform: translateY(-2px);
     }

     .table-container {
         background: white;
         padding: 30px;
         border-radius: 15px;
         box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
         overflow-x: auto;
     }

     .custom-table {
         width: 100%;
         border-collapse: collapse;
     }

     .custom-table thead {
         background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
         color: white;
     }

     .custom-table th {
         padding: 15px;
         text-align: left;
         font-weight: 600;
         font-size: 14px;
     }

     .custom-table td {
         padding: 15px;
         border-bottom: 1px solid #e0e0e0;
         font-size: 14px;
     }

     .custom-table tbody tr:hover {
         background-color: #f8f9fa;
     }

     .badge {
         padding: 6px 12px;
         border-radius: 12px;
         font-size: 12px;
         font-weight: 600;
     }

     .badge-active {
         background-color: #28a745;
         color: white;
     }

     .badge-inactive {
         background-color: #dc3545;
         color: white;
     }

     .btn-action {
         padding: 8px 15px;
         margin: 0 3px;
         border: none;
         border-radius: 8px;
         cursor: pointer;
         font-size: 13px;
         font-weight: 600;
         transition: all 0.3s ease;
     }

     .btn-edit {
         background-color: #ffc107;
         color: #000;
     }

     .btn-edit:hover {
         background-color: #e0a800;
         transform: translateY(-2px);
     }

     .btn-delete {
         background-color: #dc3545;
         color: white;
     }

     .btn-delete:hover {
         background-color: #c82333;
         transform: translateY(-2px);
     }

     .alert {
         padding: 15px 20px;
         border-radius: 10px;
         margin-bottom: 20px;
         font-weight: 500;
     }

     .alert-success {
         background-color: #d4edda;
         color: #155724;
         border-left: 4px solid #28a745;
     }

     .alert-error {
         background-color: #f8d7da;
         color: #721c24;
         border-left: 4px solid #dc3545;
     }

     .empty-state {
         text-align: center;
         padding: 50px 20px;
         color: #999;
     }

     .empty-state i {
         font-size: 64px;
         margin-bottom: 20px;
         color: #ddd;
     }
 </style>

    <!-- Mensajes -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false">
        <div id="divMensaje" runat="server" class="alert">
            <asp:Label ID="lblMensaje" runat="server"></asp:Label>
        </div>
    </asp:Panel>

    <!-- Cabecera -->
    <div class="page-header">
        <h1 class="page-title"><i class="fa-solid fa-route"></i> Gestión de Rutas</h1>
    </div>

    <!-- Formulario de Ruta -->
    <div class="form-container">
        <div class="form-title">
            <i class="fa-solid fa-plus-circle"></i> <asp:Label ID="lblFormTitle" runat="server" Text="Nueva Ruta"></asp:Label>
        </div>

        <asp:HiddenField ID="txtIdRuta" runat="server" />

        <!-- Primera fila -->
        <div class="form-row">

            <div class="form-group">
                <label for="<%= txtNombreRuta.ClientID %>"><i class="fa-solid fa-tag"></i> Nombre *</label>
                <asp:TextBox ID="txtNombreRuta" runat="server" CssClass="form-control" 
                    placeholder="Ej: Ruta Central" MaxLength="100" required="required"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= ddlServicio.ClientID %>"><i class="fa-solid fa-bus"></i> Servicio *</label>
                <asp:DropDownList ID="ddlServicio" runat="server" CssClass="form-control" required="required">
                    
                </asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="<%= txtHoraInicio.ClientID %>"><i class="fa-solid fa-clock"></i> Inicio *</label>
                <asp:TextBox ID="txtHoraInicio" runat="server" CssClass="form-control" TextMode="Time" required="required"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= txtHoraFin.ClientID %>"><i class="fa-solid fa-clock"></i> Fin *</label>
                <asp:TextBox ID="txtHoraFin" runat="server" CssClass="form-control" TextMode="Time" required="required"></asp:TextBox>
            </div>
        </div>

        <!-- Segunda fila -->
        <div class="form-row">

            <div class="form-group">
                <label for="<%= txtTiempoIdeal.ClientID %>"><i class="fa-solid fa-hourglass-half"></i> Tiempo Ideal *</label>
                <asp:TextBox ID="txtTiempoIdeal" runat="server" CssClass="form-control" TextMode="Number" min="1" required="required"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= txtTiempoRuta.ClientID %>"><i class="fa-solid fa-stopwatch"></i> Tiempo Real *</label>
                <asp:TextBox ID="txtTiempoRuta" runat="server" CssClass="form-control" TextMode="Number" min="1" required="required"></asp:TextBox>
            </div>
        </div>

        <!-- Tercera fila -->
        <div class="form-row">
            <div class="form-group">
                <label for="<%= ddlActivo.ClientID %>"><i class="fa-solid fa-toggle-on"></i> Estado *</label>
                <asp:DropDownList ID="ddlActivo" runat="server" CssClass="form-control">
                    <asp:ListItem Value="1">Activo</asp:ListItem>
                    <asp:ListItem Value="0">Inactivo</asp:ListItem>
                </asp:DropDownList>
            </div>
        </div>

        <!-- Botones -->
        <div class="btn-group">
            <asp:Button ID="btnGuardar" runat="server" Text="Guardar Ruta" CssClass="btn-primary" OnClick="btnGuardar_Click" />
            <asp:Button ID="btnCancelar" runat="server" Text="Cancelar" CssClass="btn-secondary" OnClientClick="limpiarFormulario(); return true;" />
        </div>
    </div>

    <!-- Tabla -->
    <div class="table-container">
        <div class="form-title"><i class="fa-solid fa-list"></i>Lista de Rutas</div>

        <asp:GridView ID="gvRutas" runat="server" CssClass="custom-table"
            AutoGenerateColumns="False" DataKeyNames="id_ruta"
            OnRowCommand="gvRutas_RowCommand" EmptyDataText="No hay rutas registradas">

            <Columns>
                <asp:BoundField DataField="id_ruta" HeaderText="ID" />
                <asp:BoundField DataField="nombre" HeaderText="Nombre" />
                 <asp:BoundField DataField="ID_servicio" HeaderText="ID_SERVICIO" />
                <asp:BoundField DataField="Nombre_servicio" HeaderText="Servicio" />
                <asp:BoundField DataField="hora_inicio" HeaderText="Inicio" DataFormatString="{0:HH:mm}" />
                <asp:BoundField DataField="hora_fin" HeaderText="Fin" DataFormatString="{0:HH:mm}" />
              
                <asp:BoundField DataField="tiempo_ideal" HeaderText="T. Ideal" />
                <asp:BoundField DataField="tiempo_ruta" HeaderText="T. Ruta" />

                <asp:TemplateField HeaderText="Estado">
                    <ItemTemplate>
                        <span class='<%# Convert.ToInt32(Eval("activo")) == 1 ? "badge-active" : "badge-inactive" %>'>
                            <%# Convert.ToInt32(Eval("activo")) == 1 ? "Activo" : "Inactivo" %>
                        </span>
                    </ItemTemplate>
                </asp:TemplateField>

                <asp:TemplateField HeaderText="Acciones">
                    <ItemTemplate>
                        <asp:Button ID="btnEditar" runat="server"
                            Text="Editar"
                            CssClass="btn-action btn-edit"
                            CommandName="Editar"
                            CommandArgument='<%# Eval("id_ruta") %>'
                            CausesValidation="false"
                            UseSubmitBehavior="false" />



                         

<!-- Botón Añadir Estación -->
                        <asp:Button ID="btnEstaciones" runat="server"
                            Text="Añadir Estación"
                            CssClass="btn-action btn-nuevo"
                            CommandName="Estaciones"
                            CommandArgument='<%# Eval("id_ruta") + "|" + Eval("id_servicio") + "|" + Eval("Nombre_servicio")+ "|" + Eval("nombre")%>'
                            CausesValidation="false"
                            UseSubmitBehavior="false" />


                    </ItemTemplate>
                </asp:TemplateField>

            </Columns>

        </asp:GridView>
    </div>

</asp:Content>