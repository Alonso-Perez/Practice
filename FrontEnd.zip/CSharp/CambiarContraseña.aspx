﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GouTuCambiarContraseña.Master" AutoEventWireup="true" CodeBehind="CambiarContraseña.aspx.cs" Inherits="GoutuWA.CambiarContraseña1" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Content" runat="server">

    <div class="auth-card">

        <h3 class="text-center fw-bold mb-4">Nueva Contraseña</h3>
        <p class="text-muted text-center" style="font-size:14px;">
            Ingresa tu nueva contraseña y confírmala
        </p>

        <!-- 🔒 Contraseña nueva -->
        <div class="mb-3">
            <asp:Label ID="lblNueva" runat="server" Text="Nueva contraseña"></asp:Label>
            <asp:TextBox ID="txtNueva"
                runat="server"
                CssClass="form-control"
                TextMode="Password"
                Placeholder="*********"></asp:TextBox>
        </div>

        <!-- 🔁 Confirmar contraseña -->
        <div class="mb-3">
            <asp:Label ID="lblConfirmar" runat="server" Text="Confirmar contraseña"></asp:Label>
            <asp:TextBox ID="txtConfirmar"
                runat="server"
                CssClass="form-control"
                TextMode="Password"
                Placeholder="*********"></asp:TextBox>
        </div>

        <!-- Resultado / Errores -->
        <asp:Label ID="lblMensaje" runat="server" CssClass="text-danger fw-bold d-block mb-3"></asp:Label>

        <!-- Botón -->
        <asp:Button ID="btnCambiar"
            runat="server"
            Text="Actualizar Contraseña"
            CssClass="btn btn-primary w-100"
            OnClick="btnCambiar_Click" />

    </div>

</asp:Content>

