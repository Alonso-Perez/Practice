﻿<%@ Page Title="Detalles de la Tarjeta" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="DetallesTarjeta.aspx.cs" Inherits="GoutuWA.DetallesTarjeta" %>

<asp:Content ID="cTitle" ContentPlaceHolderID="cph_Title" runat="server">
  Detalles de la Tarjeta
</asp:Content>

<asp:Content ID="cScripts" ContentPlaceHolderID="cph_Scripts" runat="server">
  <style>
    .card-detalle {
      border-radius: 15px;
      overflow: hidden;
    }
    .img-tarjeta-detalle {
      max-width: 100%;
      height: auto;
      padding: 30px;
      object-fit: contain;
    }
    .info-tarjeta {
      padding: 30px;
    }
    .info-row {
      padding: 10px 0;
      border-bottom: 1px solid #e9ecef;
    }
    .info-row:last-child {
      border-bottom: none;
    }
    .btn-action {
      min-width: 120px;
    }
  </style>
  
  <script type="text/javascript">
      function abrirModalTramite() {
          var modal = new bootstrap.Modal(document.getElementById('tramiteModal'));
          modal.show();
      }

      function abrirModalEliminar() {
          var modal = new bootstrap.Modal(document.getElementById('eliminarModal'));
          modal.show();
      }

      function mostrarToast(mensaje, tipo) {
          var toastEl = document.getElementById('toastNotificacion');
          var toastBody = document.getElementById('toastMensaje');

          toastBody.innerText = mensaje;

          toastEl.classList.remove('bg-success', 'bg-danger', 'bg-info');
          if (tipo === 'error') {
              toastEl.classList.add('bg-danger');
          } else if (tipo === 'info') {
              toastEl.classList.add('bg-info');
          } else {
              toastEl.classList.add('bg-success');
          }

          var toast = new bootstrap.Toast(toastEl);
          toast.show();
      }
  </script>
</asp:Content>

<asp:Content ID="cContenido" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">
  <div class="container py-4">
    <div class="mb-4">
      <a href="Tarjetas.aspx" class="btn btn-outline-secondary">
        <i class="fas fa-arrow-left me-2"></i>Volver a Mis Tarjetas
      </a>
    </div>
    
    <h2 class="text-center mb-4">Detalles de la Tarjeta</h2>
    
    <div class="card card-detalle shadow-lg">
      <div class="row g-0">
        <div class="col-md-4 d-flex align-items-center justify-content-center bg-light">
          <asp:Image ID="imgCard" runat="server" CssClass="img-tarjeta-detalle" AlternateText="Imagen de tarjeta" />
        </div>
        
        <div class="col-md-8">
          <div class="info-tarjeta">
            <div class="info-row">
              <h5 class="mb-0">
                <i class="fas fa-hashtag text-primary me-2"></i>Tarjeta: 
                <asp:Label ID="lblCardNumber" runat="server" CssClass="text-primary fw-bold"></asp:Label>
              </h5>
            </div>
            
            <div class="info-row">
              <p class="mb-0">
                <strong><i class="fas fa-tag me-2"></i>Tipo:</strong> 
                <asp:Label ID="lblCardType" runat="server"></asp:Label>
              </p>
            </div>
            
            <div class="info-row">
              <p class="mb-0">
                <strong><i class="fas fa-wallet me-2"></i>Saldo:</strong> 
                <asp:Label ID="lblBalance" runat="server" CssClass="text-success fw-bold"></asp:Label>
              </p>
            </div>
            
            <div class="info-row">
              <p class="mb-0">
                <strong><i class="fas fa-ticket-alt me-2"></i>Tarifa:</strong> 
                <asp:Label ID="lblTariff" runat="server"></asp:Label>
              </p>
            </div>
            
            <!-- Botones de acción -->
            <div class="mt-4 d-flex flex-wrap gap-3">
              <!-- BOTÓN RECARGAR (POSTBACK) -->
              <asp:LinkButton ID="btnRecargar" runat="server"
                              CssClass="btn btn-primary btn-action"
                              OnClick="btnRecargar_Click">
                  <i class="fas fa-plus-circle me-2"></i>Recargar
              </asp:LinkButton>

              <button type="button" class="btn btn-outline-danger btn-action" onclick="abrirModalTramite()">
                <i class="fas fa-exclamation-triangle me-2"></i>Tramitar
              </button>

              <!-- NUEVO BOTÓN ELIMINAR -->
              <button type="button" class="btn btn-danger btn-action" onclick="abrirModalEliminar()">
                <i class="fas fa-trash-alt me-2"></i>Eliminar
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  
  <!-- Modal Trámite por Pérdida o Robo -->
  <div class="modal fade" id="tramiteModal" tabindex="-1" aria-labelledby="tramiteModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-warning text-dark">
          <h5 class="modal-title" id="tramiteModalLabel">
            <i class="fas fa-exclamation-triangle me-2"></i>Trámite por pérdida o robo
          </h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <p>Estás por realizar el trámite por <strong>pérdida o robo</strong> de esta tarjeta prepago.</p>
          <p>Al continuar con este proceso:</p>
          <ul>
            <li>Tu tarjeta actual será <strong>deshabilitada</strong></li>
            <li>Se te asignará automáticamente una <strong>nueva tarjeta</strong></li>
            <li>El saldo de tu tarjeta anterior será <strong>transferido</strong> a la nueva</li>
            <li>Este proceso varía según el tipo de tarjeta</li>
          </ul>
          <div class="alert alert-warning" role="alert">
            <i class="fas fa-info-circle me-2"></i>
            <strong>Importante:</strong> Esta acción no se puede deshacer.
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <asp:Button ID="btnContinuarTramite" runat="server" CssClass="btn btn-warning" 
            Text="Continuar" OnClick="btnContinuarTramite_Click" />
        </div>
      </div>
    </div>
  </div>

  <!-- NUEVO MODAL: Confirmar Eliminación -->
  <div class="modal fade" id="eliminarModal" tabindex="-1" aria-labelledby="eliminarModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered">
      <div class="modal-content">
        <div class="modal-header bg-danger text-white">
          <h5 class="modal-title" id="eliminarModalLabel">
            <i class="fas fa-trash-alt me-2"></i>Eliminar Tarjeta
          </h5>
          <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal" aria-label="Cerrar"></button>
        </div>
        <div class="modal-body">
          <p>¿Estás seguro de que deseas <strong>eliminar</strong> esta tarjeta de tu cuenta?</p>
          <p>Al confirmar:</p>
          <ul>
            <li>La tarjeta será <strong>removida</strong> de tu lista</li>
            <li>No podrás usar esta tarjeta hasta que la vuelvas a agregar</li>
            <li><strong>El saldo permanecerá en la tarjeta</strong> si decides re-agregarla después</li>
          </ul>
          <div class="alert alert-danger" role="alert">
            <i class="fas fa-exclamation-circle me-2"></i>
            <strong>Atención:</strong> Esta acción es reversible agregando nuevamente la tarjeta.
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancelar</button>
          <asp:Button ID="btnEliminarTarjeta" runat="server" CssClass="btn btn-danger" 
            Text="Sí, Eliminar" OnClick="btnEliminarTarjeta_Click" />
        </div>
      </div>
    </div>
  </div>
  
  <!-- Toast para notificaciones -->
  <div class="toast-container position-fixed top-0 end-0 p-3">
    <div id="toastNotificacion" class="toast align-items-center text-white border-0" role="alert" aria-live="assertive" aria-atomic="true">
      <div class="d-flex">
        <div class="toast-body" id="toastMensaje">
          Operación completada
        </div>
        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Cerrar"></button>
      </div>
    </div>
  </div>
</asp:Content>