﻿<%@ Page Title="Adquisición de Tarjeta" Language="C#" MasterPageFile="~/GoutuCuenta.Master" 
    AutoEventWireup="true" CodeBehind="AdquirirTarjeta.aspx.cs" Inherits="GoutuWA.AdquirirTarjeta" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Adquisición de Tarjeta
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        :root {
            --goutu-primary: #5e2a84;
            --goutu-primary-dark: #4a1f63;
            --goutu-soft-bg: #f8f5fb;
        }

        .page-title {
            color: var(--goutu-primary);
            font-weight: 600;
            margin-bottom: 25px;
        }

        .card-adquisicion {
            border-radius: 20px;
            border: none;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        }

        .segmented-group {
            display: inline-flex;
            padding: 4px;
            border-radius: 999px;
            background-color: var(--goutu-soft-bg);
            gap: 4px;
        }

        .segmented-option {
            border: none;
            background: transparent;
            padding: 10px 26px;
            border-radius: 999px;
            font-weight: 600;
            color: var(--goutu-primary);
            min-width: 130px;
            text-align: center;
            cursor: pointer;
            transition: all 0.2s ease;
        }

        .segmented-option:hover {
            background-color: #eee3ff;
        }

        .segmented-option.active {
            background-color: var(--goutu-primary);
            color: #ffffff;
            box-shadow: 0 4px 10px rgba(94, 42, 132, 0.25);
        }

        .label-section {
            font-weight: 600;
            margin-bottom: 10px;
        }

        .costo-monto {
            font-size: 2rem;
            font-weight: 700;
            color: var(--goutu-primary);
        }

        .btn-goutu-primary {
            background-color: var(--goutu-primary);
            border-color: var(--goutu-primary);
            color: #ffffff;
            border-radius: 999px;
            padding: 10px 28px;
            font-weight: 600;
            min-width: 150px;
        }

        .btn-goutu-primary:hover {
            background-color: var(--goutu-primary-dark);
            border-color: var(--goutu-primary-dark);
            color: #ffffff;
        }

        .btn-goutu-outline {
            background-color: transparent;
            border-radius: 999px;
            padding: 10px 28px;
            font-weight: 600;
            min-width: 150px;
            border: 2px solid var(--goutu-primary);
            color: var(--goutu-primary);
        }

        .btn-goutu-outline:hover {
            background-color: var(--goutu-soft-bg);
            color: var(--goutu-primary-dark);
            text-decoration: none;
        }

        .alert-limite {
            border-radius: 20px;
            border: none;
            box-shadow: 0 8px 24px rgba(0, 0, 0, 0.08);
        }
    </style>

    <script type="text/javascript">
        function seleccionarTipo(tipo) {
            var hdn = document.getElementById('<%= hdnTipoTarjeta.ClientID %>');
            if (hdn) hdn.value = tipo;

            var btnLima = document.getElementById('btnTipoLima');
            var btnLinea = document.getElementById('btnTipoLinea');

            if (btnLima && btnLinea) {
                btnLima.classList.remove('active');
                btnLinea.classList.remove('active');

                if (tipo === 'lima') {
                    btnLima.classList.add('active');
                } else {
                    btnLinea.classList.add('active');
                }
            }

            actualizarCostoVisual(tipo);
        }

        function seleccionarTarifa(tarifa) {
            var hdn = document.getElementById('<%= hdnTarifario.ClientID %>');
            if (hdn) hdn.value = tarifa;

            var btnReg = document.getElementById('btnTarifaRegular');
            var btnUni = document.getElementById('btnTarifaUniversitario');
            var btnCon = document.getElementById('btnTarifaConadis');

            [btnReg, btnUni, btnCon].forEach(function (b) {
                if (b) b.classList.remove('active');
            });

            if (tarifa === 'regular' && btnReg) btnReg.classList.add('active');
            if (tarifa === 'universitario' && btnUni) btnUni.classList.add('active');
            if (tarifa === 'conadis' && btnCon) btnCon.classList.add('active');
        }

        function actualizarCostoVisual(tipo) {
            var lbl = document.getElementById('<%= lblMontoTarjeta.ClientID %>');
            if (!lbl) return;

            var costo = (tipo === 'lima') ? 4.5 : 5.0;
            lbl.textContent = 'S/ ' + costo.toFixed(2);
        }

        document.addEventListener('DOMContentLoaded', function () {
            var hdnTipo = document.getElementById('<%= hdnTipoTarjeta.ClientID %>');
            var tipo = (hdnTipo && hdnTipo.value) ? hdnTipo.value : 'lima';
            seleccionarTipo(tipo);

            var hdnTarifa = document.getElementById('<%= hdnTarifario.ClientID %>');
            var tarifa = (hdnTarifa && hdnTarifa.value) ? hdnTarifa.value : 'regular';
            seleccionarTarifa(tarifa);
        });
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">

    <!-- HiddenFields para comunicar selección al servidor -->
    <asp:HiddenField ID="hdnTipoTarjeta" runat="server" />
    <asp:HiddenField ID="hdnTarifario" runat="server" />

    <div class="container mt-4 mb-5">
        <h2 class="page-title">Adquisición de Tarjeta</h2>

        <!-- Mensaje cuando alcanza el límite de tarjetas -->
        <asp:Panel ID="pnlLimiteTarjetas" runat="server" Visible="false">
            <div class="alert alert-warning alert-limite">
                <h5 class="mb-2">
                    <i class="fa-solid fa-triangle-exclamation me-2"></i>
                    Límite de tarjetas alcanzado
                </h5>
                <p class="mb-2">
                    <asp:Label ID="lblMensajeLimite" runat="server" />
                </p>
                <a href="Tarjetas.aspx" class="btn btn-goutu-primary mt-2">
                    Ver mis tarjetas
                </a>
            </div>
        </asp:Panel>

        <!-- Formulario principal -->
        <asp:Panel ID="pnlFormulario" runat="server">
            <div class="card card-adquisicion mt-3">
                <div class="card-body p-4 p-md-5">

                    <!-- Tipo de tarjeta -->
                    <div class="mb-4">
                        <div class="label-section">Tipo de tarjeta</div>
                        <div class="segmented-group">
                            <button type="button" id="btnTipoLima" class="segmented-option"
                                onclick="seleccionarTipo('lima')">
                                Lima Pass
                            </button>
                            <button type="button" id="btnTipoLinea" class="segmented-option"
                                onclick="seleccionarTipo('tren')">
                                Línea 1
                            </button>
                        </div>
                    </div>

                    <!-- Tarifario -->
                    <div class="mb-4">
                        <div class="label-section">Tarifario</div>
                        <div class="segmented-group">
                            <button type="button" id="btnTarifaRegular" class="segmented-option"
                                onclick="seleccionarTarifa('regular')">
                                Regular
                            </button>
                            <button type="button" id="btnTarifaUniversitario" class="segmented-option"
                                onclick="seleccionarTarifa('universitario')">
                                Universitario
                            </button>
                            <button type="button" id="btnTarifaConadis" class="segmented-option"
                                onclick="seleccionarTarifa('conadis')">
                                Conadis
                            </button>
                        </div>
                    </div>

                    <!-- Costo -->
                    <div class="mb-4">
                        <div class="label-section">Costo de la tarjeta</div>
                        <div class="costo-monto mb-1">
                            <asp:Label ID="lblMontoTarjeta" runat="server" Text="S/ 4.50"></asp:Label>
                        </div>
                        <small class="text-muted">
                            Lima Pass: S/ 4.50 &nbsp; | &nbsp; Línea 1: S/ 5.00
                        </small>
                    </div>

                    <!-- Botones -->
                    <div class="mt-4 d-flex flex-wrap gap-3">
                        <asp:Button ID="btnContinuar" runat="server" Text="Continuar"
                            CssClass="btn btn-goutu-primary" OnClick="btnContinuar_Click" />
                        <asp:Button ID="btnVolver" runat="server" Text="Volver"
                            CssClass="btn btn-goutu-outline" OnClick="btnVolver_Click"
                            CausesValidation="false" />
                    </div>
                </div>
            </div>
        </asp:Panel>
    </div>
</asp:Content>