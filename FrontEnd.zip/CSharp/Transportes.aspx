﻿<%@ Page Title="Transportes" Language="C#" MasterPageFile="~/GoutuMaster.Master"
    AutoEventWireup="true" CodeBehind="Transportes.aspx.cs" Inherits="GoutuWA.Transportes" %>

<asp:Content ID="c1" ContentPlaceHolderID="cph_Title" runat="server">Transportes</asp:Content>

<asp:Content ID="c2" ContentPlaceHolderID="cph_Scripts" runat="server">
  <script src="Scripts/bootstrap.min.js"></script>
</asp:Content>

<asp:Content ID="c3" ContentPlaceHolderID="cph_Contenido" runat="server">
  <div class="d-flex justify-content-between align-items-center mb-4">
    <h3 class="m-0">Gestión de Transportes</h3>
    <div class="d-flex gap-2">
      <asp:DropDownList ID="ddlTipoFiltro" runat="server" CssClass="form-control">
        <asp:ListItem Text="Todos" Value=""></asp:ListItem>
        <asp:ListItem>Linea_1</asp:ListItem>
        <asp:ListItem>Metropolitano</asp:ListItem>
        <asp:ListItem>Corredor</asp:ListItem>
      </asp:DropDownList>
      <asp:LinkButton ID="btnFiltrar" runat="server" CssClass="btn btn-outline-secondary">Filtrar</asp:LinkButton>
      <asp:LinkButton ID="btnNuevoTransporte" runat="server" CssClass="btn text-white"
        Style="background-color:#4b0082"
        OnClientClick="$('#modalTransporte').modal('show'); return false;">
        + Nuevo Transporte
      </asp:LinkButton>
    </div>
  </div>

  <asp:GridView ID="gvTransportes" runat="server" CssClass="table table-striped"
      AutoGenerateColumns="False" GridLines="None">
    <Columns>
      <asp:BoundField DataField="id_transporte" HeaderText="ID" />
      <asp:BoundField DataField="nombre_transporte" HeaderText="Nombre" />
      <asp:BoundField DataField="tipo_transporte" HeaderText="Tipo" />
      <asp:BoundField DataField="capacidad" HeaderText="Capacidad" />
      <asp:BoundField DataField="placa" HeaderText="Placa" />
      <asp:BoundField DataField="fecha_registro" HeaderText="Registro" />
      <asp:BoundField DataField="tiempo_recorrido" HeaderText="T. Recorrido (min)" />
      <asp:BoundField DataField="fecha_mantenimiento" HeaderText="Próx. Mantenimiento" />
      <asp:CheckBoxField DataField="activo" HeaderText="Activo" />
      <asp:HyperLinkField Text="Asignar rutas" DataNavigateUrlFields="id_transporte"
        DataNavigateUrlFormatString="AsignarRuta.aspx?id={0}" />
      <asp:ButtonField Text="Editar" CommandName="Editar" />
      <asp:ButtonField Text="Eliminar" CommandName="Eliminar" />
    </Columns>
  </asp:GridView>

  <!-- Modal Crear/Editar Transporte -->
  <div class="modal fade" id="modalTransporte" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog modal-lg">
      <div class="modal-content p-3">
        <div class="d-flex justify-content-between align-items-center">
          <h5 class="m-0" style="color:#4b0082;">Transporte</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
        </div>

        <div class="row g-3 mt-2">
          <div class="col-md-6">
            <label class="form-label">Nombre</label>
            <asp:TextBox ID="txtNombreTransporte" runat="server" CssClass="form-control" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Tipo</label>
            <asp:DropDownList ID="ddlTipo" runat="server" CssClass="form-control">
              <asp:ListItem>Linea_1</asp:ListItem>
              <asp:ListItem>Metropolitano</asp:ListItem>
              <asp:ListItem>Corredor</asp:ListItem>
            </asp:DropDownList>
          </div>
          <div class="col-md-3">
            <label class="form-label">Capacidad</label>
            <asp:TextBox ID="txtCapacidad" runat="server" CssClass="form-control" TextMode="Number" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Placa</label>
            <asp:TextBox ID="txtPlaca" runat="server" CssClass="form-control" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Fecha registro</label>
            <asp:TextBox ID="txtFechaRegistro" runat="server" CssClass="form-control" placeholder="yyyy-MM-dd" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Tiempo recorrido (min)</label>
            <asp:TextBox ID="txtTiempoRecorrido" runat="server" CssClass="form-control" TextMode="Number" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Fecha mantenimiento</label>
            <asp:TextBox ID="txtFechaMantenimiento" runat="server" CssClass="form-control" placeholder="yyyy-MM-dd" />
          </div>
          <div class="col-md-3">
            <label class="form-label">Empresa (ID)</label>
            <asp:TextBox ID="txtIdEmpresa" runat="server" CssClass="form-control" TextMode="Number" />
          </div>
          <div class="col-12 d-flex align-items-center">
            <asp:CheckBox ID="chkActivoTransporte" runat="server" CssClass="form-check-input me-2" />
            <label class="form-check-label">Activo</label>
          </div>
        </div>

        <div class="mt-3 d-flex justify-content-end gap-2">
          <asp:LinkButton ID="btnGuardarTransporte" runat="server" CssClass="btn text-white"
            Style="background-color:#4b0082">Guardar</asp:LinkButton>
          <button type="button" class="btn btn-outline-secondary" data-bs-dismiss="modal">Cancelar</button>
        </div>
      </div>
    </div>
  </div>
</asp:Content>
