﻿<%@ Page Title="Gestión de Transporte" Language="C#" MasterPageFile="~/GoutuAdminTransporte.Master" AutoEventWireup="true" CodeBehind="GestionarTransporte.aspx.cs" Inherits="GoutuWA.GestionTransporte" %>
<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Transporte - Administrador
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script type="text/javascript">
        function confirmarEliminacion() {
            return confirm('¿Está seguro que desea eliminar este transporte? Esta acción no se puede deshacer.');
        }

        function limpiarFormulario() {
            document.getElementById('<%= txtIdTransporte.ClientID %>').value = '';
            document.getElementById('<%= txtNombreTransporte.ClientID %>').value = '';
            document.getElementById('<%= ddlTipoTransporte.ClientID %>').selectedIndex = 0;
            document.getElementById('<%= txtCapacidad.ClientID %>').value = '';
            document.getElementById('<%= txtPlaca.ClientID %>').value = '';
            document.getElementById('<%= txtTiempoRecorrido.ClientID %>').value = '';
            document.getElementById('<%= txtFechaMantenimiento.ClientID %>').value = '';
        
            document.getElementById('<%= ddlRuta.ClientID %>').selectedIndex = 0;
            document.getElementById('<%= btnGuardar.ClientID %>').value = 'Guardar Transporte';
            
            // Ocultar el campo activo al limpiar
            document.getElementById('<%= pnlActivo.ClientID %>').style.display = 'none';
        }

        function mostrarCampoActivo(mostrar) {
            document.getElementById('<%= pnlActivo.ClientID %>').style.display = mostrar ? 'block' : 'none';
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    <style>
        .page-header {
            background: white;
            padding: 25px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            color: #5e2a84;
            font-size: 26px;
            font-weight: 700;
            margin: 0;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .form-title {
            color: #5e2a84;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #5e2a84;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #5e2a84;
            box-shadow: 0 0 0 3px rgba(94, 42, 132, 0.1);
        }

        .checkbox-group {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 10px;
        }

        .checkbox-group input[type="checkbox"] {
            width: 18px;
            height: 18px;
            cursor: pointer;
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(94, 42, 132, 0.3);
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .table-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            overflow-x: auto;
        }

        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .custom-table thead {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .custom-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        .custom-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
        }

        .custom-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .btn-action {
            padding: 8px 15px;
            margin: 0 3px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background-color: #ffc107;
            color: #000;
        }

        .btn-edit:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background-color: #c82333;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: #999;
        }

        .empty-state i {
            font-size: 64px;
            margin-bottom: 20px;
            color: #ddd;
        }

        .status-active {
            color: #28a745;
            font-weight: 600;
        }

        .status-inactive {
            color: #dc3545;
            font-weight: 600;
        }

        .capacity-display {
            font-weight: 700;
            color: #5e2a84;
            font-size: 14px;
        }
    </style>

    <!-- Mensajes de alerta -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false">
        <div id="divMensaje" runat="server" class="alert">
            <asp:Label ID="lblMensaje" runat="server"></asp:Label>
        </div>
    </asp:Panel>

    <!-- Cabecera -->
    <div class="page-header">
        <h1 class="page-title">
            <i class="fa-solid fa-bus"></i> Gestión de Transporte
        </h1>
    </div>

    <!-- Formulario de Transporte -->
    <div class="form-container">
        <div class="form-title">
            <i class="fa-solid fa-plus-circle"></i> <asp:Label ID="lblFormTitle" runat="server" Text="Nuevo Transporte"></asp:Label>
        </div>

        <asp:HiddenField ID="txtIdTransporte" runat="server" />

        <div class="form-row">
            <div class="form-group">
                <label for="<%= txtNombreTransporte.ClientID %>">
                    <i class="fa-solid fa-tag"></i> Nombre del Transporte *
                </label>
                <asp:TextBox ID="txtNombreTransporte" runat="server" CssClass="form-control" 
                    placeholder="Ej: Bus Express 001" MaxLength="100"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= ddlTipoTransporte.ClientID %>">
                    <i class="fa-solid fa-bus"></i> Tipo de Transporte *
                </label>
                <asp:DropDownList ID="ddlTipoTransporte" runat="server" CssClass="form-control">
                    <asp:ListItem Value="">-- Seleccione tipo --</asp:ListItem>
                    <asp:ListItem Value="Bus">Bus</asp:ListItem>
                    <asp:ListItem Value="Microbus">Microbús</asp:ListItem>
                    <asp:ListItem Value="Van">Van</asp:ListItem>
                    <asp:ListItem Value="Combi">Combi</asp:ListItem>
                    <asp:ListItem Value="Otro">Otro</asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="<%= txtCapacidad.ClientID %>">
                    <i class="fa-solid fa-users"></i> Capacidad *
                </label>
                <asp:TextBox ID="txtCapacidad" runat="server" CssClass="form-control" 
                    placeholder="Ej: 40" TextMode="Number" min="1" max="100"></asp:TextBox>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="<%= txtPlaca.ClientID %>">
                    <i class="fa-solid fa-car"></i> Placa *
                </label>
                <asp:TextBox ID="txtPlaca" runat="server" CssClass="form-control" 
                    placeholder="Ej: ABC-123" MaxLength="20"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= txtTiempoRecorrido.ClientID %>">
                    <i class="fa-solid fa-clock"></i> Tiempo de Recorrido (min) *
                </label>
                <asp:TextBox ID="txtTiempoRecorrido" runat="server" CssClass="form-control" 
                    placeholder="Ej: 45" TextMode="Number" min="1" max="500"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= txtFechaMantenimiento.ClientID %>">
                    <i class="fa-solid fa-calendar-alt"></i> Fecha de Mantenimiento *
                </label>
                <asp:TextBox ID="txtFechaMantenimiento" runat="server" CssClass="form-control" 
                    TextMode="Date"></asp:TextBox>
            </div>
        </div>

        <div class="form-row">
            <div class="form-group">
                <label for="<%= ddlEmpresa.ClientID %>">
                    <i class="fa-solid fa-building"></i> Empresa *
                </label>
                <asp:DropDownList ID="ddlEmpresa" runat="server" CssClass="form-control">
                    <asp:ListItem Value="">-- Seleccione empresa --</asp:ListItem>
                </asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="<%= ddlRuta.ClientID %>">
                    <i class="fa-solid fa-route"></i> Ruta *
                </label>
                <asp:DropDownList ID="ddlRuta" runat="server" CssClass="form-control">
                    <asp:ListItem Value="">-- Seleccione ruta --</asp:ListItem>
                </asp:DropDownList>
            </div>

            <!-- Panel para el campo Activo (oculto por defecto) -->
            <asp:Panel ID="pnlActivo" runat="server" CssClass="form-group" style="display: none;">
                <div class="checkbox-group">
                    <asp:CheckBox ID="chkActivo" runat="server" Checked="true" />
                    <label for="<%= chkActivo.ClientID %>">Transporte Activo</label>
                </div>
            </asp:Panel>
        </div>

        <div class="btn-group">
            <asp:Button ID="btnGuardar" runat="server" Text="Guardar Transporte" 
                CssClass="btn btn-primary" OnClick="btnGuardar_Click" />
            <asp:Button ID="btnCancelar" runat="server" Text="Cancelar" 
                CssClass="btn btn-secondary" OnClientClick="limpiarFormulario(); return false;" />
        </div>
    </div>

    <!-- Tabla de Transportes -->
    <div class="table-container">
        <div class="form-title" style="margin-bottom: 20px;">
            <i class="fa-solid fa-list"></i> Lista de Transportes
        </div>

        <asp:GridView ID="gvTransportes" runat="server" CssClass="custom-table" 
            AutoGenerateColumns="False"
            OnRowCommand="gvTransportes_RowCommand"
            EmptyDataText="No hay transportes registrados">
            <Columns>
                <asp:BoundField DataField="id_transporte" HeaderText="ID" />
                <asp:BoundField DataField="nombre_transporte" HeaderText="Nombre" />
                <asp:BoundField DataField="tipo_transporte" HeaderText="Tipo" />
                <asp:TemplateField HeaderText="Capacidad">
                    <ItemTemplate>
                        <span class="capacity-display"><%# Eval("capacidad") %> pasajeros</span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="placa" HeaderText="Placa" />
                <asp:BoundField DataField="tiempo_recorrido" HeaderText="Tiempo (min)" />
                <asp:BoundField DataField="fecha_mantenimiento" HeaderText="Mantenimiento" DataFormatString="{0:dd/MM/yyyy}" />
                <asp:TemplateField HeaderText="Estado">
                    <ItemTemplate>
                        <span class='<%# Convert.ToBoolean(Eval("activo")) ? "status-active" : "status-inactive" %>'>
                            <%# Convert.ToBoolean(Eval("activo")) ? "Activo" : "Inactivo" %>
                        </span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="id_empresa" HeaderText="ID Empresa" />
                <asp:BoundField DataField="id_ruta" HeaderText="ID Ruta" />
                <asp:BoundField DataField="fecha_registro" HeaderText="Registro" DataFormatString="{0:dd/MM/yyyy}" />
                <asp:TemplateField HeaderText="Acciones">
                    <ItemTemplate>
                        <asp:Button ID="btnEditar" runat="server" Text="Editar" 
                            CssClass="btn-action btn-edit" 
                            CommandName="Editar" 
                            CommandArgument='<%# Eval("id_transporte") %>' />
                        <asp:Button ID="btnEliminar" runat="server" Text="Eliminar" 
                            CssClass="btn-action btn-delete" 
                            CommandName="Eliminar" 
                            CommandArgument='<%# Eval("id_transporte") %>'
                            OnClientClick="return confirmarEliminacion();" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
            <EmptyDataTemplate>
                <div class="empty-state">
                    <i class="fa-solid fa-bus"></i>
                    <p>No hay transportes registrados. ¡Comienza agregando un nuevo transporte!</p>
                </div>
            </EmptyDataTemplate>
        </asp:GridView>
    </div>

</asp:Content>