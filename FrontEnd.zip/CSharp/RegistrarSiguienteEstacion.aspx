﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuConductor.Master" AutoEventWireup="true" CodeBehind="RegistrarSiguienteEstacion.aspx.cs" Inherits="GoutuWA.RegistrarEstacion" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Registrar Siguiente Estación
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
   
    <style>
    .saludo-conductor {
            text-align: center;
            margin-bottom: 30px;
            padding: 15px 20px;
            background: linear-gradient(135deg, #4b1c67, #6a2c8f);
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(75, 28, 103, 0.2);
        }

        .saludo-conductor p {
            color: white;
            font-size: 1.2em;
            margin: 0;
            font-weight: 500;
        }

        .saludo-conductor strong {
            font-weight: 700;
            color: #fbbf24;
        }

        @media (max-width: 768px) {
            .saludo-conductor p {
                font-size: 1em;
            }
        }

        .estacion-estado {
            margin-top: 5px;
            font-weight: 600;
            font-size: 0.8em;
            text-align: center;
            white-space: nowrap;
        }

        .btn-cancelar {
            background-color: #dc3545;
            color: white;
            padding: 12px 25px;
            border: none;
            border-radius: 25px;
            font-weight: 700;
            cursor: pointer;
            transition: all 0.3s ease;
        }

.btn-cancelar:hover {
    background-color: #c82333;
    transform: translateY(-2px);
    box-shadow: 0 4px 15px rgba(220, 53, 69, 0.4);
}
/* Colores para los textos de estado */
.estacion.actual .estacion-estado {
    color: #4b1c67;
    font-weight: 700;
}

.estacion.siguiente .estacion-estado {
    color: #10b981;
    font-weight: 700;
}

.estacion.omitida .estacion-estado {
    color: #ef4444;
    font-weight: 700;
}

.estacion.completada .estacion-estado {
    color: #6b7280;
    font-weight: 600;
}

.estacion.inactiva .estacion-estado {
    color: #9ca3af;
    font-weight: 500;
}
        .modal {
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            z-index: 999;
        }

        .modal-overlay {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background: rgba(0, 0, 0, 0.5);
            z-index: 1;
        }

        .modal-content {
            position: absolute;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            background: #fff;
            border-radius: 15px;
            padding: 30px 40px;
            width: 400px;
            max-width: 90%;
            box-shadow: 0 10px 30px rgba(0, 0, 0, 0.3);
            z-index: 2;
            animation: aparecer 0.3s ease;
        }

        @keyframes aparecer {
            from {
                opacity: 0;
                transform: translate(-50%, -45%);
            }

            to {
                opacity: 1;
                transform: translate(-50%, -50%);
            }
        }

        .modal-content h2 {
            text-align: center;
            color: #4b1c67;
            font-weight: 700;
            margin-top: 0;
        }

        .form-control {
            width: 100%;
            padding: 10px;
            border-radius: 8px;
            border: 1px solid #ccc;
            font-size: 1em;
            box-sizing: border-box;
        }

        /* ===== PÁGINA ===== */
        .page-container {
            max-width: 900px;
            margin: 0 auto;
            padding: 20px;
        }

        .page-title {
            text-align: center;
            font-size: 2em;
            color: #000;
            margin-bottom: 40px;
            font-weight: 600;
        }

        .info-section {
            text-align: center;
            margin-bottom: 30px;
        }

        .info-label {
            font-size: 1.1em;
            color: #666;
            margin-bottom: 10px;
        }

        /* ===== BOTONES ===== */
        .botones-principales {
            display: flex;
            gap: 20px;
            justify-content: center;
            margin-bottom: 40px;
            flex-wrap: wrap;
        }

        .btn-principal {
            padding: 15px 40px;
            border: none;
            border-radius: 30px;
            font-weight: 700;
            font-size: 1.1em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

        .btn-registrar {
            background-color: #4b1c67;
            color: white;
        }

            .btn-registrar:hover {
                background-color: #3a1550;
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(75, 28, 103, 0.4);
            }

        .btn-manual {
            background-color: #f59e0b;
            color: white;
        }

            .btn-manual:hover {
                background-color: #d97706;
                transform: translateY(-2px);
                box-shadow: 0 6px 20px rgba(245, 158, 11, 0.4);
            }

        .btn-cambiar-direccion {
            padding: 12px 30px;
            background: #f59e0b;
            color: white;
            border: none;
            border-radius: 25px;
            font-weight: 700;
            font-size: 1em;
            cursor: pointer;
            transition: all 0.3s ease;
        }

            .btn-cambiar-direccion:hover {
                background: #d97706;
                transform: translateY(-2px);
                box-shadow: 0 4px 15px rgba(245, 158, 11, 0.4);
            }

        /* ===== MAPA ===== */
        .mapa-container {
            background: white;
            border-radius: 20px;
            padding: 30px 20px;
            box-shadow: 0 4px 20px rgba(0, 0, 0, 0.08);
            margin-bottom: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
        }

        .ruta-mapa {
            display: flex;
            align-items: center;
            justify-content: center;
            flex-wrap: nowrap;
            width: 100%;
            gap: clamp(10px, 2vw, 40px);
            overflow: hidden;
            position: relative;
        }

        .linea-ruta {
            position: absolute;
            top: 50%;
            left: 5%;
            right: 5%;
            height: 3px;
            background: #e5e7eb;
            z-index: 1;
        }

        .estacion {
            display: flex;
            flex-direction: column;
            align-items: center;
            position: relative;
            z-index: 2;
            flex: 1 1 auto;
            min-width: 60px;
        }

        .estacion-circulo {
            width: clamp(40px, 6vw, 70px);
            height: clamp(40px, 6vw, 70px);
            border-radius: 50%;
            border: 3px solid #d1d5db;
            display: flex;
            align-items: center;
            justify-content: center;
            background: white;
            font-weight: 700;
            font-size: clamp(0.9em, 1.5vw, 1.3em);
            color: #4b1c67;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            transition: all 0.3s ease;
        }

        .estacion-nombre {
            margin-top: 8px;
            font-weight: 600;
            font-size: clamp(0.7em, 1vw, 0.95em);
            color: #4b5563;
            text-align: center;
            white-space: nowrap;
        }

        .flecha-ruta {
            font-size: clamp(1em, 1.5vw, 1.3em);
            color: #9ca3af;
        }

        /* ===== COLORES DE ESTADO ===== */
        .estacion.actual .estacion-circulo {
            background: #4b1c67;
            color: white;
        }

        .estacion.siguiente .estacion-circulo {
            background: #10b981;
            border-color: #10b981;
            color: white;
        }

        .estacion.omitida .estacion-circulo {
            background-color: #ef4444;
            border-color: #ef4444;
            color: white;
            box-shadow: 0 0 10px rgba(239, 68, 68, 0.5);
        }

        .estacion.inactiva .estacion-circulo {
            background-color: #e5e7eb;
            border-color: #d1d5db;
            color: #9ca3af;
        }

        .estacion.actual .estacion-nombre {
            color: #4b1c67;
            font-weight: 700;
        }

        .estacion.siguiente .estacion-nombre {
            color: #10b981;
            font-weight: 700;
        }

        /* ===== RESPONSIVO ===== */
        @media (max-width: 768px) {
            .mapa-container {
                padding: 20px 10px;
            }

            .estacion-circulo {
                width: 50px;
                height: 50px;
            }

            .ruta-mapa {
                gap: 15px;
            }
        }
    </style>
</asp:Content>
<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoConductor" runat="server">
    <div class="page-container">

        <h1 class="page-title">Registrar siguiente estacion</h1>
        <div class="saludo-conductor">
            <p>¡Hola, <strong><%= NombreConductor %></strong>! Bienvenido al sistema de registro de estaciones.</p>
        </div>
        <div class="info-section">
            <!-- Información actual -->
            <div class="info-label">Estacion actual: <strong><%= EstacionActualNombre %></strong></div>
            <div class="info-label">Proxima estacion: <strong><%= ProximaEstacion %></strong></div>
        </div>

        <!-- BOTONES PRINCIPALES -->
        <div class="botones-principales">
            <asp:Button ID="btnRegistrarSiguiente" runat="server"
                Text="Registrar siguiente"
                CssClass="btn-principal btn-registrar"
                OnClick="btnRegistrarSiguiente_Click" />

            <asp:Button ID="btnRegistrarManual" runat="server"
                Text="Registrar manual"
                CssClass="btn-principal btn-manual"
                OnClick="btnRegistrarManual_Click" />
        </div>

        <!-- MAPA DE ESTACIONES -->
        <div class="mapa-container">
            <div class="ruta-mapa">
                <div class="linea-ruta"></div>
                <asp:PlaceHolder ID="phEstaciones" runat="server"></asp:PlaceHolder>
            </div>
        </div>

      
        <!-- Modal: Registrar manual -->
<div id="modalRegistrarManual" class="modal">
    <div class="modal-overlay"></div>
    <div class="modal-content">
        <h2>Registrar manual</h2>
        <div>
            <label>Estación actual:</label>
            <asp:DropDownList ID="ddlEstacionActual" runat="server" CssClass="form-control"></asp:DropDownList>
        </div>
        <div style="margin-top: 10px;">
            <label>Siguiente estación:</label>
            <asp:DropDownList ID="ddlProximaEstacion" runat="server" CssClass="form-control"></asp:DropDownList>
        </div>

        <div style="margin-top: 20px; text-align: center; display: flex; gap: 10px; justify-content: center;">
            <asp:Button ID="btnGuardarManual" runat="server" Text="Guardar" 
                CssClass="btn-principal btn-registrar" OnClick="btnGuardarManual_Click" />
            <button type="button" class="btn-principal btn-cancelar" onclick="cerrarModal()">Cancelar</button>
        </div>
    </div>
</div>

<script>
    function cerrarModal() {
        document.getElementById('modalRegistrarManual').style.display = 'none';
    }
</script>
    </div>
</asp:Content>