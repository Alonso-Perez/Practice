﻿<%@ Page Title="Asignar Rutas" Language="C#" MasterPageFile="~/GoutuMaster.Master"
    AutoEventWireup="true" CodeBehind="AsignarRuta.aspx.cs" Inherits="GoutuWA.AsignarRuta" %>

<asp:Content ID="c1" ContentPlaceHolderID="cph_Title" runat="server">Asignar Rutas</asp:Content>

<asp:Content ID="c2" ContentPlaceHolderID="cph_Scripts" runat="server">
  <script src="Scripts/bootstrap.min.js"></script>
</asp:Content>

<asp:Content ID="c3" ContentPlaceHolderID="cph_Contenido" runat="server">
  <h3 class="mb-3">Asignar rutas al transporte</h3>
  <p class="text-muted">Transporte ID: <asp:Label ID="lblIdTransporte" runat="server" Text="(id)"></asp:Label></p>

  <div class="row">
    <div class="col-md-5">
      <h5>Rutas disponibles</h5>
      <asp:ListBox ID="lstDisponibles" runat="server" CssClass="form-control" SelectionMode="Multiple" Rows="12"></asp:ListBox>
    </div>
    <div class="col-md-2 d-flex flex-column justify-content-center align-items-center gap-2">
      <asp:Button ID="btnAgregar" runat="server" CssClass="btn btn-outline-secondary" Text="&gt;&gt;" />
      <asp:Button ID="btnQuitar" runat="server" CssClass="btn btn-outline-secondary" Text="&lt;&lt;" />
    </div>
    <div class="col-md-5">
      <h5>Rutas asignadas</h5>
      <asp:ListBox ID="lstAsignadas" runat="server" CssClass="form-control" SelectionMode="Multiple" Rows="12"></asp:ListBox>
    </div>
  </div>

  <div class="mt-3 d-flex justify-content-end">
    <asp:LinkButton ID="btnGuardarAsignacion" runat="server" CssClass="btn text-white" Style="background-color:#4b0082">
      Guardar
    </asp:LinkButton>
  </div>
</asp:Content>
