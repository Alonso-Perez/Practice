﻿<%@ Page Title="" Language="C#" MasterPageFile="~/GoutuCuenta.Master" AutoEventWireup="true" CodeBehind="Tarifa.aspx.cs" Inherits="GoutuWA.Tarifa" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Tarifas
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f5f5f5;
        }
        
        .tarifa-section {
            margin: 20px auto;
            width: 90%;
            max-width: 800px;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 8px rgba(0,0,0,0.1);
            position: relative;
            min-height: 300px;
            background-size: cover;
            background-position: center;
            background-repeat: no-repeat;
        }
        
        .tarifa-overlay {
            background-color: rgba(255, 255, 255, 0.85);
            padding: 20px;
            border-radius: 8px;
            margin: 20px;
            position: absolute;
            bottom: 20px;
            right: 20px;
            width: 250px;
        }
        
        .tarifa-table {
            width: 100%;
            border-collapse: collapse;
        }
        
        .tarifa-table th, .tarifa-table td {
            padding: 10px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }
        
        .tarifa-table th {
            background-color: #f2f2f2;
            font-weight: bold;
        }
        
        .tarifa-title {
            margin-top: 0;
            color: #333;
            font-size: 1.2em;
        }
        
        .tarifa-principal {
            background-image: url('images/METROPOLITANO.jpg');





        }
        
        .tarifa-complementarios {
            background-image: url('images/CORREDORES.jpg');
        }
        
        .tarifa-paradero {
            background-image: url('images/TREN.jpg');
        }
    </style>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoCuenta" runat="server">

    <div class="tarifa-section tarifa-principal">
        <div class="tarifa-overlay">
            <h3 class="tarifa-title">Tarifas Principales</h3>
            <table class="tarifa-table">
                <tr><th>Categoría</th><th>Precio</th></tr>
                <tr><td>General</td><td>S/. 3.50</td></tr>
                <tr><td>Universitario</td><td>S/. 1.75</td></tr>
                <tr><td>Estudiante</td><td>S/. 1.50</td></tr>
            </table>
        </div>
    </div>
    
    <div class="tarifa-section tarifa-complementarios">
        <div class="tarifa-overlay">
       
            <h3 class="tarifa-title">Corredores Complementarios</h3>
            <table class="tarifa-table">
                <tr><th>Categoría</th><th>Precio</th></tr>
                <tr><td>General</td><td>S/. 3.20</td></tr>
                <tr><td>Universitario</td><td>S/. 1.20</td></tr>
                <tr><td>Estudiante</td><td>S/. 1.00</td></tr>
            </table>
        </div>
    </div>
    
    <div class="tarifa-section tarifa-paradero">
        <div class="tarifa-overlay">
            <h3 class="tarifa-title">Paradero Iracundo</h3>
            <table class="tarifa-table">
                <tr><th>Categoría</th><th>Precio</th></tr>
                <tr><td>General</td><td>S/. 1.50</td></tr>
                <tr><td>Universitario</td><td>S/. 0.50</td></tr>
            </table>
        </div>
    </div>

    <br /><hr />

		<style>
			/* Estilos para la tarjeta seleccionable */
			.card-select-option {
				border: 2px solid #e0e0e0;
				border-radius: 15px;
				padding: 15px;
				display: flex;
				align-items: center;
				cursor: pointer;
				transition: all 0.2s ease;
				margin-bottom: 10px;
				background-color: #fff;
			}
			/* Efecto Hover */
			.card-select-option:hover {
				border-color: #c0c0c0;
				background-color: #fcfaff; 
			}
			/* Estilo cuando está seleccionada */
			.card-select-option.selected {
				border-color: #5e2a84; /* Color Morado Goutu */
				background-color: #f3e5f5;
				box-shadow: 0 0 10px rgba(94, 42, 132, 0.2);
			}
			/* Imagen de la tarjeta */
			.card-icon-img {
				width: 50px;
				height: 30px;
				object-fit: cover;
				border-radius: 4px;
				margin-right: 15px;
			}
		</style>

		<script type="text/javascript">
			function selectCard(element, cardValue) {
				// 1. Quitar clase 'selected' de todas las tarjetas
				var options = document.getElementsByClassName('card-select-option');
				for (var i = 0; i < options.length; i++) {
					options[i].classList.remove('selected');
				}
				// 2. Agregar clase 'selected' a la clickeada
				element.classList.add('selected');
				
				// 3. Guardar el valor en el HiddenField para C#
				var hiddenField = document.getElementById('<%= hdnSelectedCard.ClientID %>');
				if(hiddenField) {
					hiddenField.value = cardValue;
				}
			}
        </script>

		<div class="container mt-4" style="margin-bottom: 50px;">
			<div class="card shadow-sm">
				<div class="card-header bg-primary text-white">
					<h4 class="mb-0"><i class="fa fa-bus"></i> Simular Pago de Pasaje</h4>
				</div>
				<div class="card-body" style="background-color: #f8f9fa;">
					
					<asp:HiddenField ID="hdnSelectedCard" runat="server" />

					<div class="row">
						<div class="col-md-6">
							<label class="form-label fw-bold mb-3">1. Selecciona tu Tarjeta:</label>
							
							<asp:Repeater ID="rptTarjetas" runat="server">
								<ItemTemplate>
									<div class="card-select-option" onclick="selectCard(this, '<%# Eval("Value") %>')">
										<img src='<%# Eval("ImagenUrl") %>' alt="Tarjeta" class="card-icon-img"/>
										
										<div class="flex-grow-1">
											<div class="fw-bold"><%# Eval("Nombre") %></div>
											<div class="text-muted small"><%# Eval("Numero") %></div>
										</div>
										
										<div class="text-end">
											<span class="badge bg-success rounded-pill">S/ <%# Eval("Saldo") %></span>
											<div class="text-muted small mt-1"><%# Eval("Tarifario") %></div>
										</div>
									</div>
								</ItemTemplate>
							</asp:Repeater>
							
							<asp:Panel ID="pnlNoTarjetas" runat="server" Visible="false" CssClass="alert alert-warning">
								No tienes tarjetas registradas.
							</asp:Panel>
						</div>

						<div class="col-md-6 d-flex flex-column justify-content-center">
							<div class="p-4 border rounded bg-white">
								<label class="form-label fw-bold mb-2">2. ¿Qué transporte vas a usar?</label>
								
								<asp:DropDownList ID="ddlTransportes" runat="server" 
									CssClass="form-select form-control mb-4" Font-Size="Large">
								</asp:DropDownList>

								<div class="d-grid">
									<asp:Button ID="btnSimularCobro" runat="server" Text="PAGAR PASAJE" 
										CssClass="btn btn-success btn-lg fw-bold" OnClick="btnSimularCobro_Click" />
								</div>
								
								<div class="mt-3 text-center">
									<asp:Label ID="lblResultadoSimulacion" runat="server" CssClass="fw-bold fs-5"></asp:Label>
								</div>
							</div>
						</div>
					</div>

				</div>
			</div>
		</div>

</asp:Content>
