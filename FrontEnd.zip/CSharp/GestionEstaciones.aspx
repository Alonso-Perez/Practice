﻿<%@ Page Title="Gestión de Estaciones" Language="C#" MasterPageFile="~/GoutuAdminTransporte.master" AutoEventWireup="true" CodeBehind="GestionEstaciones.aspx.cs" Inherits="GoutuWA.GestionEstaciones" %>

<asp:Content ID="Content1" ContentPlaceHolderID="cph_Title" runat="server">
    Gestión de Estaciones - Administrador
</asp:Content>

<asp:Content ID="Content2" ContentPlaceHolderID="cph_Scripts" runat="server">
    <script type="text/javascript">
        function confirmarEliminacion() {
            return confirm('¿Está seguro que desea eliminar esta estación? Esta acción no se puede deshacer.');
        }

        // Validación personalizada para evitar conflictos con required
        function validarFormulario() {
            var servicio = document.getElementById('<%= ddlServicio.ClientID %>');
            var nombre = document.getElementById('<%= txtNombreEstacion.ClientID %>');
            var latitud = document.getElementById('<%= txtLatitud.ClientID %>');
            var longitud = document.getElementById('<%= txtLongitud.ClientID %>');

            if (servicio.value == '') {
                alert('Por favor seleccione un servicio');
                servicio.focus();
                return false;
            }

            if (nombre.value.trim() == '') {
                alert('Por favor ingrese el nombre de la estación');
                nombre.focus();
                return false;
            }

            if (latitud.value.trim() == '') {
                alert('Por favor ingrese la latitud');
                latitud.focus();
                return false;
            }

            if (longitud.value.trim() == '') {
                alert('Por favor ingrese la longitud');
                longitud.focus();
                return false;
            }

            return true;
        }
    </script>
</asp:Content>

<asp:Content ID="Content3" ContentPlaceHolderID="cph_ContenidoAdmin" runat="server">
    <style>
        .page-header {
            background: white;
            padding: 25px 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
            display: flex;
            justify-content: space-between;
            align-items: center;
        }

        .page-title {
            color: #5e2a84;
            font-size: 26px;
            font-weight: 700;
            margin: 0;
        }

        .form-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            margin-bottom: 30px;
        }

        .form-title {
            color: #5e2a84;
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            padding-bottom: 10px;
            border-bottom: 2px solid #5e2a84;
        }

        .form-row {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 20px;
        }

        .form-group {
            display: flex;
            flex-direction: column;
        }

        .form-group label {
            color: #333;
            font-weight: 600;
            margin-bottom: 8px;
            font-size: 14px;
        }

        .form-control {
            padding: 12px 15px;
            border: 2px solid #e0e0e0;
            border-radius: 8px;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .form-control:focus {
            outline: none;
            border-color: #5e2a84;
            box-shadow: 0 0 0 3px rgba(94, 42, 132, 0.1);
        }

        .form-control:disabled {
            background-color: #f5f5f5;
            border-color: #d0d0d0;
            color: #666;
        }

        .checkbox-container {
            display: flex;
            align-items: center;
            gap: 10px;
            margin-top: 25px;
        }

        .checkbox-estado {
            width: 20px;
            height: 20px;
            cursor: pointer;
        }

        .checkbox-label {
            font-weight: 600;
            color: #333;
            cursor: pointer;
        }

        .btn-group {
            display: flex;
            gap: 15px;
            margin-top: 25px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 25px;
            font-weight: 600;
            cursor: pointer;
            transition: all 0.3s ease;
            font-size: 14px;
        }

        .btn-primary {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 4px 12px rgba(94, 42, 132, 0.3);
        }

        .btn-warning {
            background-color: #ffc107;
            border-color: #ffc107;
            color: #212529;
        }

        .btn-warning:hover {
            background-color: #e0a800;
            border-color: #e0a800;
            color: #212529;
        }

        .btn-secondary {
            background-color: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background-color: #5a6268;
            transform: translateY(-2px);
        }

        .table-container {
            background: white;
            padding: 30px;
            border-radius: 15px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.08);
            overflow-x: auto;
        }

        .custom-table {
            width: 100%;
            border-collapse: collapse;
        }

        .custom-table thead {
            background: linear-gradient(135deg, #5e2a84 0%, #4a1f63 100%);
            color: white;
        }

        .custom-table th {
            padding: 15px;
            text-align: left;
            font-weight: 600;
            font-size: 14px;
        }

        .custom-table td {
            padding: 15px;
            border-bottom: 1px solid #e0e0e0;
            font-size: 14px;
        }

        .custom-table tbody tr:hover {
            background-color: #f8f9fa;
        }

        .btn-action {
            padding: 8px 15px;
            margin: 0 3px;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            font-size: 13px;
            font-weight: 600;
            transition: all 0.3s ease;
        }

        .btn-edit {
            background-color: #ffc107;
            color: #000;
        }

        .btn-edit:hover {
            background-color: #e0a800;
            transform: translateY(-2px);
        }

        .btn-delete {
            background-color: #dc3545;
            color: white;
        }

        .btn-delete:hover {
            background-color: #c82333;
            transform: translateY(-2px);
        }

        .alert {
            padding: 15px 20px;
            border-radius: 10px;
            margin-bottom: 20px;
            font-weight: 500;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
            border-left: 4px solid #28a745;
        }

        .alert-error {
            background-color: #f8d7da;
            color: #721c24;
            border-left: 4px solid #dc3545;
        }

        .badge {
            padding: 6px 12px;
            border-radius: 12px;
            font-size: 12px;
            font-weight: 600;
        }

        .badge-active {
            background-color: #28a745;
            color: white;
        }

        .badge-inactive {
            background-color: #dc3545;
            color: white;
        }
    </style>

    <!-- Mensajes -->
    <asp:Panel ID="pnlMensaje" runat="server" Visible="false">
        <div id="divMensaje" runat="server" class="alert">
            <asp:Label ID="lblMensaje" runat="server"></asp:Label>
        </div>
    </asp:Panel>

    <!-- Cabecera -->
    <div class="page-header">
        <h1 class="page-title"><i class="fa-solid fa-location-dot"></i> Gestión de Estaciones</h1>
    </div>

    <!-- Formulario de Estación -->
    <div class="form-container">
        <div class="form-title">
            <i class="fa-solid fa-plus-circle"></i> 
            <asp:Label ID="lblFormTitle" runat="server" Text="Nueva Estación"></asp:Label>
        </div>

        <asp:HiddenField ID="txtIdEstacion" runat="server" />

        <!-- Primera fila -->
        <div class="form-row">
            <div class="form-group">
                <label for="<%= ddlServicio.ClientID %>"><i class="fa-solid fa-bus"></i> Servicio *</label>
                <asp:DropDownList ID="ddlServicio" runat="server" CssClass="form-control">
                </asp:DropDownList>
            </div>

            <div class="form-group">
                <label for="<%= txtNombreEstacion.ClientID %>"><i class="fa-solid fa-tag"></i> Nombre de Estación *</label>
                <asp:TextBox ID="txtNombreEstacion" runat="server" CssClass="form-control" 
                    placeholder="Ej: Estación Central" MaxLength="100"></asp:TextBox>
            </div>
        </div>

        <!-- Segunda fila -->
        <div class="form-row">
            <div class="form-group">
                <label for="<%= txtLatitud.ClientID %>"><i class="fa-solid fa-map-marker-alt"></i> Latitud *</label>
                <asp:TextBox ID="txtLatitud" runat="server" CssClass="form-control" 
                    placeholder="Ej: -12.046374"></asp:TextBox>
            </div>

            <div class="form-group">
                <label for="<%= txtLongitud.ClientID %>"><i class="fa-solid fa-map-marker-alt"></i> Longitud *</label>
                <asp:TextBox ID="txtLongitud" runat="server" CssClass="form-control" 
                    placeholder="Ej: -77.042793"></asp:TextBox>
            </div>
        </div>

        <!-- Checkbox para estado activo (oculto inicialmente) -->
        <div id="divEstadoActivo" runat="server" class="checkbox-container" visible="false">
            <asp:CheckBox ID="chkActivo" runat="server" CssClass="checkbox-estado" />
            <label for="<%= chkActivo.ClientID %>" class="checkbox-label">Activo</label>
        </div>

        <!-- Botones -->
        <div class="btn-group">
            <asp:Button ID="btnGuardar" runat="server" Text="Guardar Estación" 
                CssClass="btn btn-primary" OnClick="btnGuardar_Click" 
                OnClientClick="return validarFormulario();" />
            <asp:Button ID="btnCancelar" runat="server" Text="Cancelar" 
                CssClass="btn btn-secondary" OnClick="btnCancelar_Click" 
                CausesValidation="false" />
            <asp:Button ID="btnEditarEstacion" runat="server" Text="Actualizar Estación" 
                CssClass="btn btn-warning" OnClick="btnEditarEstacion_Click" 
                Visible="false" OnClientClick="return validarFormulario();" />
            <asp:Button ID="btnCancelarEdicion" runat="server" Text="Cancelar Edición" 
                CssClass="btn btn-secondary" OnClick="btnCancelarEdicion_Click" 
                Visible="false" CausesValidation="false" />
        </div>
    </div>

    <!-- Tabla -->
    <div class="table-container">
        <div class="form-title"><i class="fa-solid fa-list"></i> Lista de Estaciones</div>

        <asp:GridView ID="gvEstaciones" runat="server" AutoGenerateColumns="False" CssClass="custom-table"
            OnRowCommand="gvEstaciones_RowCommand">
            <Columns>
                <asp:BoundField DataField="id_estacion" HeaderText="ID" />
                <asp:BoundField DataField="nombre" HeaderText="Nombre" />
                <asp:BoundField DataField="latitud" HeaderText="Latitud" DataFormatString="{0:F6}" />
                <asp:BoundField DataField="longitud" HeaderText="Longitud" DataFormatString="{0:F6}" />
                <asp:TemplateField HeaderText="Estado">
                    <ItemTemplate>
                        <span class='<%# Convert.ToBoolean(Eval("activo")) ? "badge badge-active" : "badge badge-inactive" %>'>
                            <%# Convert.ToBoolean(Eval("activo")) ? "Activo" : "Inactivo" %>
                        </span>
                    </ItemTemplate>
                </asp:TemplateField>
                <asp:BoundField DataField="id_servicio" HeaderText="ID Servicio" />
                <asp:BoundField DataField="nombre_Servicio" HeaderText="Servicio" />
                <asp:TemplateField HeaderText="Acciones">
                    <ItemTemplate>
                        <asp:Button ID="btnEditar" runat="server" Text="Editar" CommandName="Editar" 
                            CommandArgument='<%# Eval("id_estacion") %>' CssClass="btn-action btn-edit" 
                            CausesValidation="false" UseSubmitBehavior="true" />
                        <asp:Button ID="btnEliminar" runat="server" Text="Eliminar" CommandName="Eliminar" 
                            CommandArgument='<%# Eval("id_estacion") %>' CssClass="btn-action btn-delete" 
                            OnClientClick="return confirmarEliminacion();" CausesValidation="false" />
                    </ItemTemplate>
                </asp:TemplateField>
            </Columns>
        </asp:GridView>
    </div>
</asp:Content>